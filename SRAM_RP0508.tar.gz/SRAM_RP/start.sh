PWD=`pwd`                              
WORKPATH=$PWD                          

######################################
# Check if the futureSuite is runing #
###################################### 
UTU=`ps -e | grep utu | gawk '{print $1}'`
if [ -n "$UTU" ]; then
  echo "FutureSuite is running"
  fsproreset
  fsclear
else
  starttesim
fi


#######################################
## Load socket and location file 	 #
#######################################
fscd $PWD              
fsproset $PWD/main
fsconf --socket-file $PWD/SRAM_BD.soc
fsprostart&
