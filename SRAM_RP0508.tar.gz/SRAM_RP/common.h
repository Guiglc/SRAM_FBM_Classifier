#ifndef	__COMMON_H
#define	__COMMON_H

////////////////////////
#define DUT_NUM 1
#define HASH_NUM 150


typedef int DUT_MASK;

enum FLOW  {STOP=-1,NEXT=-2};

////////////////////////
extern int FK[17];
extern int g_die_X[DUT_NUM];
extern int g_die_Y[DUT_NUM];
extern char g_TestName[256];
extern int g_NextSeq[DUT_NUM];
extern int g_BinNo[DUT_NUM];
extern char *g_BinName[DUT_NUM];
extern int g_Rejected[DUT_NUM];
extern double g_tRjectTitemTime[DUT_NUM];
extern int g_FlowDutActive[DUT_NUM];
extern char *g_DeviceName;
extern char *g_LotNumber;
extern char *g_ProberID;
extern char *g_WaferId;
extern char *g_WaferSlotNumber;
extern int g_FirstRun;
extern unsigned int g_shotcounter;
int ReadResult(UT_DUT f);
void Dummy();
void RUN_TEST(int id, void (*func)(), char *tname, void (*pre_exec)(), void (*post_exec)(), int pass_branch, int fail_branch , int bin);
void SetRegValue(RadioButton reg, USlider value);
int GetRegValue(RadioButton reg)	;
void Print(const char *format, ... );
void DebugPrint(const char *format, ... );
void ErrorStop(const char *format, ... );
int ReadFk(int fknum);
void PowerON();
void PowerOFF();
void SaveDutGroupToArray(UT_DUT DutArray[] ,int dutgroup);
int GetMeasResult(int dut);
int GetFinalResult(int dut);
void SetFinalResultOnly(int dut, int result);
void SetFinalResultOnlyAllDut(int result);
void SetFinalResultOnlyByDutMask(int dut_mask[], int result);
void SetIlMode(int ilmode);
void run_alpg_pattern(char *patfile, char *startlabel);
void start_alpg_pattern_nowait(char *patfile, char *startlabel);
void start_alpg_pattern(char *patfile, char *startlabel);
void continue_start_alpg_pattern();
void continue_meas_alpg_pattern();
void stop_alpg_pattern();
void pause();
void pause2(char *fmt, ...);
void pause3(char *fmt, ...);
void SetDutsRejection (int reject_array[]);
void SetDutsExclusion (int exclude_array[]);
void SetDutsExclusion_rof(int exclude_array[]);
void ResetDutsExclusion (int recover_array[]);
void SetPinLevelFixl(char *pinlist);
void SetPinLevelFixh(char *pinlist);
void SetPinLevelNone(char *pinlist);
char* getSymbol(char *name);
void setSymbol(char* name, char* value);
int parse_xylist(char *xy_list, char xy_deli, int xybit[]);

#define PASS	UT_RES_PASSED
#define FAIL	UT_RES_FAILED
#define NOTTEST	UT_RES_NOT_TESTED

#define TRUE  1
#define FALSE 0

#define OVER_FLOW -9999

#define NA    *1e-9
#define UA    *1e-6
#define MA    *1e-3
#define  A    *1.0

#define UV    *1e-6
#define MV    *1e-3
#define  V    *1.0

#define NS    *1e-9
#define US    *1e-6
#define MS    *1e-3
#define  S    *1.0


#define FP_DISABLE	UT_ALPG_FPSEL_DISABLE
#define FP0			UT_ALPG_FPSEL_FP0
#define FP1			UT_ALPG_FPSEL_FP1
#define FP3			UT_ALPG_FPSEL_FP3
#define FP4			UT_ALPG_FPSEL_FP4
#define FP5			UT_ALPG_FPSEL_FP5
#define FP6			UT_ALPG_FPSEL_FP6
#define FP7			UT_ALPG_FPSEL_FP7
#define FP8			UT_ALPG_FPSEL_FP8
#define FP9			UT_ALPG_FPSEL_FP9
#define FP10		UT_ALPG_FPSEL_FP10

#define	X0	(UT_SIG_X(0 ))
#define	X1	(UT_SIG_X(1 ))
#define	X2	(UT_SIG_X(2 ))
#define	X3	(UT_SIG_X(3 ))
#define	X4	(UT_SIG_X(4 ))
#define	X5	(UT_SIG_X(5 ))
#define	X6	(UT_SIG_X(6 ))
#define	X7	(UT_SIG_X(7 ))
#define	X8	(UT_SIG_X(8 ))
#define	X9	(UT_SIG_X(9 ))
#define	X10	(UT_SIG_X(10))
#define	X11	(UT_SIG_X(11))
#define	X12	(UT_SIG_X(12))
#define	X13	(UT_SIG_X(13))
#define	X14	(UT_SIG_X(14))
#define	X15	(UT_SIG_X(15))
#define	X16	(UT_SIG_X(16))
#define	X17	(UT_SIG_X(17))
#define	X18	(UT_SIG_X(18))
#define	X19	(UT_SIG_X(19))
#define	X20	(UT_SIG_X(20))
#define	X21	(UT_SIG_X(21))
#define	X22	(UT_SIG_X(22))
#define	X23	(UT_SIG_X(23))
#define	Y0	(UT_SIG_Y(0 ))
#define	Y1	(UT_SIG_Y(1 ))
#define	Y2	(UT_SIG_Y(2 ))
#define	Y3	(UT_SIG_Y(3 ))
#define	Y4	(UT_SIG_Y(4 ))
#define	Y5	(UT_SIG_Y(5 ))
#define	Y6	(UT_SIG_Y(6 ))
#define	Y7	(UT_SIG_Y(7 ))
#define	Y8	(UT_SIG_Y(8 ))
#define	Y9	(UT_SIG_Y(9 ))
#define	Y10	(UT_SIG_Y(10))
#define	Y11	(UT_SIG_Y(11))
#define	Y12	(UT_SIG_Y(12))
#define	Y13	(UT_SIG_Y(13))
#define	Y14	(UT_SIG_Y(14))
#define	Y15	(UT_SIG_Y(15))
#define	Y16	(UT_SIG_Y(16))
#define	Y17	(UT_SIG_Y(17))
#define	Y18	(UT_SIG_Y(18))
#define	Y19	(UT_SIG_Y(19))
#define	Y20	(UT_SIG_Y(20))
#define	Y21	(UT_SIG_Y(21))
#define	Y22	(UT_SIG_Y(22))
#define	Y23	(UT_SIG_Y(23))
#define	C0	(UT_SIG_C(0 ))
#define	C1	(UT_SIG_C(1 ))
#define	C2	(UT_SIG_C(2 ))
#define	C3	(UT_SIG_C(3 ))
#define	C4	(UT_SIG_C(4 ))
#define	C5	(UT_SIG_C(5 ))
#define	C6	(UT_SIG_C(6 ))
#define	C7	(UT_SIG_C(7 ))
#define	C8	(UT_SIG_C(8 ))
#define	C9	(UT_SIG_C(9 ))
#define	C10	(UT_SIG_C(10))
#define	C11	(UT_SIG_C(11))
#define	C12	(UT_SIG_C(12))
#define	C13	(UT_SIG_C(13))
#define	C14	(UT_SIG_C(14))
#define	C15	(UT_SIG_C(15))
#define	C16	(UT_SIG_C(16))
#define	C17	(UT_SIG_C(17))
#define	C18	(UT_SIG_C(18))
#define	C19	(UT_SIG_C(19))
#define	C20	(UT_SIG_C(20))
#define	C21	(UT_SIG_C(21))
#define	C22	(UT_SIG_C(22))
#define	C23	(UT_SIG_C(23))
#define	C24	(UT_SIG_C(24))
#define	C25	(UT_SIG_C(25))
#define	C26	(UT_SIG_C(26))
#define	C27	(UT_SIG_C(27))
#define	C28	(UT_SIG_C(28))
#define	C29	(UT_SIG_C(29))
#define	C30	(UT_SIG_C(30))
#define	C31	(UT_SIG_C(31))
#define	D0	(UT_SIG_D(0 ))
#define	D1	(UT_SIG_D(1 ))
#define	D2	(UT_SIG_D(2 ))
#define	D3	(UT_SIG_D(3 ))
#define	D4	(UT_SIG_D(4 ))
#define	D5	(UT_SIG_D(5 ))
#define	D6	(UT_SIG_D(6 ))
#define	D7	(UT_SIG_D(7 ))
#define	D8	(UT_SIG_D(8 ))
#define	D9	(UT_SIG_D(9 ))
#define	D10	(UT_SIG_D(10))
#define	D11	(UT_SIG_D(11))
#define	D12	(UT_SIG_D(12))
#define	D13	(UT_SIG_D(13))
#define	D14	(UT_SIG_D(14))
#define	D15	(UT_SIG_D(15))
#define	D16	(UT_SIG_D(16))
#define	D17	(UT_SIG_D(17))
#define	SD0	(UT_SIG_SD(0 ))
#define	SD1	(UT_SIG_SD(1 ))
#define	SD2	(UT_SIG_SD(2 ))
#define	SD3	(UT_SIG_SD(3 ))
#define	SD4	(UT_SIG_SD(4 ))
#define	SD5	(UT_SIG_SD(5 ))
#define	SD6	(UT_SIG_SD(6 ))
#define	SD7	(UT_SIG_SD(7 ))
#define	SD8	(UT_SIG_SD(8 ))
#define	SD9	(UT_SIG_SD(9 ))
#define	SD10	(UT_SIG_SD(10))
#define	SD11	(UT_SIG_SD(11))
#define	SD12	(UT_SIG_SD(12))
#define	SD13	(UT_SIG_SD(13))
#define	SD14	(UT_SIG_SD(14))
#define	SD15	(UT_SIG_SD(15))
#define	SD16	(UT_SIG_SD(16))
#define	SD17	(UT_SIG_SD(17))
#define	FL	(UT_SIG_FL    )
#define	FH	(UT_SIG_FH    )



////////////////////////
#define MAC_LOOPDUT_START(dutgroup)                            \
{                                                           \
	UT_DUT    dut=0;                                          \
	DutCursor dutcsr = UTL_GetDutCursor(dutgroup);                    \
	while ((dut=UTL_NextDut(dutcsr)) != UT_NOMORE )        \
	{

#define MAC_LOOPDUT_STOP                                        \
	}                                                       \
	UTL_DeleteCursor(dutcsr);                               \
}

#define MAC_LOOPPIN_START(pinlist)\
{\
		PinCursor pincur;\
		UT_PIN pin;\
		pincur = UTL_GetPinCursor(pinlist);\
		while((pin=UTL_NextPin(pincur))!=UT_NOMORE)\
		{

#define MAC_LOOPPIN_STOP\
		}\
		UTL_DeleteCursor(pincur);\
}
	


////////////////////////
#define MAC_READCDUT(log) \
{ \
	if(FK[14]) \
	{ \
		Print("** %s_CDUT= ",log); \
		MAC_LOOPDUT_START(UT_CDUT) \
			Print("%d-",dut); \
		MAC_LOOPDUT_STOP \
		Print("> **\n"); \
	} \
}


////////////////////////
#define MAC_VS_BRANCH_START(vspinno) \
{ \
	UT_DUT VsBranchInDutsArray[DUT_NUM] = {0}; \
	SaveDutGroupToArray(VsBranchInDutsArray,UT_CDUT); \
	MAC_READCDUT("VsBranchInDuts") \
	DutCursor dutcsr; \
	UT_DUT    dut; \
	int maxdg,dg; \
	ExclusionHandle hex = UTL_GetExclusionHandle(); \
	maxdg=UTL_GetDctVsDutGroupMaxNumber(vspinno); \
	UTL_SetExclusionIgnoreWet  (hex,UT_OFF); \
	UTL_SetExclusionMask       (hex,UT_ON); \
	MAC_LOOPDUT_START(UT_MDUT)                                             \
		UTL_AddExclusionDut(hex,dut);                                   \
	MAC_LOOPDUT_STOP                                                        \
	UTL_SetExclusionSetOrReset (hex,UT_ON); \
	UTL_SendExclusion(hex); \
	for(dg=0;dg<=maxdg;dg++) \
	{ \
		UTL_ClearExclusionDut(hex); \
		dutcsr=UTL_GetDctVsDutGroupCursor(vspinno,dg); \
		while ((dut=UTL_NextDut(dutcsr)) != UT_NOMORE ) \
		{ \
			if(VsBranchInDutsArray[dut-1]==1) \
			{ \
				UTL_AddExclusionDut(hex,dut); \
			} \
		} \
		UTL_SetExclusionSetOrReset (hex,UT_OFF); \
		UTL_SendExclusion(hex); \
		UTL_DeleteCursor(dutcsr); \
		if(UTL_GetDutCount(UT_CDUT)<=0){ \
			continue;\
		}else{\
			MAC_READCDUT("VsBranchLoopStart") 

#define MAC_VS_BRANCH_STOP \
		} \
		if(dg<maxdg) \
		{ \
			UTL_SetExclusionSetOrReset (hex,UT_ON); \
			UTL_SendExclusion(hex); \
		} \
	}\
	UTL_ClearExclusionDut(hex); \
	MAC_LOOPDUT_START(UT_MDUT)                                             \
		if(VsBranchInDutsArray[dut-1]==1){ \
			UTL_AddExclusionDut(hex,dut);                                   \
		}\
	MAC_LOOPDUT_STOP                                                   \
	UTL_SetExclusionSetOrReset (hex,UT_OFF); \
	UTL_SendExclusion(hex); \
	UTL_DeleteHandle(hex); \
	MAC_READCDUT("VsBranchOutDuts") \
}



////////////////////////
#define MAC_HV_BRANCH_START(vspinno) \
{ \
	UT_DUT HvBranchInDutsArray[DUT_NUM] = {0}; \
	SaveDutGroupToArray(HvBranchInDutsArray,UT_CDUT); \
	MAC_READCDUT("HvBranchInDuts") \
	DutCursor dutcsr; \
	UT_DUT    dut; \
	int maxdg,dg; \
	ExclusionHandle hex = UTL_GetExclusionHandle(); \
	VsMaskHandle hvsmask= UTL_GetVsMaskHandle(); \
	maxdg=UTL_GetDctVsDutGroupMaxNumber(vspinno); \
	UTL_SetExclusionIgnoreWet  (hex,UT_OFF); \
	UTL_SetExclusionMask       (hex,UT_OFF); \
	MAC_LOOPDUT_START(UT_MDUT)                                             \
		UTL_AddVsMaskDutVsMask(hvsmask,dut,vspinno,UT_ON); \
		UTL_AddExclusionDut(hex,dut);                                   \
	MAC_LOOPDUT_STOP                                                    \
	UTL_SendVsMask(hvsmask); \
	UTL_SetExclusionSetOrReset (hex,UT_ON); \
	UTL_SendExclusion(hex); \
	for(dg=0;dg<=maxdg;dg++) \
	{ \
		UTL_ClearExclusionDut(hex); \
		dutcsr=UTL_GetDctVsDutGroupCursor(vspinno,dg); \
		while ((dut=UTL_NextDut(dutcsr)) != UT_NOMORE ) \
		{ \
			if(HvBranchInDutsArray[dut-1]==1) \
			{ \
				UTL_AddVsMaskDutVsMask(hvsmask,dut,vspinno,UT_OFF); \
				UTL_AddExclusionDut(hex,dut); \
			} \
		} \
		UTL_DeleteCursor(dutcsr); \
		UTL_SendVsMask(hvsmask); \
		UTL_SetExclusionSetOrReset (hex,UT_OFF); \
		UTL_SendExclusion(hex); \
		if(UTL_GetDutCount(UT_CDUT)<=0){ \
			continue;\
		}else{ \
			MAC_READCDUT("HvBranchLoopStart") 

#define MAC_HV_BRANCH_STOP(vspinno) \
		} \
		if(dg<maxdg) \
		{ \
			UTL_ClearVsMaskDutVsMask(hvsmask); \
			UTL_ClearExclusionDut(hex); \
			dutcsr=UTL_GetDctVsDutGroupCursor(vspinno,dg); \
			while((dut=UTL_NextDut(dutcsr)) != UT_NOMORE) \
			{ \
				if(HvBranchInDutsArray[dut-1]==1){ \
					UTL_AddVsMaskDutVsMask(hvsmask,dut,vspinno,UT_ON); \
					UTL_AddExclusionDut(hex,dut); \
				}\
			} \
			UTL_DeleteCursor(dutcsr); \
			UTL_SendVsMask(hvsmask); \
			UTL_SetExclusionSetOrReset (hex,UT_ON); \
			UTL_SendExclusion(hex); \
		} \
	}\
	UTL_ClearExclusionDut(hex); \
	MAC_LOOPDUT_START(UT_MDUT)                                             \
		if(HvBranchInDutsArray[dut-1]==1) \
		{ \
			UTL_AddVsMaskDutVsMask(hvsmask,dut,vspinno,UT_ON); \
			UTL_AddExclusionDut(hex,dut); \
		} \
	MAC_LOOPDUT_STOP\
	UTL_SendVsMask(hvsmask); \
	UTL_SetExclusionSetOrReset (hex,UT_OFF); \
	UTL_SendExclusion(hex); \
	UTL_DeleteHandle(hvsmask); \
	UTL_DeleteHandle(hex); \
	MAC_READCDUT("HvBranchOutDuts") \
}


#define MAC_START_SERIAL_TEST_CDUT							\
{															\
	UT_DUT HvBranchInDutsArray[DUT_NUM] = {0}; \
	SaveDutGroupToArray(HvBranchInDutsArray,UT_CDUT); \
	MAC_READCDUT("SerialTestInDuts") \
	PinCursor pc;											\
	UT_PIN pin;												\
	int dutlist[DUT_NUM+1],dutcnt=0,dut,i;					\
	pc = UTL_GetPinCursor ((char *)"CS" );					\
	pin=UTL_NextPin(pc);									\
	UTL_DeleteCursor(pc);\
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();	\
   	MAC_LOOPDUT_START(UT_CDUT)									\
		UTL_SetExclusion(dut,UT_OFF,UT_OFF);				\
		UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXH);  \
		UTL_SendLevelFix(level_fix_handle, pin, dut);		\
		dutlist[dutcnt++] = dut;							\
		dutlist[dutcnt]   = UT_NOMORE;						\
    MAC_LOOPDUT_STOP											\
	for(i=0;i<dutcnt;i++)			\
	{														\
		dut=dutlist[i];										\
		UTL_ResetExclusion(dut);							\
		UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_NONE);  \
		UTL_SendLevelFix(level_fix_handle, pin, dut);\
		MAC_READCDUT("SerialTestLoopStart") 
		
#define MAC_END_SERIAL_TEST_CDUT							\
    	UTL_SetExclusion(dut,UT_OFF,UT_OFF);				\
		UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXH);  \
		UTL_SendLevelFix(level_fix_handle, pin, dut);      \
	}														\
	for(i=0;i<dutcnt;i++)			\
	{														\
		dut=dutlist[i];										\
		UTL_ResetExclusion(dut);							\
		UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_NONE);  \
		UTL_SendLevelFix(level_fix_handle, pin, dut);      \
	}														\
	UTL_DeleteHandle(level_fix_handle);						\
	MAC_READCDUT("SerialTestOutDuts") \
}
////////////////////////
#define DISABLE_KELVIN_ALARM                      	\
{												\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskPpsKelvinAlarm(rmh, UT_ON);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);							\
}

#define ENABLE_KELVIN_ALARM                    \
{												\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskPpsKelvinAlarm(rmh, UT_OFF);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);						\
}

#define DISABLE_DcGuard_ALARM                      	\
{												\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskDcGuardAlarm(rmh, UT_ON);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);						\
}

#define ENABLE_DcGuard_ALARM                    \
{												\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskDcGuardAlarm(rmh, UT_OFF);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);						\
}

#define DISABLE_PpsGuard_ALARM                      	\
{												\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskPpsGuardAlarm(rmh, UT_ON);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);						\
}

#define ENABLE_PpsGuard_ALARM                    \
{			\
	RteMaskHandle rmh=UTL_GetRteMaskHandle();	\
	UTL_SetRteMaskPpsGuardAlarm(rmh, UT_OFF);	\
	UTL_SendRteMask(rmh);						\
 	UTL_DeleteHandle(rmh);						\
}

#define WAIT_SITE_SYNC(sync_name)\
{\
	static int sync_no;\
	int sync_status, sync_code;\
	if ((sync_code = UTSC_Flow_TestSiteSync_Wait(sync_name, &sync_status)) != 0){\
		UTSC_Flow_ExitOnError(sync_code);\
	}\
	if (sync_status == UTSC_FLOW_SYNC_INCOMPLETE) {\
		fprintf(stderr, "test end site exist.\n");\
		UT_ErrorInfo error_info = UTSC_ErrorInfo_Construct();\
		UTL_RuntimeError(error_info);\
	}\
}

#endif //__COMMON_H
