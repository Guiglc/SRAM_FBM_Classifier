#ifndef __FCM_H
#define __FCM_H

enum FcmAction{FCM_AF, FCM_BF, FCM_TOTALFAIL, FCM_DISABLE};

void ulDisableFcm();
void ulConfigFcm(char *pinlist, int xbit, int ybit, enum FcmAction action);
void ulConfigFcm(char *pinlist, enum FcmAction action, ...);
void ulPresetFcm();
void ulPresetFcmAll();
//void ulReadFcm(unsigned int *data, int size, int x_st, int x_sp, int y_st, int y_sp, int dut, RadioButton aplink);
void ulReadFcm(unsigned int *data, int size, int x_st, int x_sp, int y_st, int y_sp, int dut, RadioButton aplink,USlider bitblock);
void ulGetFcmPfcByCount(int x_start, int x_end, int y_start, int y_end, USlider *count);
void ConvertFcmDataToByte(unsigned int *data, unsigned int *fcm_data, int bit_size, int start_byte, int stop_byte);

void ulPresetCfm();
void ulConfigFcmCfmPinFlex();
void ulConfigCfm(char *pinlist, enum FcmAction action, ...);
void ulReadCfm(unsigned int *data, int size, int x_st, int x_sp,int y_st, int y_sp, int dut, RadioButton aplink);


#endif
