#include "main.h"

void setVSLevel(double vdd, double vddm, double vddm1, double vddm2, double dvdd)
{
	setVs(VSNO_VDD, vdd, R3V, M400mA, 400 MA, -200 MA);
	setVs(VSNO_VDDM, vddm, R3V, M400mA, 400 MA, -200 MA);
	setVs(VSNO_VDDM1, vddm1, R3V, M400mA, 400 MA, -200 MA);
	setVs(VSNO_VDDM2, vddm2, R3V, M400mA, 400 MA, -200 MA);
	setVs(VSNO_DVDD, dvdd, R3V, M400mA, 400 MA, -200 MA);
}

void setVSLevelMeas_PowerShort(double vdd, double vddm, double vddm1, double vddm2, double dvdd, double hlimit,double lowlimit, unsigned int cnt)
{

	setVsMeas(VSNO_VDD, vdd, R2V, M400uA, 250 UA, -250 UA, 50 UA, -50 UA, cnt);
	setVsMeas(VSNO_VDDM, vddm, R2V, M400uA, 250 UA, -250 UA, 50 UA, -50 UA, cnt);
	setVsMeas(VSNO_VDDM1, vddm1, R2V, M400uA, 250 UA, -250 UA, 50 UA, -50 UA, cnt);
	setVsMeas(VSNO_VDDM2, vddm2, R2V, M400uA, 250 UA, -250 UA, 50 UA, -50 UA, cnt);
	setVsMeas(VSNO_DVDD, dvdd, R2V, M400uA, 250 UA, -250 UA, 50 UA, -50 UA, cnt);
//	setVsMeas(VSNO_VDD, vdd, R2V, M40mA, 500 UA, -500 UA, hlimit, lowlimit, cnt);
//	setVsMeas(VSNO_VDDM, vddm, R2V, M40mA, 500 UA, -500 UA, hlimit, lowlimit, cnt);
//	setVsMeas(VSNO_VDDM1, vddm1, R2V, M40mA, 500 UA, -500 UA, hlimit, lowlimit, cnt);
//	setVsMeas(VSNO_VDDM2, vddm2, R2V, M40mA, 0 UA, -500 UA, hlimit, lowlimit, cnt);
//	setVsMeas(VSNO_DVDD, dvdd, R2V, M40mA, 20 UA, -500 UA, hlimit, lowlimit, cnt);

}

void setVSLevelMeas_ISB(double vdd, double vddm, double vddm1, double vddm2, double dvdd, unsigned int cnt)
{
	setVsMeas(VSNO_VDD, vdd, R3V, M40mA, 25 MA, -25 MA,  1000 UA,0 UA, cnt);
	setVsMeas(VSNO_VDDM, vddm, R3V, M4mA, 2.5 MA, -2.5 MA,  500 UA,0 UA, cnt);
	setVsMeas(VSNO_VDDM1, vddm1, R3V, M4mA, 2.5 MA, -2.5 MA, 200 UA,0 UA, cnt);
	setVsMeas(VSNO_VDDM2, vddm2, R3V, M4mA, 2.5 MA, -2.5 MA,  200 UA,0 UA, cnt);
	setVsMeas(VSNO_DVDD, dvdd, R3V, M4mA, 2.5 MA, -2.5 MA,  1000 UA,0 UA, cnt);
}

void setVSLevelMeas_IDD(double vdd, double vddm, double vddm1, double vddm2, double dvdd, unsigned int cnt)
{
	setVsMeas(VSNO_VDD, vdd, R3V, M40mA, 25 MA, -25 MA, 1200 UA, -1200 UA, cnt);
	setVsMeas(VSNO_VDDM, vddm, R3V, M40mA, 25 MA, -25 MA, 5000 UA, -5000 UA, cnt);
	setVsMeas(VSNO_VDDM1, vddm1, R3V, M4mA,2.5 MA, -2.5 MA, 2500 UA, -2500 UA, cnt);
	setVsMeas(VSNO_VDDM2, vddm2, R3V, M40mA, 25 MA, -25 MA, 2500 UA, -2500 UA, cnt);
	setVsMeas(VSNO_DVDD, dvdd, R3V, M40mA, 25 MA, -20 MA, 7500 UA, -7500 UA, cnt);
}

void setLevel()
{
	setDpinVi(1, VIH, VIL);
	setDpinVo(1, VIH);
	setDpinVt(1, (VIH + VIL) / 2);

	setDpinVi(2, VIH *0.9, VIL);
	setDpinVo(2, VIH * 0.9);
	setDpinVt(2, (VIH *0.9+ VIL) / 2);

	setDpinVi(3, VIH *1.1, VIL);
	setDpinVo(3, VIH * 1.1);
	setDpinVt(3, (VIH *1.1 + VIL) / 2);
}

void setLevel_normal(double Dpin)
{
	setDpinVi(1, VIH, VIL);
	setDpinVo(1, Dpin);
	setDpinVt(1, (VIH + VIL) / 2);

	setDpinVi(2, VIH *0.9, VIL);
	setDpinVo(2, Dpin * 0.9);
	setDpinVt(2, (VIH *0.9+ VIL) / 2);

	setDpinVi(3, VIH *1.1, VIL);
	setDpinVo(3, Dpin * 1.1);
	setDpinVt(3, (VIH *1.1 + VIL) / 2);
}

/*
   void setLevelHigh()
   {
   setVs(VSNO_VCC,VCC_HIGH, R4V, M400mA , 400 MA, -200 MA);
   setDpinVi(1, VCC_HIGH, 0.0);
   setDpinVo(1, VCC_HIGH/2);
   setDpinVt(1, VCC_HIGH/2);
   }


   void setLevelLow()
   {
   setVs(VSNO_VCC,VCC_LOW, R4V, M400mA , 400 MA, -200 MA);
   setDpinVi(1, VCC_LOW, 0.0);
   setDpinVo(1, VCC_LOW/2);
   setDpinVt(1, VCC_LOW/2);
   }
   */
void setDpinVt(int no, double vt)
{
	VtHandle hVt = UTL_GetVtHandle();
	UTL_SetVt(hVt, vt);
	UTL_SendVt(hVt, no);
	UTL_DeleteHandle(hVt);
}
void setDpinVo(int no, double vo)
{
	VoHandle hVo = UTL_GetVoHandle();
	UTL_SetVoHigh(hVo, vo * 0.7);
	UTL_SetVoLow(hVo, vo * 0.3);
	UTL_SendVo(hVo, no);
	UTL_DeleteHandle(hVo);
}

void setDpinVi(int no, double vih, double vil)
{
	ViHandle hVi = UTL_GetViHandle();
	UTL_SetViHigh(hVi, vih);
	UTL_SetViLow(hVi, vil);
	UTL_SendVi(hVi, no);
	UTL_DeleteHandle(hVi);
}

void setDpinVload(int no, double vl)
{
	VloadHandle hVl = UTL_GetVloadHandle();
	UTL_SetVload(hVl, vl);
	UTL_SendVload(hVl, no);
	UTL_DeleteHandle(hVl);
}

void setDpinVihh(int no, int sig, double vihh, double vih, double vil)
{
	VihhMutHandle hVihhMut = UTL_GetVihhMutHandle();
	UTL_SetVihhMutSignal(hVihhMut, sig);
	UTL_SendVihhMut(hVihhMut);
	UTL_DeleteHandle(hVihhMut);

	VihhHandle hVihh = UTL_GetVihhHandle();
	UTL_SetVihhHv(hVihh, vihh);
	UTL_SetVihhHigh(hVihh, vih);
	UTL_SetVihhLow(hVihh, vil);
	UTL_SendVihh(hVihh, no);
	UTL_DeleteHandle(hVihh);
}
