#!/bin/bash

ctags -R .;
cd patterns ;
trans pat_SRAM.asc ;
cd .. ;
make onm ;
fscd .;
fsproset main
fsconf --socket-file SRAM_BD.soc;
fsproreset;
fsclear
fssymbol -stn 1 -a ATFBM1 LOG_WFB
fsra-start-rdpp ${ATFSSYSTEM}/${ATFSWFBREAD}/bin/utwfb_rdpp

fsra-start-rsp ${ATFSSYSTEM}/${ATFSWFBREAD}/bin/utwfb_rsp
#fssdut --disable-all --enable 1;
#fsprostart --session fsdiag_1 &
