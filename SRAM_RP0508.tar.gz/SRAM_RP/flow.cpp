#include "main.h"

void TestFlow()
{
	int id = 0;
	Print("###########################  Test Begin ############################\n");
	//     Label	, Function, Test Name,  pre_exec, post_exec,P Branch,F Branch	, Bin
//dc
	RUN_TEST(++id, tb_OpenShort,	 "Continuity", Dummy, Dummy, NEXT, STOP, id);  // if(FK[1]) return;
	RUN_TEST(++id, tb_InputLeakage,	 "Input_Leakage", Dummy, Dummy, NEXT, STOP, id);
        RUN_TEST(++id, tb_PowerShort,	 "PowerShort", Dummy, Dummy, NEXT, STOP, id);
//static
//	RUN_TEST(++id, tb_Static_Current_gl,"Static_Power_Check_gl_clk", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Static_Current_gl_nclk,"Static_Power_Check_gl_nclk", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Static_Current,"Static_Power_Check", Dummy, Dummy, NEXT, NEXT, id);
//dynamic
	RUN_TEST(++id, tb_Dynamic_Current_WRITE, "Dynamic_Power_Check_Write", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Dynamic_Current_READ, "Dynamic_Power_Check_Read", Dummy, Dummy, NEXT, NEXT, id);

//io vmin
	RUN_TEST(++id, tb_IO_VDDmin_DVDD,"IO_VDDmin_Mode1", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_IO_VDDmin_All, "IO_VDDmin_Mode2", Dummy, Dummy, NEXT, NEXT, id);
//march
	RUN_TEST(++id, tb_Normal_Mode_VDD1P2_1MHz, "NormalMode_VDDNom_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Normal_Mode_VDD1P32_1MHz, "NormalMode_VDDMax_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Normal_Mode_VDD0P96_1MHz, "NormalMode_VDDMin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
//bist
	RUN_TEST(++id, tb_Bist_Mode_VDD1P32_1MHz, "BIST_Mode_VDDMax_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Bist_Mode_VDD1P08_1MHz, "BIST_Mode_VDDMin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Bist_Mode_VDD1P2_1MHz, "BIST_Mode_VDDNom_1MHz", Dummy, Dummy, NEXT, STOP, id);
//	RUN_TEST(++id, tb_Bist_Mode_VDD1P2_5MHz, "BIST_Mode_VDDNom_5MHz", Dummy, Dummy, NEXT, NEXT, id);
//vmin
	RUN_TEST(++id, tb_Retention1M , "Retention_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Readmin_1M , "Read_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Writemin_1M , "Write_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Writemin_1M_IW , "Write_Vmin_1MHz_IW", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Flipmin_1M , "Flip_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_March_VDDmin, "MarchY_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
	RUN_TEST(++id, tb_Bist_VDDmin, "BIST_Vmin_1MHz", Dummy, Dummy, NEXT, NEXT, id);
//dynamic
//	RUN_TEST(++id, tb_Dynamic_Current_WRITE, "Dynamic_Power_Check_Write", Dummy, Dummy, NEXT, NEXT, id);
//	RUN_TEST(++id, tb_Dynamic_Current_READ, "Dynamic_Power_Check_Read", Dummy, Dummy, NEXT, NEXT, id);
}
