#include "main.h"
#include <stdarg.h>
#include <string.h>
#include <assert.h>
void ulDisableFcm()
{
	FcmConfigHandle h = UTL_GetFcmConfigHandle();
	UTL_AddFcmConfigAction(h, 1, UT_FCM_DISABLE);
	UTL_SendFcmConfig(h);
	UTL_DeleteHandle(h);
}
// sample: ulConfigFcm("SO", 8, 3, FCM_AF, 8192);
void ulConfigFcm(char *pinlist, int xbit, int ybit, enum FcmAction action)
{
	int data_bit=0, addr_bit=0, ad=0;
	FcmConfigHandle h = UTL_GetFcmConfigHandle();

	MAC_LOOPPIN_START(pinlist)
		UTL_AddFcmConfigPinAssign(h, data_bit++, pin);
	MAC_LOOPPIN_STOP
		UTL_SetFcmConfigBitSize(h, data_bit);
	UTL_SetFcmConfigDutBitSize(h, data_bit);

	for (ad = 0; ad < ybit; ad++)
	{
		UTL_SetFcmConfigAddrAssign(h, addr_bit++, UT_SIG_Y(ad));
	}
	for (ad = 0; ad < xbit; ad++)
	{
		UTL_SetFcmConfigAddrAssign(h, addr_bit++, UT_SIG_X(ad));
	}
	UTL_SetFcmConfigPinAssignTarget(h, UT_FCM_FLEX_PINASSIGN);

	if (action == FCM_AF)
	{
		UTL_AddFcmConfigAction(h, 1, UT_FCM_AF);
		UTL_SetFcmConfigStoreSignalByMMType(h, UT_FCM_AF, UT_SIG_MM);
	}
	else if (action == FCM_BF)
	{
		UTL_AddFcmConfigAction(h, 1, UT_FCM_BF);
		UTL_SetFcmConfigStoreSignalByMMType(h, UT_FCM_BF, UT_SIG_MM);
	}
	else if (action == FCM_TOTALFAIL)
	{	
		UTL_AddFcmConfigAction(h, 1, UT_FCM_TOTALFAIL);
	}
	else if (action == FCM_DISABLE)
	{	
		UTL_AddFcmConfigAction(h, 1, UT_FCM_DISABLE);
	}

	UTL_SetFcmConfigRate(h, UT_FCM_LS);
	UTL_SendFcmConfig(h);
	UTL_DeleteHandle(h);
}


// sample: ulConfigFcm("SO", FCM_AF, 8192, "X0-X7", "Y0-Y2",NULL);
void ulConfigFcm(char *pinlist, enum FcmAction action,  ...)
{
	int xbit[24], ybit[24];
	int data_bit=0, addr_bit=0, ad=0;
	FcmConfigHandle h = UTL_GetFcmConfigHandle();
	
	MAC_LOOPPIN_START(pinlist)
		UTL_AddFcmConfigPinAssign(h, data_bit++, pin);
	MAC_LOOPPIN_STOP
	UTL_SetFcmConfigBitSize(h, data_bit);
	UTL_SetFcmConfigDutBitSize(h, data_bit);

	va_list va;
	char   *ap;
	va_start(va, action);
	while((ap = va_arg(va, char *))!= NULL)
	{
		if((strstr(ap,"Y")-ap)==0&&strstr(ap,"X")==NULL){
			int count = parse_xylist(ap, 'Y', ybit);
			for (ad = 0; ad < count; ad++)
			{
				UTL_SetFcmConfigAddrAssign(h, addr_bit++, UT_SIG_Y(ybit[ad]));
			}
		}else if((strstr(ap,"X")-ap)==0&&strstr(ap,"Y")==NULL){
			int count = parse_xylist(ap, 'X', xbit);
			for (ad = 0; ad < count; ad++)
			{
				UTL_SetFcmConfigAddrAssign(h, addr_bit++, UT_SIG_X(xbit[ad]));
			}
		}
		else{
			ErrorStop("%s, %s, line%d: please input the correct X/Y address\n", __FILE__, __FUNCTION__, __LINE__);
		}
	}
	va_end(va);

//	UTL_SetFcmConfigPinAssignTarget(h, UT_FCM_FLEX_PINASSIGN);
	UTL_SetFcmConfigPinAssignTarget(h, UT_FCM);

	if (action == FCM_AF)
	{
		UTL_AddFcmConfigAction(h, 1, UT_FCM_AF);
		UTL_SetFcmConfigStoreSignalByMMType(h, UT_FCM_AF, UT_SIG_MM);
	}
	else if (action == FCM_BF)
	{
		UTL_AddFcmConfigAction(h, 1, UT_FCM_BF);
		UTL_SetFcmConfigStoreSignalByMMType(h, UT_FCM_BF, UT_SIG_MM);
	}
	else if (action == FCM_TOTALFAIL)
	{	
		UTL_AddFcmConfigAction(h, 1, UT_FCM_TOTALFAIL);
	}
	else if (action == FCM_DISABLE)
	{	
		UTL_AddFcmConfigAction(h, 1, UT_FCM_DISABLE);
	}

	UTL_SetFcmConfigRate(h, UT_FCM_LS);
	UTL_SendFcmConfig(h);
	UTL_DeleteHandle(h);
}

void ulPresetFcm()
{
	FcmAccessHandle h = UTL_GetFcmAccessHandle();
	UTL_SetFcmAccessAutoAddrAssignMode(h, UT_ON);
	UTL_SetFcmAccessAllBit            (h, UT_ON);
	UTL_SetFcmAccessAllDut            (h, UT_ON);
	UTL_SetFcmAccessPresetAllMemory   (h, UT_OFF);
//	UTL_SetFcmAccessPresetMemoryInUse (h, UT_ON);//Only support after R6.41, this function can optimize the time of preset
	UTL_PresetFcm                     (h, 0);	
	UTL_DeleteHandle(h);
}

void ulPresetFcmAll()
{
	FcmAccessHandle h = UTL_GetFcmAccessHandle();
	UTL_SetFcmAccessAutoAddrAssignMode(h, UT_ON);
	UTL_SetFcmAccessAllBit            (h, UT_ON);
	UTL_SetFcmAccessAllDut            (h, UT_ON);
	UTL_SetFcmAccessPresetAllMemory   (h, UT_ON);
	UTL_PresetFcm                     (h, 0);
	UTL_DeleteHandle(h);
}

//sample: ulReadFcm(fcm_data, 8*8, 0, 7, 0, 7, dut, UT_FCM_APLINK_YXZ,1);
void ulReadFcm(unsigned int *data, int size, int x_st, int x_sp, int y_st, int y_sp, int dut, RadioButton aplink,USlider bitblock)
{
	assert ( data != NULL);
	assert ( x_sp>=x_st && x_st>=0);
	assert ( y_sp>=y_st && y_st>=0);
	int actual_size = ( x_sp - x_st +1) * ( y_sp - y_st +1 );
	assert ( size >= actual_size);

	FcmAccessHandle h = UTL_GetFcmAccessHandle();

	UTL_SetFcmAccessBitMode(h,UT_FCM_BITMODE_BLOCK);
	UTL_SetFcmAccessBitBlock(h,bitblock);

	UTL_SetFcmAccessAutoAddrAssignMode(h, UT_ON);
	UTL_SetFcmAccessApLink(h, aplink);
	UTL_SetFcmAccessAction(h, 1);
	UTL_SetFcmAccessAllBit(h, UT_OFF);
	UTL_SetFcmAccessAllDut(h, UT_OFF);
	UTL_SetFcmAccessDut  (h, dut);
	UTL_SetFcmAccessXAddr(h, x_st, x_sp);
	UTL_SetFcmAccessYAddr(h, y_st, y_sp);
	// UTL_ReadFcm(h, data, actual_size * );
	UTL_ReadFcm(h, data, actual_size * sizeof(unsigned int));
	UTL_DeleteHandle(h);
}

//sample: ulGetFcmPfcByCount(0, 15, 0, 7, pfc_count);
void ulGetFcmPfcByCount(int x_start, int x_end, int y_start, int y_end, USlider *count) 
{
	FcmAccessHandle h = UTL_GetFcmAccessHandle();
	UTL_SetFcmAccessAction(h, 1);
	UTL_SetFcmAccessAutoAddrAssignMode(h, UT_ON);
	UTL_SetFcmAccessPfcMode(h,UT_FCM_PFCMODE_BYCOUNT);
//	UTL_SetFcmAccessAllDut(h, UT_ON);
	UTL_SetFcmAccessAllDut(h, UT_OFF);

	UTL_SetFcmAccessAllBit(h, UT_OFF);
	UTL_SetFcmAccessXAddr(h, x_start, x_end);
	UTL_SetFcmAccessYAddr(h, y_start, y_end);
	UTL_SetFcmAccessApLink(h, UT_FCM_APLINK_YXZ);
	UTL_ParallelFailCountFcm(h);
	MAC_LOOPDUT_START(UT_CDUT)
		UTL_SetFcmAccessDut(h, dut);
		if(UTL_GetFcmParallelFailCountOverflow(h) == UT_OFF)
				count[dut-1]=UTL_GetFcmParallelFailCount(h);
		else
				Print("\t#Parallel Fail Count OverFlow!!!\n");
	MAC_LOOPDUT_STOP
	UTL_DeleteHandle(h);
}


void ConvertFcmDataToByte(unsigned int *data, unsigned int *fcm_data, int bit_size, int start_byte, int stop_byte){
	int i = 0, byte_size = stop_byte-start_byte+1;
	if(bit_size==1){
		for(i = 0; i<byte_size; i++){
			data[i]=((fcm_data[8*i+0] & 0x1) << 7) | ((fcm_data[8*i+1] & 0x1) << 6) |
				((fcm_data[8*i+2] & 0x1) << 5) | ((fcm_data[8*i+3] & 0x1) << 4) |
				((fcm_data[8*i+4] & 0x1) << 3) | ((fcm_data[8*i+5] & 0x1) << 2) |
				((fcm_data[8*i+6] & 0x1) << 1) | ((fcm_data[8*i+7] & 0x1) << 0) ;
		} 
	} else if(bit_size == 2){
		for(i=0; i<byte_size; i++) {
			data[i]=((fcm_data[4*i+0] & 0x3) << 6) | ((fcm_data[4*i+1] & 0x3) << 4) |
				((fcm_data[4*i+2] & 0x3) << 2) | ((fcm_data[4*i+3] & 0x3) << 0) ;
		}
	} else if(bit_size == 4){
		for(i=0; i<byte_size; i++) {
			data[i]=((fcm_data[2*i+0] & 0xf) << 4) | ((fcm_data[2*i+1] & 0xf) << 0) ;
		}
	}
}

void ulPresetCfm()
{
	CfmAccessHandle h = UTL_GetCfmAccessHandle();
	UTL_SetCfmAccessAllBit            (h, UT_ON);
	UTL_SetCfmAccessAllDut            (h, UT_ON);
	UTL_SetCfmAccessPresetAllMemory   (h, UT_ON);
	UTL_PresetCfm                     (h, 0);
	UTL_DeleteHandle(h);
}

void ulConfigFcmCfmPinFlex(){
	FcmConfigHandle h = UTL_GetFcmConfigHandle();
	UTL_AddFcmConfigAction(h, 1, UT_FCM_DISABLE);
	UTL_SetFcmConfigPinAssignTarget(h,UT_FCM_FLEX_PINASSIGN);
	UTL_ClearFcmConfigPinAssign(h);
	UTL_SendFcmConfig(h);
	UTL_DeleteHandle(h);
}
//sample: ulConfigCfm("SO", FCM_TOTALFAIL, "X0-X7", "Y0-Y2",NULL);
void ulConfigCfm(char *pinlist, enum FcmAction action, ...)
{
	int xbit[24], ybit[24];
	int data_bit=0, addr_bit=0, ad=0;
	CfmConfigHandle h = UTL_GetCfmConfigHandle();

	MAC_LOOPPIN_START(pinlist)
		UTL_AddCfmConfigPinAssign(h, data_bit++, pin);
	MAC_LOOPPIN_STOP
	UTL_SetCfmConfigBitSize(h, data_bit);
	UTL_SetCfmConfigDutBitSize(h, data_bit);

	va_list va;
	char   *ap;
	va_start(va, action);
	while((ap = va_arg(va, char *))!= NULL)
	{
		if((strstr(ap,"Y")-ap)==0&&strstr(ap,"X")==NULL){
			int count = parse_xylist(ap, 'Y', xbit);
			for (ad = 0; ad < count; ad++)
			{
				UTL_SetCfmConfigAddrAssign(h, addr_bit++, UT_SIG_Y(xbit[ad]));
			}
		}else if((strstr(ap,"X")-ap)==0&&strstr(ap,"Y")==NULL){
			int count = parse_xylist(ap, 'X', ybit);
			for (ad = 0; ad < count; ad++)
			{
				UTL_SetCfmConfigAddrAssign(h, addr_bit++, UT_SIG_X(ybit[ad]));
			}
		}
		else{
			ErrorStop("%s, %s, line%d: please input the correct X/Y address\n", __FILE__, __FUNCTION__, __LINE__);
		}
	}
	va_end(va);

	if (action == FCM_AF)
	{
		UTL_AddCfmConfigAction(h, 1, UT_FCM_AF);
		UTL_SetCfmConfigStoreSignalByMMType(h, UT_FCM_AF, UT_SIG_MM);
	}
	else if (action == FCM_BF)
	{
		UTL_AddCfmConfigAction(h, 1, UT_FCM_BF);
		UTL_SetCfmConfigStoreSignalByMMType(h, UT_FCM_BF, UT_SIG_MM);
	}
	else if (action == FCM_TOTALFAIL)
	{	
		UTL_AddCfmConfigAction(h, 1, UT_FCM_TOTALFAIL);
	}
	else if (action == FCM_DISABLE)
	{	
		UTL_AddCfmConfigAction(h, 1, UT_FCM_DISABLE);
	}

	UTL_SendCfmConfig(h);
	UTL_DeleteHandle(h);
}

//sample: ulReadCfm(data, 16*8, 0, 15, 0, 7, dut, UT_FCM_APLINK_YXZ);
void ulReadCfm(unsigned int *data, int size, int x_st, int x_sp,int y_st, int y_sp, int dut, RadioButton aplink)
{
	int bit, ad,xtemp=0,ytemp=0,x_sizebits=0,y_sizebits=0;
	bit = 0;
	assert ( data != NULL );
	assert ( x_sp>=x_st && x_st>=0 );
	assert ( y_sp>=y_st && y_st>=0 );
	int actual_size = ( x_sp - x_st +1 ) * ( y_sp - y_st +1 );
	assert ( size >= actual_size );
	
	xtemp=x_sp - x_st ;
	ytemp=y_sp - y_st ;
	while(xtemp!=0)
	{
		x_sizebits++;
		xtemp=xtemp>>1;
	}
	while(ytemp!=0)
	{
		y_sizebits++;
		ytemp=ytemp>>1;
	}
	
//--printf("x_sizebits=%d,y_sizebits=%d\n",x_sizebits,y_sizebits);

	CfmAccessHandle h = UTL_GetCfmAccessHandle();
	for ( ad = 0; ad < y_sizebits; ad++)
	{
		UTL_SetCfmAccessAddrAssign(h, bit++, UT_SIG_Y(ad));
	}
	for ( ad = 0; ad < x_sizebits; ad++)	
	{
		UTL_SetCfmAccessAddrAssign(h, bit++, UT_SIG_X(ad));
	}
	UTL_SetCfmAccessApLink(h, aplink);
	UTL_SetCfmAccessAction  (h, 1);
	UTL_SetCfmAccessBitBlock(h, 1);
	UTL_SetCfmAccessBitMode (h, UT_FCM_BITMODE_BLOCK); 
	UTL_SetCfmAccessAllBit  (h, UT_ON);  

	UTL_SetCfmAccessDut  (h, dut);
	UTL_SetCfmAccessXAddr(h, x_st, x_sp);
	UTL_SetCfmAccessYAddr(h, y_st, y_sp);
	UTL_ReadCfm(h, data, actual_size * sizeof(unsigned int));
	UTL_DeleteHandle(h);
}
