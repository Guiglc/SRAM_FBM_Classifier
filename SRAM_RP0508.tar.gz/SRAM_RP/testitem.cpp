#include "main.h"
#include "atfswfbread.h"
WfbHandle wfbh;

const USlider Data0 = 0X00000000;
const USlider DataF = 0XFFFFFFFF;
const USlider Data5 = 0X55555555;
const USlider DataA = 0XAAAAAAAA;
int wfbfail1(void);
/*###################################################################### DC Test ########################################################################### */
/*
 * tb_OpenShort
 * tb_PowerShort
 * tb_OutputLeakage
 * tb_InputLeakage
 * tb_ISB
 * tb_IDD_Write
 * tb_IDD_Read
 * tb_IDD
 */

void tb_OpenShort()
{

#if 0
	setVSLevel(1.2,1.2, 1.2, 1.2, 1.2); // Ground All Power Pins
	setLevel();
	setPinFmt();
	setTiming1MHz();
	UTL_OnPowerSeq();UTL_SetWet();
	run_alpg_pattern("pat_SRAM.mpa", "DEBUG_FIXH");
#endif

	setVSLevel(VGND, VGND, VGND, VGND, VGND); // Ground All Power Pins
	setDpinFixL("ALLPINS", 1, VIH, VIL);	  // Ground All Digital Pins
	/* Lower Diode Open&Short Test*/
	setDcISVM(OS_LOWER_FORCE_CURRENT, R200uA, Rm20V, OS_LOWER_PCLAMP, OS_LOWER_NCLAMP, OS_LOWER_HIGH_LIMIT, OS_LOWER_LOW_LIMIT, MEASURE_CNT);
	UTL_OnPowerSeq();UTL_SetWet();
	MeasPin("OSPINS");
	Print("------------------Lower OS TestResult:------------------\n");
	PrintMeasData("OSPINS", "Continuity_High", 1 V, "V");
	UTL_OffPowerSeq();UTL_ResetWet();
	/* Upper Diode Open&Short Test*/

	setVSLevel(VGND, VGND, VGND, VGND, VGND); // Ground All Power Pins

	setDcISVM(OS_UPPER_FORCE_CURRENT, R200uA, R20V, OS_UPPER_PCLAMP, OS_UPPER_NCLAMP, OS_UPPER_HIGH_LIMIT, OS_UPPER_LOW_LIMIT, MEASURE_CNT);
	setDpinFixL("ALLPINS", 1, VIH, VIL);	  // Ground All Digital Pins
	UTL_OnPowerSeq();UTL_SetWet();
	MeasPin("OSPINS");
	Print("\n------------------Upper OS TestResult:------------------\n");
	PrintMeasData("OSPINS", "Continuity_Low", 1 V, "V");
	UTL_OffPowerSeq();UTL_ResetWet();
}



void tb_PowerShort()

{
#if 0
	setVSLevel(1.2, 1.2, 1.2, 1.2, 1.2); // Ground All Power Pins
	UTL_OnPowerSeq();UTL_SetWet();

#endif
#if 1
	setVSLevel(0, 0, 0, 0, 0); // Ground All Power Pins
	UTL_WaitTime(200e-3);
	//	setVSLevelMeas_PowerShort(VGND + 0.1 V, VGND , VGND, VGND , VGND , PS_HIGH_LIMIT,PS_LOW_LIMIT, MEASURE_CNT);
	setVSLevelMeas_PowerShort(VGND + 0.1 V, VGND + 0.1 V, VGND + 0.1 V, VGND + 0.1 V, VGND + 0.1 V, PS_HIGH_LIMIT,PS_LOW_LIMIT, MEASURE_CNT);
	setDpinFixL("INPUTPINS", 1, VIH, VIL);	  // Ground Input Digital Pins
	setDpinOpen("OUTPINS");		   // Set Outpins Open
	//		setDpinFixL("OUTPINS",1,VIH,VIL);		   // Set Outpins Open
	UTL_OnPowerSeq();UTL_SetWet();

	//	run_alpg_pattern("pat_SRAM.mpa", "DEBUG_FIXH");
	UTL_WaitTime(200e-3);
	MeasPin("VDD");
	MeasPin("VDDM");
	MeasPin("VDDM1");
	MeasPin("VDDM2");
	MeasPin("DVDD");
	Print("\n------------------Power Short  TestResult:------------------\n");
	PrintMeasData("POWERPINS", "PowerShort", 1 NA, "nA");

	UTL_OffPowerSeq();UTL_ResetWet();
#endif
}


void tb_InputLeakage()
{
	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setDpinOpen("OUTPUT_LEAKAGEPINS");		   // Set Outpins Open
	setDpinFixH("INPUT_LEAKAGEPINS", 1, VIH, VIL); // Fix High to  All Input Pins
	setDcVSIM(VIL, R20V, R5uA, IIHL_PCLAMP, IIHL_NCLAMP, IIHL_HIGH_LIMIT, IIHL_LOW_LIMIT, MEASURE_CNT);
	UTL_OnPowerSeq();UTL_SetWet();
	MeasPin("INPUT_LEAKAGEPINS");
	Print("\n------------------Input Pins Leakage Low TestResult:------------------\n");
	PrintMeasData("INPUT_LEAKAGEPINS", "Input_Leakage_IIL", 1 UA, "UA");
	UTL_OffPowerSeq();UTL_ResetWet();
	setDpinFixL("INPUT_LEAKAGEPINS", 1, VIH, VIL); // Fix Low to All Input Pins
	setDcVSIM(VIH, R20V, R5uA, IIHL_PCLAMP, IIHL_NCLAMP, IIHL_HIGH_LIMIT, IIHL_LOW_LIMIT, MEASURE_CNT);
	UTL_OnPowerSeq();UTL_SetWet();
	MeasPin("INPUT_LEAKAGEPINS");
	Print("\n------------------Input Pins Leakage High TestResult:------------------\n");
	PrintMeasData("INPUT_LEAKAGEPINS", "Input_Leakage_IIH", 1 UA, "UA");
	UTL_OffPowerSeq();UTL_ResetWet();
}
void tb_Static_Current_gl_nclk()
{
	Print("\n------------------StandBy ISB GL TestResult:------------------\n");
	setDpinVi(1, 1.2, 0);
	setDpinVo(1, 1.2);
	setDpinVt(1, (1.2 - 0) / 2);
	//	setPinFmt();
	setPinFmt_vmin();
	setTiming();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setSettlingTime(10 MS, 50 MS, 10 MS);
	UTL_OnPowerSeq();UTL_SetWet();
	run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_WGL_NCLK");

	setDpinFixL("INPUTPINS",1,VIH,VIL);
	setDpinOpen("OUTPINS");				 // Set Outpins Open
	setDpinFixH("RN", 1, VIH, VIL); // Fix Low to All Input Pins
	setDpinFixH("CEN", 1, VIH, VIL);	 // Fix Low to 
	setVSLevelMeas_ISB(VDD, VDDM, VDDM1, VDDM2, DVDD, MEASURE_CNT);

	UTL_WaitTime(20e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1","Static_Power_Check_DUMMY", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "Static_Power_Check_DUMMY", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDD");
	PrintMeasData("VDD",  "Static_Power_Check_DUMMY", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2","Static_Power_Check_DUMMY", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM");
	PrintMeasData("VDDM", "Static_Power_Check_DUMMY", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	UTL_OffPowerSeq();UTL_ResetWet();


}




void tb_Static_Current_gl()
{
	Print("\n------------------StandBy ISB GL TestResult:------------------\n");
	setDpinVi(1, 1.2, 0);
	setDpinVo(1, 1.2);
	setDpinVt(1, (1.2 - 0) / 2);
	//	setPinFmt();
	setPinFmt_vmin();
	setTiming();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setSettlingTime(10 MS, 50 MS, 10 MS);
	UTL_OnPowerSeq();UTL_SetWet();
	run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_WGL");

	setDpinFixL("INPUTPINS",1,VIH,VIL);
	setDpinOpen("OUTPINS");				 // Set Outpins Open
	setDpinFixH("RN", 1, VIH, VIL); // Fix Low to All Input Pins
	setDpinFixH("CEN", 1, VIH, VIL);	 // Fix Low to 
	setVSLevelMeas_ISB(VDD, VDDM, VDDM1, VDDM2, DVDD, MEASURE_CNT);

	UTL_WaitTime(20e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1","Static_Power_Check_DUMMY_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "Static_Power_Check_DUMMY_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDD");
	PrintMeasData("VDD",  "Static_Power_Check_DUMMY_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2","Static_Power_Check_DUMMY_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM");
	PrintMeasData("VDDM", "Static_Power_Check_DUMMY_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	UTL_OffPowerSeq();UTL_ResetWet();
}

void tb_Static_Current()
{
	Print("\n------------------StandBy ISB TestResult:------------------\n");

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setDpinFixL("INPUTPINS",1,VIH,VIL);
	setDpinOpen("OUTPINS");				 // Set Outpins Open
	setDpinFixH("RN", 1, VIH, VIL); // Fix Low to All Input Pins
	setDpinFixH("CEN", 1, VIH, VIL);	 // Fix Low to All Input Pins
	setSettlingTime(10 MS, 50 MS, 10 MS);
	UTL_OnPowerSeq();UTL_SetWet();
	setVSLevelMeas_ISB(VDD, VDDM, VDDM1, VDDM2, DVDD, MEASURE_CNT);

	UTL_WaitTime(20e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1","Static_Power_Check_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "Static_Power_Check_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDD");
	PrintMeasData("VDD",  "Static_Power_Check_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2","Static_Power_Check_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM");
	PrintMeasData("VDDM", "Static_Power_Check_VDDnom", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	UTL_OffPowerSeq();UTL_ResetWet();
}
void tb_IO_VDDmin_DVDD()
{
	double Power = 1.2;					   // 起始电压（高）
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
	int i;
	int remaining = 0; // 仍在等待 FAIL 的 DUT 数
	/* 初始化 done / Vmin / remaining */
	Print("\n------------IO_VDDmin_Mode1_TestResult:---------------\n");
	while ((Power >= VminLimit) )
	{
		setDpinVi(1, Power, 0);
		setDpinVo(1, Power);
		setDpinVt(1, (Power - 0) / 2);
		setPinFmt();
		setTiming();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, Power); // 根据你原来的接口参数调整
		UTL_WaitTime(20e-3);
		run_alpg_pattern("pat_SRAM.mpa", "TESTOUT_PIN_TEST");
		UTL_OffPowerSeq();UTL_ResetWet();

		UT_DUT d = 1;
		int res = UTL_ReadMeasResult(d);

		if (res == UT_RES_FAILED)
		{
			/* 记录、打印、加入 exclusion（保留你的逻辑） */
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
			break;
			/* 记录上一次通过电压为 Vmi */
			//			Vmin[i] = Power + PowerDrop;

			//			done[i] = 1;
			//			remaining--;

		}
		else /* PASS */
		{
			printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
		}

		Power -= PowerDrop;
	} /* end while sweep */

}




void tb_IO_VDDmin_All()


{	double Power = 1.2;					   // 起始电压（高）
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
	int i;
	int remaining = 0; // 仍在等待 FAIL 的 DUT 数
	/* 初始化 done / Vmin / remaining */
	Print("\n------------IO_VDDmin_Mode2_TestResult:---------------\n");
	while ((Power >= VminLimit) )
	{
		setDpinVi(1, Power, 0);
		setDpinVo(1, Power);
		setDpinVt(1, (Power - 0) / 2);
		setPinFmt();
		setTiming();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(Power, Power, Power, Power, Power); // 根据你原来的接口参数调整
		UTL_WaitTime(20e-3);
		run_alpg_pattern("pat_SRAM.mpa", "TESTOUT_PIN_TEST");
		UTL_OffPowerSeq();UTL_ResetWet();

		UT_DUT d = 1;
		int res = UTL_ReadMeasResult(d);

		if (res == UT_RES_FAILED)
		{
			/* 记录、打印、加入 exclusion（保留你的逻辑） */
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
			break;
			/* 记录上一次通过电压为 Vmi */
			//			Vmin[i] = Power + PowerDrop;

			//			done[i] = 1;
			//			remaining--;

		}
		else /* PASS */
		{
			printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
		}

		Power -= PowerDrop;
	} /* end while sweep */

}















void tb_Normal_Mode_VDD1P08_250KHz()
{
	setLevel_normal(1.08 V);
	setPinFmt();
	setTiming250KHz();

	//setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //
	setVSLevel(VDD_1P08, VDDM_1P08, VDDM1_1P08, VDDM2_1P08, DVDD_1P08);

	//run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");

	Func_FCM(Data0, "MATCHY_TEST");
}
void tb_Normal_Mode_VDD1P08_1MHz()
{

	setLevel_normal(1.08 V);
	setPinFmt();
	setTiming1MHz();


	setVSLevel(VDD_1P08, VDDM_1P08, VDDM1_1P08, VDDM2_1P08, DVDD_1P08);
	Print("\n------------------debug wr  TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(1000e-3);
	Func_FCM(Data0, "MARCHY_TEST");
	Print("\n------------------FUNC MatchCPLUS TestResult Condition1p08:------------------\n");

}
void tb_Normal_Mode_VDD1P2_250KHz()
{
	setLevel();
	setPinFmt();
	setTiming250KHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //

	//run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");

	Func_FCM(Data0, "MATCHY_TEST");
}
void tb_Normal_Mode_VDD1P32_1MHz()
{
	float Power=1.32;
	setLevel_normal(Power);
	setPinFmt();
	setTiming1MHz();
	setVSLevel(Power,Power,Power,Power,Power); //
	//setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //
	//   	if(0 !=wfbhandle()){
	//	        if(wfbh>=0)UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD_ERROR_STOP\n");
	//UTL_Stop();
	//  	}
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");
	Print("\n------------------Normal_Mode_VDD1P32_1MHz TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(10e-3);
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	UTL_OnPowerSeq();UTL_SetWet();UTL_WaitTime(10 MS);
	//	run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	Func_FCM(Data0, "P_READ");

	Func_FCM(Data0, "MARCHY_TEST");
	//	Func_FCM(Data0, "MATCHY_TEST");

	//	if(0 != wfbfail1()){
	//		if(wfbh>=0) UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD ERROR STOP\n");
	//		UTL_Stop();
	//	}
	//	UTWFB_DeleteHandle(wfbh);


}
void tb_Normal_Mode_VDD1P2_1MHz()
{
	float Power=1.2;
	setLevel_normal(Power);
	setPinFmt();
	setTiming1MHz();
	setVSLevel(Power,Power,Power,Power,Power); //
	//setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //
	//   	if(0 !=wfbhandle()){
	//	        if(wfbh>=0)UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD_ERROR_STOP\n");
	//UTL_Stop();
	//  	}
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");
	Print("\n------------------Normal_Mode_VDD1P2_1MHz TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(10e-3);
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	UTL_OnPowerSeq();UTL_SetWet();UTL_WaitTime(10 MS);
	//	run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	Func_FCM(Data0, "P_READ");

	Func_FCM(Data0, "MARCHY_TEST");
	//	Func_FCM(Data0, "MATCHY_TEST");

	//	if(0 != wfbfail1()){
	//		if(wfbh>=0) UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD ERROR STOP\n");
	//		UTL_Stop();
	//	}
	//	UTWFB_DeleteHandle(wfbh);


}

void tb_Normal_Mode_VDD0P96_1MHz()
{
	float Power=0.96;
	setLevel_normal(Power);
	setPinFmt();
	setTiming1MHz();
	setVSLevel(Power,Power,Power,Power,Power); //
	//setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //
	//   	if(0 !=wfbhandle()){
	//	        if(wfbh>=0)UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD_ERROR_STOP\n");
	//UTL_Stop();
	//  	}
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");
	Print("\n------------------Normal_Mode_VDD1P08_1MHz TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(10e-3);
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	UTL_OnPowerSeq();UTL_SetWet();UTL_WaitTime(10 MS);
	//	run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
	//	SetRegValue(UT_REG_TPH1,0X55555555);
	//	SetRegValue(UT_REG_TPH2,0X55555555);
	//	Func_FCM(Data0, "P_READ");

	Func_FCM(Data0, "MARCHY_TEST");
	//	Func_FCM(Data0, "MATCHY_TEST");

	//	if(0 != wfbfail1()){
	//		if(wfbh>=0) UTWFB_DeleteHandle(wfbh);
	//		printf("WFBREAD ERROR STOP\n");
	//		UTL_Stop();
	//	}
	//	UTWFB_DeleteHandle(wfbh);


}
int wfbhandle(void){
	int code;
	wfbh =UTWFB_GetHandle();
	if (wfbh ==0) return(1);
	code =UTWFB_SetJobMode(wfbh, UT_DEFWFB_JobMode_CHIP_NOWAIT);
	if (code!=0)  return(1);
	code =UTWFB_SetBaseTag(wfbh,"Basetag");
	if (code!=0)  return(1);
	code =UTWFB_EnterFunctionTag(wfbh,"MATCHY_TEST_");
	if (code!=0)  return(1);
	code =UTWFB_SetWaferNumber(wfbh, 10);
	if (code!=0)  return(1);
	code =UTWFB_SetProberAuto(wfbh, UT_ON);
	if (code!=0)  return(0);
}
int wfbfail1(void){
	int code;
	code =UTWFB_SetFunctionTag(wfbh,"MATCHY_TEST_");
	if (code!=0)  return(1);
	code =UTWFB_SetDutMode(wfbh, UT_DEFWFB_DutMode_CDUT);
	if (code!=0)  return(1);
	code =UTWFB_SetTargetAction(wfbh, 1);
	if (code!=0)  return(1);
	code =UTWFB_FailGet(wfbh);
	if (code!=0)  return(1);
	return(0);


}
void tb_Normal_Mode_VDD1P2_5MHz()
{
	setLevel_normal(1.2 V);
	setPinFmt();

	setTiming5MHz();
	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //

	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	//Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");
	Print("\n------------------debug wr  TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(1000e-3);
	Func_FCM(Data0, "MARCHY_TEST");


	Print("\n------------------FUNC MatchCPLUS TestResult Condition1P2 5MHz------------------\n");

}
void tb_Normal_Mode_VDD1P2_10MHz()
{
	setLevel();
	setPinFmt();
	setTiming10MHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //

	//run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");

	Func_FCM(Data0, "MATCHY_TEST");
}
void tb_Normal_Mode_VDD1P32_250KHz()
{
	setLevel();
	setPinFmt();
	setTiming250KHz();

	//setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); //
	setVSLevel(VDD_1P32, VDDM_1P32, VDDM1_1P32, VDDM2_1P32, DVDD_1P32);

	//run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");

	Func_FCM(Data0, "MATCHY_TEST");
}
#if 0
void tb_Normal_Mode_VDD1P32_1MHz()
{	setLevel_normal(1.32 V);
	setPinFmt();
	setTiming1MHz();


	setVSLevel(VDD_1P32, VDDM_1P32, VDDM1_1P32, VDDM2_1P32, DVDD_1P32);
	//	run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	run_alpg_pattern("pat_SRAM.mpa", "MATCHY_TEST");
	//Print("\n------------------FUNC MatchCPLUS TestResult:------------------\n");
	Print("\n------------------debug wr  TestResult:------------------\n");

	UTL_OnPowerSeq();UTL_SetWet();
	UTL_WaitTime(1000e-3);
	Func_FCM(Data0, "MARCHY_TEST");
	//	Func_FCM(Data0, "MATCHY_TEST");

	//		if(0 != wfbfail1()){
	//				if(wfbh>=0) UTWFB_DeleteHandle(wfbh);
	//				printf("WFBREAD ERROR STOP\n");
	//				UTL_Stop();
	//		}
	//		UTWFB_DeleteHandle(wfbh);


	Print("\n------------------FUNC MatchCPLUS TestResult:1p32 1M------------------\n");
}
#endif
void tb_Dynamic_Current_READ()
{
	Print("\n------------------Dynamic_Power_Check_Read TestResult:------------------\n");

	setLevel();
	setTiming1MHz();
	setPinFmt();
	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setSettlingTime(100 MS, 100 MS, 100 MS);
	setSamplingRate(1e-3);
	UTL_OnPowerSeq();UTL_SetWet();
	setVSLevelMeas_IDD(VDD, VDDM, VDDM1, VDDM2, DVDD, 70);
	start_alpg_pattern_nowait("pat_SRAM.mpa", "READ_CROSS");
	//		run_alpg_pattern("pat_SRAM.mpa", "WRITE_CROSS");
	//		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	start_alpg_pattern_nowait("pat_SRAM.mpa", "READ_CROSS");
	//	start_alpg_pattern_nowait("pat_SRAM.mpa", "MARCHY_TEST");
	UTL_WaitTime(200e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDD");
	PrintMeasData("VDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM");
	PrintMeasData("VDDM", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	UTL_StopFct();
	UTL_OffPowerSeq();UTL_ResetWet();
}




void tb_Dynamic_Current_WRITE()
{
	setLevel();
	setTiming1MHz();
	setPinFmt();
	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // Set Power Pins Voltages
	setVSLevelMeas_IDD(VDD, VDDM, VDDM1, VDDM2, DVDD, 700);
	setSettlingTime(100 MS, 100 MS, 100 MS);
	setSamplingRate(1e-3);
	UTL_OnPowerSeq();UTL_SetWet();

	start_alpg_pattern_nowait("pat_SRAM.mpa", "WRITE_CROSS");
	//		run_alpg_pattern("pat_SRAM.mpa", "WRITE_CROSS");
	//		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
	//	start_alpg_pattern_nowait("pat_SRAM.mpa", "READ_CROSS");
	//	start_alpg_pattern_nowait("pat_SRAM.mpa", "MARCHY_TEST");
	Print("\n------------------Dynamic_Power_Check_Write TestResult:------------------\n");

	MeasPin("VDDM1");
	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");

	UTL_WaitTime(200e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(200e-3);
	//	
	////	UTL_WaitTime(20e-3);
	MeasPin("VDD");
	PrintMeasData("VDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(200e-3);
	////	UTL_WaitTime(20e-3);
	//
	////	MeasPin("VDDM1");
	////	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");
	////
	MeasPin("VDDM2");
	PrintMeasData("VDDM2", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(200e-3);
	//
	//
	MeasPin("VDDM");
	PrintMeasData("VDDM", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(200e-3);
	//
	//	UTL_StopFct();
	//	
	//	start_alpg_pattern_nowait("pat_SRAM.mpa", "READ_CROSS");
	//	UTL_WaitTime(20e-3);
	//	MeasPin("DVDD");
	//	PrintMeasData("DVDD", "DYNAMIC Current", 1 UA, "uA");
	//	
	////	UTL_WaitTime(20e-3);
	//	MeasPin("VDD");
	//	PrintMeasData("VDD", "DYNAMIC Current", 1 UA, "uA");
	////	UTL_WaitTime(20e-3);
	//
	////	MeasPin("VDDM1");
	////	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");
	////
	////	MeasPin("VDDM2");
	////	PrintMeasData("VDDM2", "DYNAMIC Current", 1 UA, "uA");
	//
	//
	//	MeasPin("VDDM");
	//	PrintMeasData("VDDM", "DYNAMIC Current", 1 UA, "uA");


#if 0
	UTL_WaitTime(20e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_StopFct();
	start_alpg_pattern_nowait("pat_SRAM.mpa", "READ_CROSS");
	MeasPin("POWERPINS");
	Print("\n------------------Dynamic IDD( Read ) TestResult:------------------\n");
	MeasPin("VDD");
	PrintMeasData("VDD", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM");
	PrintMeasData("VDDM", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM1");
	PrintMeasData("VDDM1", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("VDDM2");
	PrintMeasData("VDDM2", "DYNAMIC Current", 1 UA, "uA");
	UTL_WaitTime(20e-3);
	MeasPin("DVDD");
	PrintMeasData("DVDD", "DYNAMIC Current", 1 UA, "uA");

#endif

	UTL_StopFct();
	UTL_OffPowerSeq();UTL_ResetWet();
}

void tb_Bist_Mode_VDD1P08_250KHz()
{
	setLevel();
	setPinFmt();
	setTiming250KHz();

	setVSLevel(VDD_1P08, VDDM_1P08, VDDM1_1P08, VDDM2_1P08, DVDD_1P08); // 根据你原来的接口参数调整

	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------FUNC BIST_MODE TestResult:------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P08_1MHz()
{

	setLevel_normal(1.08 V);
	setPinFmt();
	setTiming1MHz();


	setVSLevel(VDD_1P08, VDDM_1P08, VDDM1_1P08, VDDM2_1P08, DVDD_1P08); // 根据你原来的接口参数调整
	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------Bist_Mode_VDD1P08_1MHz TestResult------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P2_250KHz()
{
	setLevel();
	setPinFmt();
	setTiming250KHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------FUNC BIST_MODE TestResult:------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P2_1MHz()
{
	setLevel();
	setPinFmt();
	setTiming1MHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//	run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");

	Print("\n------------------Bist_Mode_VDD1P2_1MHz TestResult------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P2_5MHz()
{
	setLevel();
	setPinFmt();

	setTiming5MHz();
	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//	run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");

	Print("\n------------------Bist_Mode_VDD1P2_5MHz TestResult------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P2_10MHz()
{
	setLevel();
	setPinFmt();
	setTiming10MHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------FUNC BIST_MODE TestResult:------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P32_250KHz()
{
	setLevel();
	setPinFmt();
	setTiming250KHz();

	setVSLevel(VDD_1P32, VDDM_1P32, VDDM1_1P32, VDDM2_1P32, DVDD_1P32); // 根据你原来的接口参数调整

	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------FUNC BIST_MODE TestResult:------------------\n");

	Func_FCM_BIST("BIST_MODE");
}
void tb_Bist_Mode_VDD1P32_1MHz()

{
	setLevel_normal(1.32 V);
	setPinFmt();
	setTiming1MHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//	run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");

	Print("\n------------------Bist_Mode_VDD1P32_1MHz TestResult------------------\n");

	Func_FCM_BIST("BIST_MODE");
}

void tb_Qual_Mode()
{

	setLevel();
	setPinFmt();
	setTiming1MHz();

	setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整

	//run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
	Print("\n------------------FUNC BIST_MODE TestResult:------------------\n");

	Func_FCM_QUAL("BIST_MODE");
}
void tb_Retention1M()
{	

	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;
	Print("\n------------Retention_Vmin_1MHz TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{
		mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		

		setDpinVi(1, 1.2 , 0);
		setDpinVo(1, 1.2 );
		setPinFmt_vmin();
		setTiming1MHz();

		int passflag=1;
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();UTL_SetWet();
		UTL_WaitTime(400e-3);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(mid, mid, mid, mid, mid);
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);
		UTL_WaitTime(400e-3);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
		UTL_WaitTime(400e-3);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		//	Func_FCM(Data0, "CHECKBOARD_R");
		passflag &=ReadResult(d);
		if (passflag == 1){
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);
		}else{
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);
		}
		fflush(stdout);
	}

	while ((hi >= VminLimit) ){
		int passflag=1;
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();UTL_SetWet();

		setDpinVi(1, 1.2 , 0);
		setDpinVo(1, 1.2 );
		setPinFmt_vmin();
		setTiming1MHz();

		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();UTL_SetWet();
		UTL_WaitTime(400e-3);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(hi, hi, hi, hi, hi);
		setDpinVi(1, hi, 0);
		setDpinVo(1, hi);
		UTL_WaitTime(400e-3);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
				UTL_WaitTime(400e-3);UTL_WaitTime(400e-3);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		//	Func_FCM(Data0, "CHECKBOARD_R");
		passflag &=ReadResult(d);
		if (passflag == 1){

			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);

			hi -= PowerDrop;
		}else{
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d Retention_Vmin_1MHz = %.3f V\n",d,hi);
			Func_FCM(Data0, "CHECKBOARD_R");
			break;
		}
		fflush(stdout);
	}

	UTL_OffPowerSeq();UTL_ResetWet();
}



void tb_Retention10M()
{



	Print("\n------------------Retention10M TestResult:------------------\n");
}
void tb_Bist_VDDmin()
{
	double Power = 1.2;					   // 起始电压（高）
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
	int i;
	int remaining = 0; // 仍在等待 FAIL 的 DUT 数
	/* 初始化 done / Vmin / remaining */
	Print("\n------------BIST_Vmin_1MHz TestResult---------------\n");
	while ((Power >= VminLimit) )
	{
		int passflag=1;
		setDpinVi(1, Power, 0);
		setDpinVo(1, Power);
		setDpinVt(1, (Power - 0) / 2);
		setPinFmt();
		setTiming1MHz();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(Power, Power, Power, Power, Power); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(20e-3);
		//	run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
		Func_FCM_BIST("BIST_MODE");
		UTL_OffPowerSeq();UTL_ResetWet();

		UT_DUT d = 1;
		int res = UTL_ReadMeasResult(d);

		passflag &=ReadResult(d);
		if (passflag ==0)
		{
			/* 记录、打印、加入 exclusion（保留你的逻辑） */
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
			fflush(stdout);
			break;
		}
		else /* PASS */
		{
			printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
			fflush(stdout);
		}

		Power -= PowerDrop;
	} /* end while sweep */

}

void tb_March_VDDmin()
{
	double Power = 1.2;					   // 起始电压（高）
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double Vmin[DUT_NUM];			   // 每个 DUT 的 Vmin 结果
	int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
	int i;
	int remaining = 0; // 仍在等待 FAIL 的 DUT 数
	/* 初始化 done / Vmin / remaining */
	Print("\n------------MarchY_Vmin_1MHz TestResult----------------\n");
        UTL_OnPowerSeq();UTL_SetWet();
	while ((Power >= VminLimit) )
	{
		int passflag=1;
		setDpinVi(1, Power, 0);
		setDpinVo(1, Power);
		setDpinVt(1, (Power - 0) / 2);
		setPinFmt();
		setTiming1MHz();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(Power, Power, Power, Power, Power); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(20e-3);
		//	run_alpg_pattern("pat_SRAM.mpa", "BIST_MODE");
		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
		UTL_OffPowerSeq();UTL_ResetWet();

		UT_DUT d = 1;
		int res = UTL_ReadMeasResult(d);

		passflag &=ReadResult(d);
		if (passflag ==0)
		{
			/* 记录、打印、加入 exclusion（保留你的逻辑） */
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
			fflush(stdout);
			break;
		}
		else /* PASS */
		{
			printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
			fflush(stdout);
		}

		Power -= PowerDrop;
	} /* end while sweep */

}


#if 0
void tb_March_VDDmin()
{
	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;

	Print("\n------------MarchY_Vmin_1MHz TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{	mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		


		int passflag=1;
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);
		setDpinVt(1, (mid - 0) / 2);
		setPinFmt();
		setTiming1MHz();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(mid, mid, mid, mid, mid); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(20e-3);
		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
		//	Func_FCM(Data0, "MARCHY_TEST");
		//int res = UTL_ReadMeasResult(d);
		passflag &=ReadResult(d);
		if (passflag ==0){
			/* 记录、打印、加入 exclusion（保留你的逻辑） */
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);

			//		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
			//Func_FCM(Data0, "MARCHY_TEST");
			//	fflush(stdout);
			//	break;
		}
		else{ /* PASS */
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);
		}
		fflush(stdout);
	} /* end while sweep */

	while ((hi >= VminLimit) ){

		int passflag=1;
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);
		setDpinVt(1, (mid - 0) / 2);
		setPinFmt();
		setTiming1MHz();
		/* 对所有 DUT 同步施加电压并跑 pattern */
		setVSLevel(mid, mid, mid, mid, mid); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(20e-3);
		run_alpg_pattern("pat_SRAM.mpa", "MARCHY_TEST");
		//	Func_FCM(Data0, "MARCHY_TEST");
		//int res = UTL_ReadMeasResult(d);
		passflag &=ReadResult(d);


		if (passflag == 1){

			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);

			hi -= PowerDrop;
		}else{
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d MARCHY_Vmin_1MHz = %.3f V\n",d,hi);
			Func_FCM(Data0, "MARCHY_TEST");
			break;
		}
		fflush(stdout);
	}















	UTL_OffPowerSeq();UTL_ResetWet();

}
#endif


void tb_Readmin_1M()
{
	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;
	int f_flag=0;
	Print("\n------------Read_Vmin_1MHz TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{
		mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		


		int passflag=1;
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();UTL_SetWet();
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
		setPinFmt_vmin();
		setTiming1MHz();
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(mid, mid, mid, mid, mid);
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		UTL_WaitTime(10 MS);
		//		Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);
		if (passflag == 1){
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);

		}else{
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);
			//	Func_FCM(Data0, "CHECKBOARD_R");

		}
		fflush(stdout);
	}

	//	hi=hi-PowerDrop;	
	while ((hi >= VminLimit) ){
		int passflag=1;
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();UTL_SetWet();
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
		setPinFmt_vmin();
		setTiming1MHz();
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(hi, hi, hi, hi, hi);
		setDpinVi(1, hi, 0);
		setDpinVo(1, hi);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		UTL_WaitTime(10 MS);
		//		Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);
		if (passflag == 1){

			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);

			hi -= PowerDrop;
		}else{
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d Read_Vmin_1MHz = %.3f V\n",d,hi);
			Func_FCM(Data0, "CHECKBOARD_R");
			break;
		}
		fflush(stdout);
	}

	UTL_OffPowerSeq();UTL_ResetWet();
}
//printf("DUT %d Read_Vmin_1MHz = %.3f V\n",d,lo);




/*
   SetRegValue(UT_REG_TPH1,0XFF);
   SetRegValue(UT_REG_TPH2,0XFF);
   setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
   run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
   setVSLevel(Power, Power, Power, Power, Power);
   run_alpg_pattern("pat_SRAM.mpa", "P_READ");
   res |= UTL_ReadMeasResult(d);

   SetRegValue(UT_REG_TPH1,0X55);
   SetRegValue(UT_REG_TPH2,0X55);
   setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
   run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
   setVSLevel(Power, Power, Power, Power, Power);
   run_alpg_pattern("pat_SRAM.mpa", "P_READ");
   res |= UTL_ReadMeasResult(d);

   SetRegValue(UT_REG_TPH1,0XAA);
   SetRegValue(UT_REG_TPH2,0XAA);
   setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
   run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
   setVSLevel(Power, Power, Power, Power, Power);
   run_alpg_pattern("pat_SRAM.mpa", "P_READ");


   UTL_OffPowerSeq();UTL_ResetWet();
   if (res == UT_RES_FAILED)
   {
   printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
   }
   {
   printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
   }

   Power -= PowerDrop;
   }end while sweep 
   */







void tb_Readmin_10M()
{
	{	
		double Fix1p2V =1.2;
		double Power = 1.2;					   // 起始电压（高）
		const double PowerDrop = VOLTAGE_DROP; // 步长
		const double VminLimit = 0.6;		   // 最低限位
		double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
		int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
		int i;
		int remaining = 0; // 仍在等待 FAIL 的 DUT 数

		UT_DUT ActiveDut[DUT_NUM] = {0};
		SaveDutGroupToArray(ActiveDut, UT_CDUT);

		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] != 0)
			{
				done[i] = 0;
				Vmin[i] = 0.0;
				remaining++;
			}
			else
			{
				done[i] = 1; // 不存在的 DUT 标记为已完成，便于跳过
				Vmin[i] = 0.0;
			}
		}

		setLevel();
		setPinFmt();
		setTiming10MHz();

		ExclusionHandle h = UTL_GetExclusionHandle();
		UTL_SetExclusionIgnoreWet(h, UT_OFF);
		UTL_SetExclusionMask(h, UT_OFF);

		Print("\n------------IO_VDDmin_DVDD_TestResult:---------------\n");

		while ((Power >= VminLimit) && (remaining > 0))
		{
			SetRegValue(UT_REG_TPH1,0X00);
			SetRegValue(UT_REG_TPH2,0X00);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XFF);
			SetRegValue(UT_REG_TPH2,0XFF);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0X55);
			SetRegValue(UT_REG_TPH2,0X55);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XAA);
			SetRegValue(UT_REG_TPH2,0XAA);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");
			int exclusionAddedThisRound = 0;

			for (i = 0; i < DUT_NUM; ++i)
			{
				UT_DUT d = ActiveDut[i];
				if ((d == 0) || done[i])
				{
					continue;
				}

				int res = UTL_ReadMeasResult(d);

				if (res == UT_RES_FAILED)
				{
					printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);

					Vmin[i] = Power;

					done[i] = 1;
					remaining--;

					UTL_AddExclusionDut(h, d);
					exclusionAddedThisRound = 1;
				}
				else /* PASS */
				{
					printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
				}
			} 

			if (exclusionAddedThisRound)
			{
				UTL_SetExclusionSetOrReset(h, UT_ON);
				UTL_SendExclusion(h);
			}

			Power -= PowerDrop;
		} /* end while sweep */

		if (remaining > 0)
		{

			for (i = 0; i < DUT_NUM; ++i)
			{
				if ((ActiveDut[i] == 0) || done[i])
					continue;

				Vmin[i] = Power + PowerDrop;
				done[i] = 1;
				remaining--;
				printf("DUT %d  Reached lower limit %.3f V without FAIL. Vmin set to %.3f V\n",
						ActiveDut[i], VminLimit, Vmin[i]);
			}
		}

		UTL_DeleteHandle(h);
		ResetDutsExclusion(ActiveDut);

		Print("\n===== Vmin Results (per DUT) =====\n");
		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] == 0)
				continue;
			printf("DUT %d : Vmin = %.3f V\n", ActiveDut[i], Vmin[i]);
		}
		Print("\n===== End =====\n");
	}





	Print("\n------------------Read10M TestResult:------------------\n");
}

void tb_Writemin_1M()
{
	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;

	Print("\n------------Write_Vmin_1MHz TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{
		mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		
		int passflag=1;
		setVSLevel(mid, mid, mid, mid, mid);
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);

		setPinFmt_vmin();
		setTiming1MHz();
		UT_DUT d = 1;
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(10 MS);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, Fix1p2V, 0);
		setDpinVo(1, Fix1p2V);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		//	Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);


		if (passflag == 1){
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);

		}else{
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);
			//	Func_FCM(Data0, "CHECKBOARD_R");

		}
		fflush(stdout);
	}

	while ((hi >= VminLimit) ){
		int passflag=1;
		setVSLevel(hi, hi, hi, hi, hi);
		setDpinVi(1, hi, 0);
		setDpinVo(1, hi);

		setPinFmt_vmin();
		setTiming1MHz();
		UT_DUT d = 1;
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(10 MS);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, Fix1p2V, 0);
		setDpinVo(1, Fix1p2V);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		//	Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);

		if (passflag == 1){

			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);

			hi -= PowerDrop;
		}else{
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d WRITE_Vmin_1MHz = %.3f V\n",d,hi);
			Func_FCM(Data0, "CHECKBOARD_R");
			break;
		}


		fflush(stdout);
	}


	UTL_OffPowerSeq();UTL_ResetWet();
}



void tb_Writemin_1M_IW()
{
	int count=0;
	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;

	Print("\n------------Write_Vmin_1MHz_IW TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{	count++;
		mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		
		int passflag=1;
		setVSLevel(mid, mid, mid, mid, mid);
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);

		setPinFmt_vmin();
		setTiming1MHz();
		if(count%2==1){
			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		}else{
			SetRegValue(UT_REG_TPH1,0X55555555);
			SetRegValue(UT_REG_TPH2,0X55555555);
		}





		UT_DUT d = 1;
		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(10 MS);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, Fix1p2V, 0);
		setDpinVo(1, Fix1p2V);


		if(count%2==1){
			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		}else{
			SetRegValue(UT_REG_TPH1,0X55555555);
			SetRegValue(UT_REG_TPH2,0X55555555);
		}



		//	Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);


		if (passflag == 1){
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);

		}else{
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);
			//	Func_FCM(Data0, "CHECKBOARD_R");

		}
		fflush(stdout);
	}

	while ((hi >= VminLimit) ){
		count++;
		int passflag=1;
		setVSLevel(hi, hi, hi, hi, hi);
		setDpinVi(1, hi, 0);
		setDpinVo(1, hi);

		setPinFmt_vmin();
		setTiming1MHz();
		UT_DUT d = 1;
		if(count%2==1){
			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		}else{
			SetRegValue(UT_REG_TPH1,0X55555555);
			SetRegValue(UT_REG_TPH2,0X55555555);
		}


		UTL_OnPowerSeq();UTL_SetWet();
		UTL_WaitTime(10 MS);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		setDpinVi(1, Fix1p2V, 0);
		setDpinVo(1, Fix1p2V);
		if(count%2==1){
			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		}else{
			SetRegValue(UT_REG_TPH1,0X55555555);
			SetRegValue(UT_REG_TPH2,0X55555555);
		}


		//	Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);

		if (passflag == 1){

			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);

			hi -= PowerDrop;
		}else{
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d WRITE_Vmin_1MHz_IW = %.3f V\n",d,hi);
			Func_FCM(Data0, "CHECKBOARD_R");
			break;
		}


		fflush(stdout);
	}


	UTL_OffPowerSeq();UTL_ResetWet();


	//	double Fix1p2V =1.2;
	//	double Power = 1.2;					   // 起始电压（高）
	//	const double PowerDrop = VOLTAGE_DROP; // 步长
	//	const double VminLimit = 0.2;		   // 最低限位
	//	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	//	int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
	//	int i;
	//	int remaining = 0; // 仍在等待 FAIL 的 DUT 数
	//	int count=0;
	//	/* 初始化 done / Vmin / remaining */
	//	Print("\n------------Write_Vmin_1MHz_IW TestResult---------------\n");
	//	while ((Power >= VminLimit) )
	//	{
	//
	//		count++;
	//		setDpinVi(1, Power, 0);
	//		setDpinVo(1, Power);
	//		setDpinVt(1, (Power - 0) / 2);
	//		setPinFmt_vmin();
	//		setTiming1MHz();
	//		UT_DUT d = 1;
	//		int passflag=1;
	//		if(count%2==1){
	//			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
	//			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
	//		}else{
	//			SetRegValue(UT_REG_TPH1,0X55555555);
	//			SetRegValue(UT_REG_TPH2,0X55555555);
	//		}
	//		setVSLevel(Power, Power, Power, Power, Power);
	//		UTL_OnPowerSeq();UTL_SetWet();
	//		UTL_WaitTime(10 MS);
	//		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");
	//		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
	//		setDpinVi(1, Fix1p2V, 0);
	//		setDpinVo(1, Fix1p2V);
	//
	//		if(count%2==1){
	//			SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
	//			SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
	//		}else{
	//			SetRegValue(UT_REG_TPH1,0X55555555);
	//			SetRegValue(UT_REG_TPH2,0X55555555);
	//		}
	//
	//
	//		Func_FCM(Data0, "CHECKBOARD_R");
	//		passflag &=ReadResult(d);
	//		if(ReadResult(d)==0);
	//		UTL_OffPowerSeq();UTL_ResetWet();
	//		if (passflag == 1)
	//		{
	//			printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
	//			fflush(stdout);
	//
	//		}else
	//		{
	//			printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);
	//
	//			fflush(stdout);
	//			break;
	//		}
	//
	//		Power -= PowerDrop;
	//	}
	//	UTL_OffPowerSeq();UTL_ResetWet();
}
void tb_Writemin_10M()
{
	{	
		double Fix1p2V =1.2;
		double Power = 1.2;					   // 起始电压（高）
		const double PowerDrop = VOLTAGE_DROP; // 步长
		const double VminLimit = 0.6;		   // 最低限位
		double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
		int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
		int i;
		int remaining = 0; // 仍在等待 FAIL 的 DUT 数

		UT_DUT ActiveDut[DUT_NUM] = {0};
		SaveDutGroupToArray(ActiveDut, UT_CDUT);

		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] != 0)
			{
				done[i] = 0;
				Vmin[i] = 0.0;
				remaining++;
			}
			else
			{
				done[i] = 1; // 不存在的 DUT 标记为已完成，便于跳过
				Vmin[i] = 0.0;
			}
		}

		setLevel();
		setPinFmt();
		setTiming10MHz();

		ExclusionHandle h = UTL_GetExclusionHandle();
		UTL_SetExclusionIgnoreWet(h, UT_OFF);
		UTL_SetExclusionMask(h, UT_OFF);

		Print("\n------------IO_VDDmin_DVDD_TestResult:---------------\n");

		while ((Power >= VminLimit) && (remaining > 0))
		{
			SetRegValue(UT_REG_TPH1,0X00);
			SetRegValue(UT_REG_TPH2,0X00);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XFF);
			SetRegValue(UT_REG_TPH2,0XFF);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0X55);
			SetRegValue(UT_REG_TPH2,0X55);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XAA);
			SetRegValue(UT_REG_TPH2,0XAA);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");
			int exclusionAddedThisRound = 0;

			for (i = 0; i < DUT_NUM; ++i)
			{
				UT_DUT d = ActiveDut[i];
				if ((d == 0) || done[i])
				{
					continue;
				}

				int res = UTL_ReadMeasResult(d);

				if (res == UT_RES_FAILED)
				{
					printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);

					Vmin[i] = Power;

					done[i] = 1;
					remaining--;

					UTL_AddExclusionDut(h, d);
					exclusionAddedThisRound = 1;
				}
				else /* PASS */
				{
					printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
				}
			} 

			if (exclusionAddedThisRound)
			{
				UTL_SetExclusionSetOrReset(h, UT_ON);
				UTL_SendExclusion(h);
			}

			Power -= PowerDrop;
		} /* end while sweep */

		if (remaining > 0)
		{

			for (i = 0; i < DUT_NUM; ++i)
			{
				if ((ActiveDut[i] == 0) || done[i])
					continue;

				Vmin[i] = Power + PowerDrop;
				done[i] = 1;
				remaining--;
				printf("DUT %d  Reached lower limit %.3f V without FAIL. Vmin set to %.3f V\n",
						ActiveDut[i], VminLimit, Vmin[i]);
			}
		}

		UTL_DeleteHandle(h);
		ResetDutsExclusion(ActiveDut);

		Print("\n===== Vmin Results (per DUT) =====\n");
		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] == 0)
				continue;
			printf("DUT %d : Vmin = %.3f V\n", ActiveDut[i], Vmin[i]);
		}
		Print("\n===== End =====\n");
	}





	Print("\n------------------Write10M TestResult:------------------\n");
}


void tb_Flipmin_1M()
{
	double Fix1p2V =1.2;
	const double PowerDrop = VOLTAGE_DROP; // 步长
	const double VminLimit = 0.2;		   // 最低限位
	double lo=VminLimit;
	double hi=1.2;
	double mid;
	double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
	UT_DUT d = 1;
	int f_flag=0;
	Print("\n------------Flip_Vmin_1MHz TestResult---------------\n");
	while ((hi-lo)>=PowerDrop )
	{		mid=ceil((lo+hi)/2.0/PowerDrop)*PowerDrop;
		if(mid>=hi) mid=hi-PowerDrop;		
		if(mid<=lo) mid=lo+PowerDrop;		


		int passflag=1;
		setDpinVi(1, 1.2 , 0);
		setDpinVo(1, 1.2 );


		setDpinVt(1, (1.2 - 0) / 2);
		setPinFmt_vmin();
		setTiming1MHz();
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");


		setVSLevel(mid, mid, mid, mid, mid);
		UTL_WaitTime(10 MS);
		setDpinVi(1, mid, 0);
		setDpinVo(1, mid);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_WaitTime(10 MS);
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		//		Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);
		UTL_OffPowerSeq();UTL_ResetWet();
		if (passflag == 1){
			hi=mid;
			printf("DUT %d  Power = %.3f V  => PASS\n", d, mid);
			fflush(stdout);
		}else{
			lo=mid;
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, mid);
		}
		fflush(stdout);
	}
	while ((hi >= VminLimit) ){
		int passflag=1;
		setDpinVi(1, 1.2 , 0);
		setDpinVo(1, 1.2 );


		setDpinVt(1, (1.2 - 0) / 2);
		setPinFmt_vmin();
		setTiming1MHz();
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_OnPowerSeq();UTL_SetWet();
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_W");


		setVSLevel(hi, hi, hi, hi, hi);
		UTL_WaitTime(10 MS);
		setDpinVi(1, hi, 0);
		setDpinVo(1, hi);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		setVSLevel(VDD, VDDM, VDDM1, VDDM2, DVDD); // 根据你原来的接口参数调整
		UTL_WaitTime(10 MS);
		setDpinVi(1, 1.2, 0);
		setDpinVo(1, 1.2);
		SetRegValue(UT_REG_TPH1,0XAAAAAAAA);
		SetRegValue(UT_REG_TPH2,0XAAAAAAAA);
		UTL_WaitTime(10 MS);
		//		Func_FCM(Data0, "CHECKBOARD_R");
		run_alpg_pattern("pat_SRAM.mpa", "CHECKBOARD_R");
		passflag &=ReadResult(d);
		if (passflag == 1){
			printf("DUT %d  Power = %.3f V  => PASS\n", d, hi);
			hi-=PowerDrop;	
		}else{	
			printf("DUT %d  Power = %.3f V  => FAIL\n", d, hi);

			printf("DUT %d FLIP_Vmin_1MHz = %.3f V\n",d,hi);
			Func_FCM(Data0, "CHECKBOARD_R");
			break;
		}
		fflush(stdout);
	}



	UTL_OffPowerSeq();UTL_ResetWet();
}
void tb_Flipmin_10M()
{
	{	
		double Fix1p2V =1.2;
		double Power = 1.2;					   // 起始电压（高）
		const double PowerDrop = VOLTAGE_DROP; // 步长
		const double VminLimit = 0.6;		   // 最低限位
		double Vmin[DUT_NUM];				   // 每个 DUT 的 Vmin 结果
		int done[DUT_NUM];					   // 标记该 DUT 是否已经记录了 Vmin
		int i;
		int remaining = 0; // 仍在等待 FAIL 的 DUT 数

		UT_DUT ActiveDut[DUT_NUM] = {0};
		SaveDutGroupToArray(ActiveDut, UT_CDUT);

		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] != 0)
			{
				done[i] = 0;
				Vmin[i] = 0.0;
				remaining++;
			}
			else
			{
				done[i] = 1; // 不存在的 DUT 标记为已完成，便于跳过
				Vmin[i] = 0.0;
			}
		}

		setLevel();
		setPinFmt();
		setTiming10MHz();

		ExclusionHandle h = UTL_GetExclusionHandle();
		UTL_SetExclusionIgnoreWet(h, UT_OFF);
		UTL_SetExclusionMask(h, UT_OFF);

		Print("\n------------IO_VDDmin_DVDD_TestResult:---------------\n");

		while ((Power >= VminLimit) && (remaining > 0))
		{
			SetRegValue(UT_REG_TPH1,0X00);
			SetRegValue(UT_REG_TPH2,0X00);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XFF);
			SetRegValue(UT_REG_TPH2,0XFF);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0X55);
			SetRegValue(UT_REG_TPH2,0X55);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");

			SetRegValue(UT_REG_TPH1,0XAA);
			SetRegValue(UT_REG_TPH2,0XAA);
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "P_WRITE");
			setVSLevel(Power, Power, Power, Power, Power);
			UTL_WaitTime(200 MS); // Retention Time
			setVSLevel(Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V, Fix1p2V);
			run_alpg_pattern("pat_SRAM.mpa", "p_READ");
			int exclusionAddedThisRound = 0;

			for (i = 0; i < DUT_NUM; ++i)
			{
				UT_DUT d = ActiveDut[i];
				if ((d == 0) || done[i])
				{
					continue;
				}

				int res = UTL_ReadMeasResult(d);

				if (res == UT_RES_FAILED)
				{
					printf("DUT %d  Power = %.3f V  => FAIL\n", d, Power);

					Vmin[i] = Power;

					done[i] = 1;
					remaining--;

				}
				else /* PASS */
				{
					printf("DUT %d  Power = %.3f V  => PASS\n", d, Power);
				}
			} 

			if (exclusionAddedThisRound)
			{
				UTL_SetExclusionSetOrReset(h, UT_ON);
				UTL_SendExclusion(h);
			}

			Power -= PowerDrop;
		} /* end while sweep */

		if (remaining > 0)
		{

			for (i = 0; i < DUT_NUM; ++i)
			{
				if ((ActiveDut[i] == 0) || done[i])
					continue;

				Vmin[i] = Power + PowerDrop;
				done[i] = 1;
				remaining--;
				printf("DUT %d  Reached lower limit %.3f V without FAIL. Vmin set to %.3f V\n",
						ActiveDut[i], VminLimit, Vmin[i]);
			}
		}

		UTL_DeleteHandle(h);
		ResetDutsExclusion(ActiveDut);

		Print("\n===== Vmin Results (per DUT) =====\n");
		for (i = 0; i < DUT_NUM; ++i)
		{
			if (ActiveDut[i] == 0)
				continue;
			printf("DUT %d : Vmin = %.3f V\n", ActiveDut[i], Vmin[i]);
		}
		Print("\n===== End =====\n");
	}





	Print("\n------------------Flip10M TestResult:------------------\n");
}
