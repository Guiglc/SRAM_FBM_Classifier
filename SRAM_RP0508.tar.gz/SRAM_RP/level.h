#ifndef	__LEVEL_H
#define	__LEVEL_H

void setVSLevel(double vdd, double vddm, double vddm1, double vddm2,double dvdd);
void setVSLevelMeas_PowerShort(double vdd, double vddm, double vddm1, double vddm2,double dvdd, double hlimit,double lowlimit, unsigned int cnt);
void setVSLevelMeas_ISB(double vdd, double vddm, double vddm1, double vddm2,double dvdd, unsigned int cnt);
void setVSLevelMeas_IDD(double vdd, double vddm, double vddm1, double vddm2,double dvdd, unsigned int cnt);
void setLevelHigh();
void setLevel_normal(double Dpin);
void setLevel();
void setLevelLow();
void setDpinVt(int no, double vt);
void setDpinVo(int no, double vo);
void setDpinVi(int no, double vih, double vil);
void setDpinVload(int no, double vl);
void setDpinVihh(int no, int sig, double vihh, double vih, double vil);

#endif	
