#include "main.h"

void setPowerSeq(){
	PowerSeqHandle	h = UTL_GetPowerSeqHandle();
	UTL_AddPowerSeqUnit     (h, 1,UT_UNIT_VS(5)); 
	UTL_AddPowerSeqUnit     (h, 2,UT_UNIT_VS(2)); 
	UTL_AddPowerSeqUnit     (h, 3,UT_UNIT_VS(3)); 
	UTL_AddPowerSeqUnit     (h, 4,UT_UNIT_VS(4)); 
	UTL_AddPowerSeqUnit     (h, 5,UT_UNIT_VS(1)); 
	UTL_AddPowerSeqOthers    (h, 6);
	UTL_SetPowerSeqWaitTime (h, 2, 5 MS);
	UTL_SetPowerSeqWaitTime (h, 3, 5 MS);
	UTL_SetPowerSeqWaitTime (h, 4, 5 MS);
	UTL_SetPowerSeqWaitTime (h, 5, 5 MS);
	UTL_SetPowerSeqWaitTime (h, 6, 5 MS);
	UTL_SendPowerSeq (h);
}



//-------------------------------------------------------------
//T5830-PPS 
//-------------------------------------------------------------
//  SRng  : SVal           
//-------------------------------------------------------------
//     2V : 0.0V ~ 2.2V   
//     3V : 0.0V ~ 3.3V   
//     4V : 0.0V ~ 4.0V   
//    16V :-1.0V ~13.0V   
//-------------------------------------------------------------
//  MRng  : SRng             SVal
//-------------------------------------------------------------
//   40uA :  2V,3V,4V,16V : +/-FSR
//  400uA :               
//    4mA :               
//   40mA :               
//-------------------------------------------------------------
//  400mA :  2V,3V,4V     : +/-FSR
//        : 16V           : 8V~13V
//        :               : 0V~7.999V
//        :               :-1V~0V
//-------------------------------------------------------------
//  1200A :  2V           : 0.7V~2.2V
//        :               : 0.0V~0.699V
//        :  3V           : 2.0V~3.3V
//        :               : 0.0V~1.999V
//        :  4V           : 2.6V~4.0V
//        :               : 0.0V~2.599V
//        : 16V           : not supported 
//-------------------------------------------------------------
void setVs(int vsno, double val, enum ePPS_SRNG srng, enum ePPS_MRNG mrng, double pclamp, double mclamp)
{
	double sRngMax;
	double sRngMin;
	double mRngMax;
	double mRngMin;
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_VSIM);
	UTL_SetVsSource  (Vs_H, val);
	switch(srng)
	{
		case R2V  : sRngMax= 2.2; sRngMin= 0.0; break;
		case R3V  : sRngMax= 3.3; sRngMin= 0.0; break;
		case R4V  : sRngMax= 4.0; sRngMin= 0.0; break;
		case R16V : sRngMax=13.0; sRngMin=-1.0; break;
		default   : ErrorStop("Out of range : VCC : SRng\n"); break;
	}

	switch(mrng)
	{
		case M40uA  : mRngMax=25e-6;  mRngMin=-25e-6;  break;
		case M400uA : mRngMax=250e-6; mRngMin=-250e-6; break;
		case M4mA   : mRngMax=2.5e-3; mRngMin=-2.5e-3; break;
		case M40mA  : mRngMax=25e-3;  mRngMin=-25e-3;  break;
		case M400mA : mRngMax=400e-3; mRngMin=-200e-3; break;
		case M1200mA : mRngMax=1200e-3; mRngMin=-200e-3; break;
		default   : ErrorStop("Out of range : VCC : MRng\n");break;
	}

	UTL_SetVsLimitHigh    (Vs_H, 0, UT_OFF);
	UTL_SetVsLimitLow     (Vs_H, 0, UT_OFF);

	UTL_SetVsSrange       (Vs_H, sRngMax, sRngMin);
	UTL_SetVsMrange       (Vs_H, mRngMax, mRngMin);
	UTL_SetVsPclamp       (Vs_H, pclamp);
	UTL_SetVsMclamp       (Vs_H, mclamp);
	UTL_AddVsWetItem      (Vs_H, UT_DCT_MRANGE);
	UTL_SetVsPhaseCompensation(Vs_H, UT_DCT_C1);

	UTL_SendVs		 (Vs_H, vsno);
	UTL_DeleteHandle (Vs_H);
}

void setVsMeas(int vsno, double val, enum ePPS_SRNG srng, enum ePPS_MRNG mrng, double pclamp, double mclamp, double upperLimit, double lowerLimit, int cnt)
{
	double sRngMax;
	double sRngMin;
	double mRngMax;
	double mRngMin;
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_VSIM);
	UTL_SetVsMeasCnt (Vs_H, cnt);
	UTL_SetVsSource  (Vs_H, val);
	switch(srng)
	{
		case R2V  : sRngMax= 2.2; sRngMin= 0.0; break;
		case R3V  : sRngMax= 3.3; sRngMin= 0.0; break;
		case R4V  : sRngMax= 4.0; sRngMin= 0.0; break;
		case R16V : sRngMax=13.0; sRngMin=-1.0; break;
		default   : ErrorStop("Out of range : VCC : SRng\n"); break;
	}

	switch(mrng)
	{
		case M40uA  : mRngMax=25e-6;  mRngMin=-25e-6;  break;
		case M400uA : mRngMax=250e-6; mRngMin=-250e-6; break;
		case M4mA   : mRngMax=2.5e-3; mRngMin=-2.5e-3; break;
		case M40mA  : mRngMax=25e-3;  mRngMin=-25e-3;  break;
		case M400mA : mRngMax=400e-3; mRngMin=-200e-3; break;
		case M1200mA: mRngMax=1200e-3; mRngMin=-200e-3; break;
		default   : ErrorStop("Out of range : VCC : MRng\n");  break;
	}

	UTL_SetVsSrange  (Vs_H, sRngMax, sRngMin);
	UTL_SetVsMrange  (Vs_H, mRngMax, mRngMin);

	UTL_SetVsLimitHigh    (Vs_H, upperLimit, UT_ON);
	UTL_SetVsLimitLow     (Vs_H, lowerLimit, UT_ON);
	UTL_SetVsPclamp       (Vs_H, pclamp);
	UTL_SetVsMclamp       (Vs_H, mclamp);
	UTL_AddVsWetItem      (Vs_H, UT_DCT_MRANGE);
	UTL_SetVsPhaseCompensation(Vs_H, UT_DCT_C1);

	UTL_SendVs       (Vs_H, vsno);
	UTL_DeleteHandle (Vs_H);
}

//-------------------------------------------------------------
//T5830-HV  (VSIM)
//-------------------------------------------------------------
//  SRng  : SVal           
//-------------------------------------------------------------
//     8V :  -8V ~ 8V
//    32V : -10V ~ 32V
//-------------------------------------------------------------
//  MRng  : 
//-------------------------------------------------------------
//    8uA :   -8uA ~   8uA
//   80uA :  -80uA ~  80uA
//  800uA : -800uA ~ 800uA
//    8mA :   -8mA ~   8mA
//  128mA :  -80mA ~  90mA
//-------------------------------------------------------------
//-------------------------------------------------------------
//T5830  (MVM)
//-------------------------------------------------------------
//  MRng  : 
//-------------------------------------------------------------
//    +8V :  -0.3V ~  8.0V
//    -8V :  -8.0V ~  0.3V
//   +32V :  -0.3V ~ 32.0V
//   -32V : -11.0V ~  0.3V
//-------------------------------------------------------------

void setHv(int vsno, double val, enum eVPP_SRNG srng, enum eVPP_MRNG mrng, double pclamp, double mclamp)
{
	double sRngMax;
	double sRngMin;
	double mRngMax;
	double mRngMin;
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_VSIM);
	UTL_SetVsSource  (Vs_H, val);
	switch(srng)
	{
		case R8V  : sRngMax=  8.0; sRngMin=  -8.0; break;
		case R32V : sRngMax= 32.0; sRngMin= -10.0; break;
		default   : ErrorStop("%s : Out of range : VCC : SRng\n", __FUNCTION__);break;
	}

	switch(mrng)
	{
		case M8uA   : mRngMax=  8e-6; mRngMin=  -8e-6;  break;
		case M80uA  : mRngMax= 80e-6; mRngMin= -80e-6;  break;
		case M800uA : mRngMax=800e-6; mRngMin=-800e-6;  break;
		case M8mA   : mRngMax=  8e-3; mRngMin=  -8e-3;  break;
		case M128mA : mRngMax= 90e-3; mRngMin= -80e-3;  break;
		default   : ErrorStop("%s : Out of range : VCC : MRng\n", __FUNCTION__); break;
	}

	UTL_SetVsSrange  (Vs_H, sRngMax, sRngMin);
	UTL_SetVsMrange  (Vs_H, mRngMax, mRngMin);
	UTL_SetVsLimitHigh    (Vs_H, 0, UT_OFF);
	UTL_SetVsLimitLow     (Vs_H, 0, UT_OFF);
	UTL_SetVsPclamp  (Vs_H, pclamp);
	UTL_SetVsMclamp  (Vs_H, mclamp);
	UTL_AddVsWetItem (Vs_H,UT_DCT_MRANGE);
	SendVsHv_ForceWet(Vs_H, vsno);
	UTL_DeleteHandle (Vs_H);
}


void setHvMeas(int vsno, double val, enum eVPP_SRNG srng, enum eVPP_MRNG mrng, double pclamp, double mclamp, double upperLimit, double lowerLimit, int cnt)
{
	double sRngMax;
	double sRngMin;
	double mRngMax;
	double mRngMin;
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_VSIM);
	UTL_SetVsMeasCnt (Vs_H, cnt);
	UTL_SetVsSource  (Vs_H, val);
	switch(srng)
	{
		case R8V  : sRngMax=  8.0; sRngMin=  -8.0; break;
		case R32V : sRngMax= 32.0; sRngMin= -10.0; break;
		default   : ErrorStop("%s : Out of range : VCC : SRng\n", __FUNCTION__); break;
	}

	switch(mrng)
	{
		case M8uA   : mRngMax=  8e-6; mRngMin=  -8e-6;  break;
		case M80uA  : mRngMax= 80e-6; mRngMin= -80e-6;  break;
		case M800uA : mRngMax=800e-6; mRngMin=-800e-6;  break;
		case M8mA   : mRngMax=  8e-3; mRngMin=  -8e-3;  break;
		case M128mA : mRngMax= 90e-3; mRngMin= -80e-3;  break;
		default   : ErrorStop("%s : Out of range : VCC : MRng\n", __FUNCTION__); break;
	}

	UTL_SetVsSrange  (Vs_H, sRngMax, sRngMin);
	UTL_SetVsMrange  (Vs_H, mRngMax, mRngMin);

	UTL_SetVsLimitHigh    (Vs_H, upperLimit, UT_ON);
	UTL_SetVsLimitLow     (Vs_H, lowerLimit, UT_ON);
	UTL_SetVsPclamp       (Vs_H, pclamp);
	UTL_SetVsMclamp       (Vs_H, mclamp);
	UTL_AddVsWetItem      (Vs_H, UT_DCT_MRANGE);

	SendVsHv_ForceWet     (Vs_H, vsno);
	UTL_DeleteHandle      (Vs_H);
}


void setHvMVM(int vsno, enum eVPP_MRNG mrng, double upperLimit, double lowerLimit , int cnt)
{
	double mRngMax;
	double mRngMin;
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_MVM);
	UTL_SetVsMeasCnt (Vs_H, cnt);

	switch(mrng)
	{
		case M8V    : mRngMax=  8.00; mRngMin=  -0.30;  break;
		case Mm8V   : mRngMax=  0.30; mRngMin=  -8.00;  break;
		case M32V   : mRngMax= 32.00; mRngMin=  -0.30;  break;
		case Mm32V  : mRngMax=  0.30; mRngMin= -11.00;  break;
		default   : ErrorStop("%s : Out of range : VCC : MRng\n", __FUNCTION__);  break;
	}

	UTL_SetVsMrange  (Vs_H, mRngMax, mRngMin);

	UTL_SetVsLimitHigh    (Vs_H, upperLimit, UT_ON);
	UTL_SetVsLimitLow     (Vs_H, lowerLimit, UT_ON);
	UTL_AddVsWetItem      (Vs_H, UT_DCT_MRANGE    );
	SendVsHv_ForceWet(Vs_H, vsno);

	UTL_DeleteHandle (Vs_H);
}

void addVsLimit(int vsno, double upperLimit, double lowerLimit)
{
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_UpdateVs (Vs_H, vsno);	

	UTL_SetVsLimitHigh    (Vs_H, upperLimit, UT_ON);
	UTL_SetVsLimitLow     (Vs_H, lowerLimit, UT_ON);
	UTL_SendVs            (Vs_H, vsno);
	UTL_DeleteHandle      (Vs_H);
}

//-------------------------------------------------------------
//T5830-DC  (VSIM)
//---------------------------------------------------------------------------------------
//  SRng  : SVal           
//---------------------------------------------------------------------------------------
//  20V   : -1.0V ~ +13.0V   Reso=2mV
//---------------------------------------------------------------------------------------
//  MRng  : 
//---------------------------------------------------------------------------------------
//   5uA  : -5uA   ~ +5uA    Reso=1nA
//  20uA  : -20uA  ~ +20uA   Reso=4nA
// 200uA  : -200uA ~ +200uA  Reso=40nA
//   2mA  : -2mA   ~ +2mA    Reso=400nA
//  20mA  : -20mA  ~ +20mA   Reso=20uA
//---------------------------------------------------------------------------------------
//	enum eDC_VRNG { R20V };
//	enum eDC_IRNG { R5uA, R20uA, R200uA, R2mA, R20mA };

void setDcVS(double sval, enum eDC_VRNG srng, enum eDC_IRNG mrng, double pclamp, double mclamp)
{
	DcHandle hDc = UTL_GetDcHandle();
	UTL_SetDcMode     (hDc, UT_DCT_VSIM);
	UTL_SetDcSource   (hDc, sval);

	if(srng==R20V)
		UTL_SetDcSrange   (hDc, 13.0, -1.0);
	else { ErrorStop("Unsupported srange is set on setDcVSIM().");  }

	if     (mrng==R5uA  ) UTL_SetDcMrange   ( hDc,   5.0e-6,   -5.0e-6 );
	else if(mrng==R20uA ) UTL_SetDcMrange   ( hDc,  20.0e-6,  -20.0e-6 );
	else if(mrng==R200uA) UTL_SetDcMrange   ( hDc, 200.0e-6, -200.0e-6 );
	else if(mrng==R2mA  ) UTL_SetDcMrange   ( hDc,   2.0e-3,   -2.0e-3 );
	else if(mrng==R20mA ) UTL_SetDcMrange   ( hDc,  20.0e-3,  -20.0e-3 );
	else{ ErrorStop("Unsupported mrange is set on setDcVSIM()."); }

	UTL_SetDcPclamp   (hDc, pclamp);
	UTL_SetDcMclamp   (hDc, mclamp);

	UTL_SetDcLimitHigh(hDc, 0.0, UT_OFF);
	UTL_SetDcLimitLow (hDc, 0.0, UT_OFF);
	UTL_AddDcWetItem  (hDc, UT_DCT_MRANGE);
	SendDc_ForceWet   (hDc);
	UTL_DeleteHandle  (hDc);
}

void setDcVSIM(double sval, enum eDC_VRNG srng, enum eDC_IRNG mrng, double pclamp, double mclamp, double hlimit, double llimit, int cnt)
{
	DcHandle hDc = UTL_GetDcHandle();
	UTL_SetDcMode     (hDc, UT_DCT_VSIM);
	UTL_SetDcSource   (hDc, sval);

	if(srng==R20V){
		UTL_SetDcSrange   (hDc, 7, -1);
	}
	else { ErrorStop("Unsupported srange is set on setDcVSIM()."); }

	if     (mrng==R5uA  ) UTL_SetDcMrange   ( hDc,   5.0e-6,   -5.0e-6 );
	else if(mrng==R20uA ) UTL_SetDcMrange   ( hDc,  20.0e-6,  -20.0e-6 );
	else if(mrng==R200uA) UTL_SetDcMrange   ( hDc, 200.0e-6, -200.0e-6 );
	else if(mrng==R2mA  ) UTL_SetDcMrange   ( hDc,   2.0e-3,   -2.0e-3 );
	else if(mrng==R20mA ) UTL_SetDcMrange   ( hDc,  20.0e-3,  -20.0e-3 );
	else{ ErrorStop("Unsupported mrange is set on setDcVSIM()."); }

	UTL_SetDcPclamp   (hDc, pclamp);
	UTL_SetDcMclamp   (hDc, mclamp);

	UTL_SetDcLimitHigh(hDc, hlimit, UT_ON);
	UTL_SetDcLimitLow (hDc, llimit, UT_ON);
	UTL_SetDcMeasCnt  (hDc, cnt);
	UTL_AddDcWetItem  (hDc, UT_DCT_MRANGE);
	SendDc_ForceWet   (hDc);
	UTL_DeleteHandle  (hDc);
}
//-------------------------------------------------------------
//T5830-DC  (ISVM)
//---------------------------------------------------------------------------------------
//  SRng  : SVal           
//---------------------------------------------------------------------------------------
//  20uA  : -20uA  ~ +20uA   Reso=2.5nA
// 200uA  : -200uA ~ +200uA  Reso=25nA
//   2mA  : -2mA   ~ +2mA    Reso=250nA
//  20mA  : -20mA  ~ +20mA   Reso=10uA(-0.3V~13V)
//  m20mA : -10mA  ~ +10mA   Reso=10uA(-1.8V~0.3V)
//---------------------------------------------------------------------------------------
//  MRng  : 
//---------------------------------------------------------------------------------------
//  20V   : -0.3V ~ +13.0V   Reso=2mV
//  m20V  : -1.8V ~  +0.3V   Reso=2mV
//---------------------------------------------------------------------------------------
//	enum eDC_VRNG { R20V };
//	enum eDC_IRNG { R5uA, R20uA, R200uA, R2mA, R20mA };
void setDcIS(double sval, enum eDC_IRNG srng, enum eDC_VRNG mrng, double pclamp, double mclamp)
{
	DcHandle hDc = UTL_GetDcHandle();
	UTL_SetDcMode     (hDc, UT_DCT_ISVM);
	UTL_SetDcSource   (hDc, sval);

	if     (srng==R20uA ) UTL_SetDcSrange   ( hDc,  20.0e-6,  -20.0e-6 );
	else if(srng==R200uA) UTL_SetDcSrange   ( hDc, 200.0e-6, -200.0e-6 );
	else if(srng==R2mA  ) UTL_SetDcSrange   ( hDc,   2.0e-3,   -2.0e-3 );
	else if(srng==R20mA ) UTL_SetDcSrange   ( hDc,  20.0e-3,  -20.0e-3 );
	else if(srng==Rm20mA) UTL_SetDcSrange   ( hDc,  10.0e-3,  -10.0e-3 );
	else{ ErrorStop("Unsupported srange is set on setDcIS()."); }

	if(mrng==R20V)
		UTL_SetDcMrange   (hDc, 13.0, -0.3);
	else if(mrng==Rm20V)
		UTL_SetDcMrange   (hDc,  0.3, -1.8);
	else{ ErrorStop("Unsupported mrange is set on setDcIS()."); }

	UTL_SetDcPclamp   (hDc, pclamp);
	UTL_SetDcMclamp   (hDc, mclamp);

	UTL_SetDcLimitHigh(hDc, 0.0, UT_OFF);
	UTL_SetDcLimitLow (hDc, 0.0, UT_OFF);
	UTL_AddDcWetItem  (hDc, UT_DCT_MRANGE);
	SendDc_ForceWet   (hDc);
	UTL_DeleteHandle  (hDc);
}

void setDcISVM(double sval, enum eDC_IRNG srng, enum eDC_VRNG mrng, double pclamp, double mclamp, double hlimit, double llimit , int cnt)
{

	DcHandle hDc = UTL_GetDcHandle();
	UTL_SetDcMode     (hDc, UT_DCT_ISVM);
	UTL_SetDcSource   (hDc, sval);

	if     (srng==R20uA ) UTL_SetDcSrange   ( hDc,  20.0e-6,  -20.0e-6 );
	else if(srng==R200uA) UTL_SetDcSrange   ( hDc, 200.0e-6, -200.0e-6 );
	else if(srng==R2mA  ) UTL_SetDcSrange   ( hDc,   2.0e-3,   -2.0e-3 );
	else if(srng==R20mA ) UTL_SetDcSrange   ( hDc,  20.0e-3,  -20.0e-3 );
	else if(srng==Rm20mA) UTL_SetDcSrange   ( hDc,  10.0e-3,  -10.0e-3 );
	else{ ErrorStop("Unsupported srange is set on setDcISVM().");  }

	if(mrng==R20V)
		UTL_SetDcMrange   (hDc, 7, -0.3);
	else if(mrng==Rm20V)
		UTL_SetDcMrange   (hDc,  0.3, -7);
	else{ ErrorStop("Unsupported mrange is set on setDcIS()."); }

	UTL_SetDcPclamp   (hDc, pclamp);
	UTL_SetDcMclamp   (hDc, mclamp);

	UTL_SetDcLimitHigh(hDc, hlimit, UT_ON);
	UTL_SetDcLimitLow (hDc, llimit, UT_ON);
	UTL_SetDcMeasCnt  (hDc, cnt);
	UTL_AddDcWetItem  (hDc, UT_DCT_MRANGE);
	SendDc_ForceWet   (hDc);
	UTL_DeleteHandle  (hDc);
}

/****************************************************/
/*VS connection
/****************************************************/

void setVsOpen(int vsno)
{
	VsHandle Vs_H = UTL_GetVsHandle();
	UTL_SetVsMode    (Vs_H, UT_DCT_OPEN);
	UTL_SetVsLimitHigh    (Vs_H, 0, UT_OFF);
	UTL_SetVsLimitLow     (Vs_H, 0, UT_OFF);
	UTL_SendVs       (Vs_H, vsno);
	UTL_DeleteHandle (Vs_H);
}
void setVsDisconnect(char *vspins)
{
	PinHandle h = UTL_GetPinHandle ();
	UTL_SetPinSendMode(h, UT_PIN_PART);
	UTL_SetPinVsDisconnect(h, UT_ON);
	UTL_SendPin(h, vspins);
	UTL_DeleteHandle(h);
}
void setVsConnect(char *vspins)
{
	PinHandle h = UTL_GetPinHandle ();
	UTL_SetPinSendMode(h,UT_PIN_PART);
	UTL_SetPinVsDisconnect(h, UT_OFF);
	UTL_SendPin(h, vspins);
	UTL_DeleteHandle(h);
}
/****************************************************/
/*HV connection
/****************************************************/
void setHvUnMask(int vs_no)
{
	VsMaskHandle h = UTL_GetVsMaskHandle();
	MAC_LOOPDUT_START(UT_CDUT)
	{
		UTL_AddVsMaskDutVsMask(h, dut, vs_no, UT_OFF);
	}
	MAC_LOOPDUT_STOP
		UTL_SendVsMask(h);
	UTL_DeleteHandle(h);
}
void setHvMask(int vs_no)
{
	VsMaskHandle h = UTL_GetVsMaskHandle();
	MAC_LOOPDUT_START(UT_CDUT)
	{
		UTL_AddVsMaskDutVsMask(h, dut, vs_no, UT_ON);
	}
	MAC_LOOPDUT_STOP
		UTL_SendVsMask(h);
	UTL_DeleteHandle(h);
}

/****************************************************/
/*DC connection
/****************************************************/
void setDpinDcConnect(char* pinName)
{
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle (hPin);
	UTL_SetPinDcConnect     (hPin, UT_ON);
	UTL_SendPin             (hPin, pinName);
	UTL_DeleteHandle        (hPin);
}
void setDpinDcDisconnect(char* pinName)
{
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle (hPin);
	UTL_SetPinDcConnect     (hPin, UT_OFF);
	UTL_SendPin             (hPin, pinName);
	UTL_DeleteHandle        (hPin);
}

/****************************************************/
/*DC measurement
/****************************************************/
void setSettlingTime(double t, double t1, double t2)
{
	SettlingTimeHandle h = UTL_GetSettlingTimeHandle();
	UTL_SetSettlingTime(h, t);
	UTL_SetSettlingTimeAfterRon(h, t1);
	UTL_SetSettlingTimeAfterRof(h,  t2);
	UTL_SendSettlingTime(h);
	UTL_DeleteHandle(h);
}

void setSamplingRate(double t){
	SamplingRateHandle h = UTL_GetSamplingRateHandle();
	UTL_SetSamplingRate(h, t);
	UTL_SendSamplingRate(h);
	UTL_DeleteHandle(h);
}

void MeasPin(char *pinlist)
{    
	DctHandle h = UTL_GetDctHandle();
	UTL_SetDctPinList(h, pinlist);
	UTL_MeasDct (h);
	UTL_DeleteHandle(h);
} 
/****************************************************/
/*Read DCT data
/****************************************************/
void PrintHistoryData(char *pinlist, double unit, int meas_cnt)
{
	RadioButton pintype; 
	double data[2048];
	UTL_GetPinType(pinlist, &pintype);
	DctReadPinHandle h = UTL_GetDctReadPinHandle();
	UTL_SetDctReadPinType  (h, pintype);
	MAC_LOOPDUT_START(UT_CDUT)
		UTL_SetDctReadPinDut   (h, dut);
	MAC_LOOPPIN_START(pinlist)
		UTL_SetDctReadPinNumber(h, pin);
	UTL_ReadDctPinAllHistoryData(h, data, meas_cnt);
	for(int i=0;i<meas_cnt;i++){
		if(pintype == UT_PINTYPE_VS){
			Print("[DUT%d] 	%8s	data_point%4d: %f\n",dut, g_pinlist[pin].vsname,  i, data[i]/unit);
		}else{
			Print("[DUT%d] 	%8s	data_point%4d: %f\n",dut, g_pinlist[pin].pinname,  i, data[i]/unit);
		}
	}
	MAC_LOOPPIN_STOP
		MAC_LOOPDUT_STOP
		UTL_DeleteHandle(h);
}

void ReadHistoryData(int dut, char *pinlist, int meas_cnt, double *data)
{
	PinCursor pincur;
	UT_PIN pin;
	RadioButton pintype; 
	UTL_GetPinType(pinlist, &pintype);
	DctReadPinHandle h = UTL_GetDctReadPinHandle();
	UTL_SetDctReadPinDut   (h, dut);
	UTL_SetDctReadPinType  (h, pintype);
	pincur = UTL_GetPinCursor(pinlist);
	pin=UTL_NextPin(pincur);
	UTL_SetDctReadPinNumber(h, pin);
	UTL_ReadDctPinAllHistoryData(h, data, meas_cnt);
	UTL_DeleteHandle(h);
	UTL_DeleteCursor(pincur);
}

void PrintMeasData(char *pinlist, char *test_item, double unit, char* unitstr)    
{
	int ofdata[DUT_NUM];
	double data[DUT_NUM];
	UT_DUT sysdut;
	double hlimit, llimit;

	MAC_LOOPDUT_START(UT_CDUT)
	{
		PinCursor pincur;
		UT_PIN pin;
		DctReadPinHandle h = UTL_GetDctReadPinHandle();
		UTL_SetDctReadPinDut   (h, dut);
		RadioButton pintype; 
		UTL_GetPinType(pinlist, &pintype);
		UTL_SetDctReadPinType  (h, pintype);
		UTL_SetDctReadPinMode  (h,UT_RES_OVERFLOW); //for overflow pin
		pincur = UTL_GetPinCursor(pinlist);
		UTL_ConvertDutNumber(UT_SITEDUT,dut,UT_SYSDUT,NULL,&sysdut);
		while((pin=UTL_NextPin(pincur))!=UT_NOMORE)
		{
			UTL_SetDctReadPinNumber(h, pin);
			data[dut-1] = UTL_ReadDctPinData(h);
			ofdata[dut-1] = UTL_ReadDctPin(h); //for overflow pin
			if(pintype == UT_PINTYPE_VS){
				VsHandle vsh=UTL_GetVsHandle();
				UTL_UpdateVs(vsh, pin);
				UTL_GetVsLimitHigh(vsh, &hlimit);
				UTL_GetVsLimitLow(vsh, &llimit);
				UTL_DeleteHandle(vsh);
				if(ofdata[dut-1] !=0)//for overflow pin
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t        of\t%s\tSITE%2d\tSDUT%d\t*\n",dut, test_item, pin,g_pinlist[pin].vsname,unitstr,UTL_ReadSiteNumber(),sysdut);//for overflow pin
				else if(data[dut-1]<llimit||data[dut-1]>hlimit)
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t%6.6f\t%s\tSITE%2d\tSDUT%d\tF\n",dut, test_item, pin,g_pinlist[pin].vsname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
				else
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t%6.6f\t%s\tSITE%2d\tSDUT%d\tP\n",dut, test_item, pin,g_pinlist[pin].vsname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
			}
			else{
				DcHandle dch=UTL_GetDcHandle();
				UTL_UpdateDc(dch, 1);
				UTL_GetDcLimitHigh(dch, &hlimit);
				UTL_GetDcLimitLow(dch, &llimit);
				UTL_DeleteHandle(dch);
				if(ofdata[dut-1] !=0)//for overflow pin
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t        of\t%s\tSITE%2d\tSDUT%d\t*\n",dut, test_item, pin,g_pinlist[pin].pinname,unitstr,UTL_ReadSiteNumber(),sysdut);//for overflow pin
				else if(data[dut-1]<llimit||data[dut-1]>hlimit)
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t%6.3f\t%s\tSITE%2d\tSDUT%d\tF\n",dut, test_item, pin,g_pinlist[pin].pinname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
				else
					Print((char *)"[D0%d]\t%-15s\tPIN%-3d\t%20s\t%6.3f\t%s\tSITE%2d\tSDUT%d\tP\n",dut, test_item, pin,g_pinlist[pin].pinname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
			}
		}
		UTL_DeleteCursor(pincur);    
		UTL_DeleteHandle(h);
	}    
	MAC_LOOPDUT_STOP
}    

void PrintMeasData_FAtest(char *pinlist, char *test_item, double unit, char* unitstr, USlider IOflag)    
{
	int ofdata[DUT_NUM];
	double data[DUT_NUM];
	UT_DUT sysdut;
	double hlimit, llimit;
	USlider pin_count=0;
	USlider io_count=0;

	MAC_LOOPDUT_START(UT_CDUT)
	{
		PinCursor pincur;
		UT_PIN pin;
		DctReadPinHandle h = UTL_GetDctReadPinHandle();
		UTL_SetDctReadPinDut   (h, dut);
		RadioButton pintype; 
		UTL_GetPinType(pinlist, &pintype);
		UTL_SetDctReadPinType  (h, pintype);
		UTL_SetDctReadPinMode  (h,UT_RES_OVERFLOW); //for overflow pin
		pincur = UTL_GetPinCursor(pinlist);
		UTL_ConvertDutNumber(UT_SITEDUT,dut,UT_SYSDUT,NULL,&sysdut);
		while((pin=UTL_NextPin(pincur))!=UT_NOMORE)
		{
			if(pin_count%2 == 0){
				Print("##### IO%d #####:\n",IOflag + 8*io_count);
				io_count++;
			}
			pin_count++;
			UTL_SetDctReadPinNumber(h, pin);
			data[dut-1] = UTL_ReadDctPinData(h);
			ofdata[dut-1] = UTL_ReadDctPin(h); //for overflow pin
			DcHandle dch=UTL_GetDcHandle();
			UTL_UpdateDc(dch, 1);
			UTL_GetDcLimitHigh(dch, &hlimit);
			UTL_GetDcLimitLow(dch, &llimit);
			UTL_DeleteHandle(dch);
			if(ofdata[dut-1] !=0)//for overflow pin
				Print((char *)"[D0%d]\t%-15s\tPIN%2d\t%8s\t        of\t%s\tSITE%2d\tSDUT%d\t*\n",dut, test_item, pin,g_pinlist[pin].pinname,unitstr,UTL_ReadSiteNumber(),sysdut);//for overflow pin
			else if(data[dut-1]<llimit||data[dut-1]>hlimit)
				Print((char *)"[D0%d]\t%-15s\tPIN%2d\t%8s\t%6.3f\t%s\tSITE%2d\tSDUT%d\t*\n",dut, test_item, pin, g_pinlist[pin].pinname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
			else
				Print((char *)"[D0%d]\t%-15s\tPIN%2d\t%8s\t%6.3f\t%s\tSITE%2d\tSDUT%d\tP\n",dut, test_item, pin, g_pinlist[pin].pinname,data[dut-1]/(unit), unitstr,UTL_ReadSiteNumber(),sysdut);
		}
		UTL_DeleteCursor(pincur);    
		UTL_DeleteHandle(h);
	}    
	MAC_LOOPDUT_STOP
}   

void ReadMeasData(char *pinlist, double unit,double *data)
{

	PinCursor pincur;
	UT_PIN pin;
	DctReadPinHandle h = UTL_GetDctReadPinHandle();
	RadioButton pintype; 
	UTL_GetPinType(pinlist, &pintype);
	UTL_SetDctReadPinType  (h, pintype);
	UTL_SetDctReadPinMode  (h,UT_RES_OVERFLOW); //for overflow pin
	pincur = UTL_GetPinCursor(pinlist);
	pin=UTL_NextPin(pincur);
	UTL_SetDctReadPinNumber(h, pin);
	MAC_LOOPDUT_START(UT_CDUT)
		UTL_SetDctReadPinDut(h, dut);
	if(UTL_ReadDctPin(h)){//overflow 
		data[dut-1] = OVER_FLOW;
	}else{
		data[dut-1] = UTL_ReadDctPinData(h)/(unit);
	}
	MAC_LOOPDUT_STOP
		UTL_DeleteHandle(h);
	UTL_DeleteCursor(pincur);
}
void ReadMeasData2D(char *pinlist, double unit,double (*data)[DUT_NUM])
{
	DctReadPinHandle h = UTL_GetDctReadPinHandle();
	RadioButton pintype; 
	UTL_GetPinType(pinlist, &pintype);
	UTL_SetDctReadPinType  (h, pintype);
	UTL_SetDctReadPinMode  (h,UT_RES_OVERFLOW); //for overflow pin
	MAC_LOOPDUT_START(UT_CDUT)
		int i=0;
	MAC_LOOPPIN_START(pinlist)
		UTL_SetDctReadPinDut   (h, dut);
	UTL_SetDctReadPinNumber(h, pin);
	if(UTL_ReadDctPin(h)){//overflow 
		data[i][dut-1] = OVER_FLOW;
	}else{
		data[i][dut-1] = UTL_ReadDctPinData(h)/(unit);
	}
	i++;
	MAC_LOOPPIN_STOP
		MAC_LOOPDUT_STOP
		UTL_DeleteHandle(h);
}
