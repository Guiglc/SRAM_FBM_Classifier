#include "device.h"
#include "main.h"
#include <stdint.h>
#define MACRO_NUM  64
#define BEAT_PER_M 14

void Test_Mode_Select(char *pinlist, Mode_Choose mode)
{
	int	imode = mode; 

	MAC_LOOPPIN_START(pinlist)
		if(imode & 0X1)
			setDpinFixH(g_pinlist[pin].pinname, 1 ,VIH , VIL);      
		else
			setDpinFixL(g_pinlist[pin].pinname, 1 ,VIH , VIL);      
	imode = imode>>1;
	MAC_LOOPPIN_STOP
}


void Func_FCM(USlider WriExpValue,char *patname)
{
	/* FCM Config */
	ulConfigFcm("OUTPINS",FCM_AF,"Y0-Y3","X0-X14",NULL);//8192 -> 13bit , equal 1 Macro Size.
	ulPresetFcmAll();
	//Print("	#Total Fail Count");
	/* Run Pattern */
	run_alpg_pattern("pat_SRAM.mpa",patname);

	/* Get Fail Count */
	//	USlider FailCount = 0;
	//	ulGetFcmPfcByCount(0,32767,0,15,&FailCount);
	//	Print("	#Total Fail Count: %d\n",FailCount);
	//  if (FailCount == 0) {
	//    Print("#Total Fail Count: 0  -> [Result: PASS]\n");
	//  return; // 如果没有 Fail，直接结束函数，不跑后面的 50 万次循环
	// } else {
	//   Print("#Total Fail Count: %d -> [Result: FAIL]\n", FailCount);
	// }

	/* Get All FCM Result */
	//if(FK[2]){
//	Print("#Total Fail Address: \n");
	USlider FcmData_Low[16*512*64+256]={0};// 32 colunm * 256 row * 128 Macro. For Low 16 I/O, PinBlock 1
	USlider FcmData_High[16*512*64+256]={0};// 32 colunm * 256 row * 128 Macro. For High 16 I/O, PinBlock 2
	MAC_LOOPDUT_START(UT_CDUT)
	ulReadFcm(FcmData_Low, 	16*32768, 0, 32767, 0, 15, dut, UT_FCM_APLINK_YXZ,1);
	ulReadFcm(FcmData_High, 16*32768, 0, 32767, 0, 15, dut, UT_FCM_APLINK_YXZ,2);
	/* Get Fail Address */
	for(int i=0; i<16*512*64; i++){
		if((FcmData_Low[i] != 0) ||(FcmData_High[i] != 0)){
			int column = i & 0xF;
			int row    = (i>>4)&0x1FF;
			int macro  = (i>>13)&0x3F;
//			int address= row*32 +column;
			int address= i & 0x1FFF;
			USlider actual_32 =((USlider)FcmData_High[i]<<16)|FcmData_Low[i];
			char bin_str[33];
			for(int b=31;b>=0;b--){
				bin_str[31-b]=((actual_32>>b)&1)?'1':'0';
			}
			bin_str[32]='\0';
			Print("Macro:%-4dAddress:%-8dFailInfo:%s\n",macro,address,bin_str);
			fflush(stdout);
		}
	}
	MAC_LOOPDUT_STOP
		//}
}





void Func_FCM_BIST(char *patname)
{
	/* FCM Config */
	ulConfigFcm("OUTPINS", FCM_AF, "Y0-Y3","X9-X14", NULL);   // 仅 Y0~Y4 => 5bit address
	ulPresetFcmAll();

	/* Run Pattern */
	run_alpg_pattern("pat_SRAM.mpa", patname);

	USlider FcmData_Low[14*64]={0};// 32 colunm * 256 row * 128 Macro. For Low 16 I/O, PinBlock 1
	USlider FcmData_High[14*64]={0};// 32 colunm * 256 row * 128 Macro. For High 16 I/O, PinBlock 2
	MAC_LOOPDUT_START(UT_CDUT)
		ulReadFcm(FcmData_Low, 	16*64, 0, 63, 0, 13, dut, UT_FCM_APLINK_YXZ,1);
	ulReadFcm(FcmData_High, 16*64, 0, 63, 0, 13, dut, UT_FCM_APLINK_YXZ,2);
	/* Get Fail Address */
	uint32_t W[14*64]={0};
	for(int macro=0;macro<64;macro++){

		for(int i=14*macro; i<14*(macro+1); i++){
			W[i] = ((uint32_t)(FcmData_High[i] & 0xFFFF) << 16) |
				((uint32_t)(FcmData_Low[i]  & 0xFFFF));
			//		Print("MACRO:%d,DATA[%2d]: 0x%08X\n",macro, i-14*macro, W[i]);
					
		}

	}

	for(int macro=0;macro<64;macro++){


		uint32_t flags = W[14*macro] & 0x7;
		if(((flags>>2)&1)==1){
		Print("MACRO :%d  FLAGS: BEND=%u BBAD=%u BFAIL=%u\n",macro,
				(flags >> 2) & 1, (flags >> 1) & 1, (flags >> 0) & 1);
		}

		if((unsigned)(W[14*macro+1] & 0xFFFF)>0){
				Print("MACRO:%d \n",macro );
		uint32_t flags = W[14*macro] & 0x7;
		Print("FLAGS: BEND=%u BBAD=%u BFAIL=%u\n",
				(flags >> 2) & 1, (flags >> 1) & 1, (flags >> 0) & 1);
		Print("FAIL_COUNT: %u\n", (unsigned)(W[14*macro+1] & 0xFFFF));

		for (int err = 0; err < 4; err++)
		{
			
			int base = 14*macro + 2 + err * 3;

			uint32_t fail_data   = W[base + 0];
			uint32_t fail_addr   = W[base + 1] & 0x1FFF;   // low 13
			uint32_t exp_data    = W[base + 2];
			//				uint32_t fail_amount = W[base + 3] & 0x3FFFF;  // low 18
			char bin_str1[33];
			char bin_str2[33];
			for(int b=31;b>=0;b--){
				bin_str1[31-b]=((fail_data>>b)&1)?'1':'0';
				bin_str2[31-b]=((exp_data>>b)&1)?'1':'0';
			}
			bin_str1[32]=bin_str2[32]='\0';

			Print("BIST_ERR%d: MACRO=%-4daddr=%-8ddata=%s exp=%s\n",
					err + 1,macro,(unsigned)fail_addr,
					bin_str1,
					bin_str2
			     );
			//		
		}
}
	}
	MAC_LOOPDUT_STOP
	}




	void Func_FCM_QUAL(char *patname)
	{
		/* FCM Config */
		ulConfigFcm("OUTPINS",FCM_AF,"X0-X5","Y0-Y4",NULL);//8192 -> 13bit , equal 1 Macro Size.
		ulPresetFcmAll();

		/* Run Pattern */
		run_alpg_pattern("pat_SRAM.mpa",patname);

		/* Get Fail Count */
		USlider FailCount = 0;
		ulGetFcmPfcByCount(0,0,0,32,&FailCount);
		Print("	#Total Fail Count: %d\n",FailCount);
		/* Get All FCM Result */
		Print("	#Total Fail Address: \n");
		USlider FcmData_Low[16*512*64]={0};// 32 colunm * 256 row * 128 Macro. For Low 16 I/O, PinBlock 1
		USlider FcmData_High[16*512*64]={0};// 32 colunm * 256 row * 128 Macro. For High 16 I/O, PinBlock 2
		MAC_LOOPDUT_START(UT_CDUT)
			ulReadFcm(FcmData_Low,  16*64*18, 0, 64, 0, 32, dut, UT_FCM_APLINK_YXZ,1);
		ulReadFcm(FcmData_High, 16*64*18, 0, 64, 0, 32, dut, UT_FCM_APLINK_YXZ,2);

		/* 下面 W[] 拼接 + macro 打印逻辑保持你原来的 */
		uint32_t W[64 * 18];
		for (int k = 0; k < MACRO_NUM * BEAT_PER_M; k++)
		{
			W[k] = ((uint32_t)(FcmData_High[k] & 0xFFFF) << 16) |
				((uint32_t)(FcmData_Low[k]  & 0xFFFF));
		}

		for (int macro = 0; macro < MACRO_NUM; macro++)
		{
			int off = macro * BEAT_PER_M;

			uint32_t flags = W[off + 0] & 0x7;
			uint32_t BEND  = (flags >> 2) & 1;
			uint32_t BBAD  = (flags >> 1) & 1;
			uint32_t BFAIL = (flags >> 0) & 1;

			uint32_t fail_count = W[off + 1] & 0xFFFF;

			Print("MACRO%02d: FLAGS(BEND=%u BBAD=%u BFAIL=%u)  FAIL_COUNT=%u\n",
					macro, (unsigned)BEND, (unsigned)BBAD, (unsigned)BFAIL, (unsigned)fail_count);

			for (int err = 0; err < 4; err++)
			{
				int base = off + 2 + err * 4;

				uint32_t fail_data   = W[base + 0];
				uint32_t fail_addr   = W[base + 1] & 0x1FFF;
				uint32_t exp_data    = W[base + 2];
				uint32_t fail_amount = W[base + 3] & 0x3FFFF;

				Print("ERR%d: data=0x%08X addr=0x%04X exp=0x%08X amount=%u\n",
						err + 1,
						fail_data,
						(unsigned)fail_addr,
						exp_data,
						(unsigned)fail_amount);
			}
		}
		MAC_LOOPDUT_STOP
	}
