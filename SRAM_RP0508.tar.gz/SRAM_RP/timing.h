#ifndef __TIMING_H
#define __TIMING_H

void setTiming();
void setTiming1MHz();
void setTiming10MHz();
void setTiming5MHz();
void setTiming250KHz();

void setBaseRate(double val);

#endif
