#ifndef __DEVICE_H
#define __DEVICE_H

#include "main.h"

#define MEASURE_CNT	50

#define VSNO_VDD	4
#define VSNO_VDDM	1
#define VSNO_VDDM1	2
#define VSNO_VDDM2	3
#define VSNO_DVDD	5

#define VDD		1.2 V
#define VDDM	1.2 V
#define VDDM1	1.2 V
#define VDDM2	1.2 V
#define DVDD    1.2 V
#define VDDIO    1.2 V

#define VDD_1P08		1.08 V
#define VDDM_1P08	1.08 V
#define VDDM1_1P08	1.08 V
#define VDDM2_1P08	1.08 V
#define DVDD_1P08    1.08 V
#define VDDIO_1P08    1.08 V

#define VDD_1P32		1.32 V
#define VDDM_1P32	1.32 V
#define VDDM1_1P32	1.32 V
#define VDDM2_1P32	1.32 V
#define DVDD_1P32   1.32 V
#define VDDIO_1P32    1.32 V



#define VGND	0 V

#define VIL		0.0 V //fixed
#define VIH		1.2 V

#define OS_LOWER_FORCE_CURRENT -100 UA
#define OS_LOWER_LOW_LIMIT    -0.8  V
#define OS_LOWER_HIGH_LIMIT   	-0.2 V
#define OS_LOWER_NCLAMP    		-1.2 V
#define OS_LOWER_PCLAMP    		 0.6 V  // fixed

#define OS_UPPER_FORCE_CURRENT  100 UA
#define OS_UPPER_LOW_LIMIT    	0.2 V
#define OS_UPPER_HIGH_LIMIT   	0.8   V
#define OS_UPPER_NCLAMP   	   -0.6 V  // fixed
#define OS_UPPER_PCLAMP   		1.2 V


#define PS_HIGH_LIMIT   		50 UA
#define PS_LOW_LIMIT   		-50 UA

#define IIHL_NCLAMP   	   		-5 UA // related to I Meas Range
#define IIHL_PCLAMP   			5 UA // related to I Meas Range
#define IOHL_NCLAMP   	   		-5 UA // related to I Meas Range
#define IOHL_PCLAMP   			 5 UA // related to I Meas Range

#define IIHL_LOW_LIMIT   	   	-2 UA
#define IIHL_HIGH_LIMIT   		 2 UA 
#define IOHL_LOW_LIMIT   	   	-10 UA
#define IOHL_HIGH_LIMIT   		 10 UA 

#define ISB_VDDPM_LIMIT   		500  UA
#define ISB_VDDCM_LIMIT   		2000 UA
#define ISB_VDD_LIMIT   		150  UA
#define ISB_VDDIO_LIMIT   		20   UA

#define IDD_VDDPM_LIMIT   		3 MA
#define IDD_VDDCM_LIMIT   		2 MA
#define IDD_VDD_LIMIT   		3 MA
#define IDD_VDDIO_LIMIT   		2 MA


#define VOLTAGE_DROP	20 MV
#define WIDTH_DROP		5  NS

enum Mode_Choose{STDBYMOD = 0X03, RETENMOD = 0X01, FUNCMOD = 0X02, RWMOD = 0X06, WTMOD = 0X0E, FAMOD = 0X16};

enum FA_Choose{DBT0to3, DBT4to7, DBT8to11, DBT12to15,ERROR_ADDR};

void Test_Mode_Select(char *pinlist, Mode_Choose mode);
void AT_Change(char *pinlist, USlider data);
void Func_FCM(USlider WriExpValue,char *patname);
FA_Choose SetAdderss(USlider Addr);
void SetBLock(USlider Block);
void Func_FCM_BIST(char *patname);
void Func_FCM_QUAL(char *patname);



#endif
