#include "main.h"

////////////////////////
int FK[17]={0};
int g_die_X[DUT_NUM] = {0};
int g_die_Y[DUT_NUM] = {0};
char g_TestName[256]={0};
int g_NextSeq[DUT_NUM];
int g_BinNo[DUT_NUM] = {0};
char *g_BinName[DUT_NUM];
int g_Rejected[DUT_NUM] = {0};
double g_tRjectTitemTime[DUT_NUM];
int g_FlowDutActive[DUT_NUM]={0};
char *g_DeviceName = {'\0'};
char *g_LotNumber = {'\0'};
char *g_ProberID = {'\0'};
char *g_WaferId = {'\0'};
char *g_WaferSlotNumber = {'\0'};
int g_FirstRun=0;
unsigned int g_shotcounter;

void Dummy(){}

static void FlowPreProcess(int id)
{
	MAC_LOOPDUT_START(UT_MDUT)
		if(g_NextSeq[dut-1]==NEXT)
		{
			
			g_FlowDutActive[dut-1]=true;
		}
		else if (g_NextSeq[dut-1]==id)
		{
			g_FlowDutActive[dut-1]=true;			
		}
		else
		{
			g_FlowDutActive[dut-1]=false;			
		}			
	MAC_LOOPDUT_STOP

	ExclusionHandle exclusion_handle = UTL_GetExclusionHandle();
	//////////////////////////////// Reset Exclusion ////////////////////////////////
	UTL_SetExclusionSetOrReset(exclusion_handle, UT_OFF);
	UTL_ClearExclusionDut     (exclusion_handle );		
	if ((UTL_GetDutCount(UT_MDUT) - UTL_GetDutCount(UT_CDUT)) > 0 ) {			
		MAC_LOOPDUT_START(UT_MDUT)                                                     
			UTL_AddExclusionDut(exclusion_handle , dut);                           
		MAC_LOOPDUT_STOP                                                                
		UTL_SendExclusion(exclusion_handle);                                   
	}

	//////////////////////////////// Set   Exclusion ////////////////////////////////
	UTL_ClearExclusionDut     (exclusion_handle );                                 
	UTL_SetExclusionSetOrReset(exclusion_handle, UT_ON);			
	UTL_SetExclusionMask      (exclusion_handle, UT_OFF);                                  
	int exclusion_dut_count = 0;
	MAC_LOOPDUT_START(UT_MDUT)                      
		if(g_FlowDutActive[dut-1]==false) {
			UTL_AddExclusionDut(exclusion_handle , dut);
			exclusion_dut_count++;
		}
	MAC_LOOPDUT_STOP
	if (exclusion_dut_count ) UTL_SendExclusion(exclusion_handle);
	UTL_DeleteHandle          (exclusion_handle);

}

void RUN_TEST(int id, void (*func)(), char *tname, void (*pre_exec)(), void (*post_exec)(), int pass_branch, int fail_branch , int bin)
{
	unsigned int overflow;
	struct timespec t_start, t_end;
	double t;
	clock_gettime(CLOCK_REALTIME, &t_start);   
	FlowPreProcess(id);

	if(FK[11]==1){
		char str_pass_branch[20]={"\0"};
		char str_fail_branch[20]={"\0"};
		if(pass_branch==NEXT)sprintf(str_pass_branch,"%s","NEXT");
		else if(pass_branch==STOP)sprintf(str_pass_branch,"%s","STOP");
		else sprintf(str_pass_branch,"%d",pass_branch);
		if(fail_branch==NEXT)sprintf(str_fail_branch,"%s","NEXT");
		else if(fail_branch==STOP)sprintf(str_fail_branch,"%s","STOP");
		else sprintf(str_fail_branch,"%d",fail_branch);

		Print("*** %3d	%-30s	pass_branch=%4s, fail_branch=%4s, bin=%d\n", id, tname, str_pass_branch, str_fail_branch, bin);
		return;
	}

	if(UTL_GetDutCount(UT_CDUT) == 0) 
	{
		Print((char *)"no die is active......................%s\n", tname);
		return;
	}
	pre_exec();
//	Print("=============================Begin Test Block %-3d %-30s================================\n",id,tname);
	sprintf(g_TestName, "%d_%s", id, tname);
	{
		TestHandle h = UTL_GetTestHandle();
		UTL_SetTestAction(h, func);
		UTL_Test         (h, g_TestName);
		UTL_DeleteHandle (h);
	}
	post_exec();
	clock_gettime(CLOCK_REALTIME, &t_end);
	t = (double)(t_end.tv_sec - t_start.tv_sec) * 1e3 + ((double)(t_end.tv_nsec - t_start.tv_nsec) * 1e-6);
	MAC_LOOPDUT_START(UT_CDUT)
		Print((char *)"[D%02d] %-30s ETT %10.0f      %s", dut, g_TestName, t, UTL_ReadFinalResult(dut, UT_RES_ALL)==PASS? "P":"F");
		if ((UTL_ReadFinalResult(dut, UT_RES_ALL)!=PASS) && (fail_branch==NEXT))
		{
			Print((char *)" (force passed)\n");
		}
		else
		{
			Print((char *)"\n");
		}
	MAC_LOOPDUT_STOP

	MAC_LOOPDUT_START(UT_MDUT)
		if(g_FlowDutActive[dut-1]==true)
		{		
		if(FK[8]==1){
				g_NextSeq[dut-1] = NEXT;
				UTL_ResetFinalResultOnly(dut,UT_RES_ALL);
			}
			else if(UTL_ReadFinalResult(dut,UT_RES_ALL) == UT_RES_FAILED)
			{
				if(fail_branch == STOP)//bin out
				{
					g_BinNo[dut-1]=bin;				
					g_BinName[dut-1] = tname; 
					g_Rejected[dut-1]=1;
					UTL_SetCategory(dut, bin);
					UTL_SetRejection(dut, UT_OFF);
					g_tRjectTitemTime[dut-1] = UTL_ReadTimer(&overflow);
				}
				else						//force PASS
				{
					g_NextSeq[dut-1] = fail_branch;
					UTL_ResetFinalResultOnly(dut,UT_RES_ALL);
				}
			}
			else	
			{
				if(pass_branch == STOP)//bin out
				{
					g_BinNo[dut-1]=bin;				
					g_BinName[dut-1] = tname; 
					g_Rejected[dut-1]=1;
					UTL_SetCategory(dut, bin);
					UTL_SetRejection(dut, UT_OFF);
					g_tRjectTitemTime[dut-1] = UTL_ReadTimer(&overflow);
				}
				else						
				{
					g_NextSeq[dut-1] = pass_branch;
				}
			}
		}
	MAC_LOOPDUT_STOP
}


////////////////TYPE-SET///////////////////////
void SetRegValue(RadioButton reg, USlider value)
{
	RegHandle h = UTL_GetRegHandle();
	UTL_SetRegUs(h, reg, 1 ,value);
	UTL_SendReg(h);
	UTL_DeleteHandle(h);
}

int GetRegValue(RadioButton reg)	
{
	int Reg_Val;
	Reg_Val = UTL_ReadUSRegister(reg, 1);
	return(Reg_Val);	
}
////////////////TYPE-PRINT///////////////////////
void Print(const char *format, ... )
{
	va_list ap;
	va_start(ap, format );
	char* buf_ = NULL;
	vasprintf(&buf_, format, ap );
	fprintf(stdout, "%s", buf_ );
	fflush(stdout);
	free(buf_ );
	va_end(ap);
}
void DebugPrint(const char *format, ... )
{
	if(FK[15]==0)return;
	va_list ap;
	va_start(ap, format );
	char* buf_ = NULL;
	vasprintf(&buf_, format, ap );
	fprintf(stdout, "%s", buf_ );
	fflush(stdout);
	free(buf_ );
	va_end(ap);
}


void ErrorStop(const char *format, ... )
{
	va_list ap;
	va_start(ap, format );
	char* buf_ = NULL;
	vasprintf(&buf_, format, ap );
	fprintf(stderr,"<--*****************ERROR********************\n");
	fprintf(stderr, "%s", buf_ ); 
	fprintf(stderr,"********************ERROR********************-->\n");fflush(stderr);
	free(buf_ );
	va_end(ap);
	UTL_Stop();
}


////////////////TYPE-FLOW////////////////////////
int ReadFk(int fknum)
{
	char svname[100];
	char *rdata, label[5], *value;
	UTSC_size_t size;
	UTSC_Pf pfdesc;
	UT_LKstream lks, lobj;
	int stn, st, ival = UT_OFF;


	pfdesc = NULL;
	lks = NULL;

	if ((st = UTSC_Pf_Open(&pfdesc, NULL)) != 0)
	{
		Print("%s:%d %d\n", __FILE__, __LINE__, st);
		goto END;
	}

	stn = UTL_ReadStationNumber();
	sprintf(svname, "UTPFV_SystemValue_FK%d", stn);
	if ((st = UTSC_Pf_ReadData(pfdesc, svname, (void **)&rdata, &size)) != 0)
	{
		Print("%s:%d %d\n", __FILE__, __LINE__, st);
		goto END;
	}
	if ((st = UTHN_LKstream_Construct(&lks, rdata)) != UTHN_LKSTREAM_OK)
	{
		Print("%s:%d %d\n", __FILE__, __LINE__, st);
		goto END;
	}

	snprintf(label, sizeof(label), "FK%d", fknum);
	if ((st = UTHN_LKstream_FindLabel(lks, label, &lobj)) != UTHN_LKSTREAM_OK)
	{
		Print("%s:%d %d\n", __FILE__, __LINE__, st);
		goto END;
	}
	if ((st = UTHN_LKstream_FindKey(lobj, "switch", &value)) != UTHN_LKSTREAM_OK)
	{
		Print("%s:%d %d\n", __FILE__, __LINE__, st);
		goto END;
	}
	if (strcmp(value, "on") == 0)
		ival = UT_ON;
	else
		ival = UT_OFF;

END:
	if(lks )
	{
		if ((st = UTHN_LKstream_Destruct(lks)) != UTHN_LKSTREAM_OK)
			Print("%s:%d %d\n", __FILE__, __LINE__, st);
	}
	if(pfdesc )
	{
		if ((st = UTSC_Pf_Close(pfdesc)) != 0)
			Print("%s:%d %d\n", __FILE__, __LINE__, st);
	}
	return ival;
}

void PowerON()
{
	UTL_OnPowerSeq();
	UTL_SetWet();
	if(FK[3]) { Print("%-36s ReON </\\>\n",g_TestName);}
}

void PowerOFF()
{
	UTL_OffPowerSeq();
	UTL_ResetWet();
	if(FK[3]) { Print("%-36s ReOF <\\/>\n",g_TestName);}
}

void SaveDutGroupToArray(UT_DUT DutArray[] ,int dutgroup)
{
	MAC_LOOPDUT_START(dutgroup)
		if(dut<=DUT_NUM && dut>=1)
		{
			DutArray [dut-1]=1;
		}
		else
		{
			ErrorStop("DutNum(%d) is bigger than Array length(%d)!\n",dut,DUT_NUM );
		}
	MAC_LOOPDUT_STOP

}

////////////////TYPE-OTHER////////////////////////
int GetMeasResult(int dut)
{
	if(UTL_ReadMeasResult(dut) == UT_RES_PASSED)
	{
		return PASS;
	}
	else if(UTL_ReadMeasResult(dut) == UT_RES_NOT_TESTED)
	{
		return NOTTEST;
	}
	else
	{
		return FAIL;
	}
}

int GetFinalResult(int dut)
{
	if(UTL_ReadFinalResult(dut,UT_RES_ALL) == UT_RES_PASSED)
	{
		return PASS;
	}
	else if(UTL_ReadFinalResult(dut,UT_RES_ALL) == UT_RES_NOT_TESTED)
	{
		return NOTTEST;
	}
	else
	{
		return FAIL;
	}

}

void SetFinalResultOnly(int dut, int result)
{
	if(result == FAIL)
	{
		UTL_SetFinalResultOnly(dut, UT_RES_ALL);
	}
	else
	{
		UTL_ResetFinalResultOnly(dut, UT_RES_ALL);
	}
}

void SetFinalResultOnlyAllDut(int result)
{
	if(result == FAIL)
	{
		MAC_LOOPDUT_START(UT_CDUT)
			UTL_SetFinalResultOnly(dut, UT_RES_ALL);
		MAC_LOOPDUT_STOP
	}
	else
	{
		MAC_LOOPDUT_START(UT_CDUT)
			UTL_ResetFinalResultOnly(dut, UT_RES_ALL);
		MAC_LOOPDUT_STOP
	}
}

void SetFinalResultOnlyByDutMask(int dut_mask[], int result) {
	int cdut_array[DUT_NUM];
	DebugPrint("\n         : %-40s:%10s:", "", "DUT");
	MAC_LOOPDUT_START(UT_DDUT)
		DebugPrint("%3d ", dut);	
	MAC_LOOPDUT_STOP
	DebugPrint("\n");
	SaveDutGroupToArray(cdut_array ,UT_CDUT);
	DebugPrint("TEST NAME: %-40s:%10s:", UTL_ReadTestName(), "Result");
	MAC_LOOPDUT_START(UT_DDUT)
		if(cdut_array[dut-1] == 0||dut_mask[dut-1]==0){
			DebugPrint("  - ");
		}
		else if(result==FAIL) {
			if(dut_mask[dut-1]==1){
				UTL_SetFinalResult(dut, UT_RES_ALL);
				DebugPrint("  F ");}
		}
		else{
			if(dut_mask[dut-1]==1){
				UTL_ResetFinalResult(dut, UT_RES_ALL);
				DebugPrint("  P ");}
		}
	MAC_LOOPDUT_STOP
	DebugPrint("\n");
}
void SetIlMode(int ilmode)
{
	IlModeHandle h = UTL_GetIlModeHandle();
	UTL_SetIlMode(h, ilmode);
	UTL_SendIlMode(h);
	UTL_DeleteHandle(h);

}

int ReadResult(UT_DUT f){
	int flag = 0;
	if( UTL_ReadMeasResult(f)==UT_RES_PASSED){
		flag=1;
			};
		return flag;
		}
void run_alpg_pattern(char *patfile, char *startlabel)
{
	char pat_path[50] ;
	USlider pc;
	RadioButton rtn;
	sprintf(pat_path, "./patterns/%s", patfile);
	if(FK[16]==1) Print("	-> Run alpg pattern =  %s <-\n", startlabel); 
	ReadMpatPcHandle pch = UTL_GetReadMpatPcHandle();
	UTL_SetReadMpatStartName      (pch, startlabel);
	UTL_SetReadMpatFileName       (pch, pat_path);
	rtn = UTL_ReadMpatStartPc     (pch, &pc);
	if(rtn == UT_NOT_FOUND )
	{
		ErrorStop("runtest_pattern:  start label \"%s\" was not found in pat file %s\n", startlabel, patfile);
		assert(rtn == UT_FOUND);
	}
	UTL_DeleteHandle(pch);

	FctHandle h = UTL_GetFctHandle();
	UTL_SetFctFailInhibit(h, UT_ON);
	UTL_SetFctMpatName   (h, pat_path);
	UTL_SetFctStartPc    (h, pc);
	UTL_MeasFct(h);
	UTL_DeleteHandle(h);
}

void start_alpg_pattern_nowait(char *patfile, char *startlabel)
{
	char pat_path[50];
	USlider pc;
	RadioButton rtn;
	sprintf(pat_path, "./patterns/%s", patfile);
	if(FK[16]==1) Print("	-> Start alpg pattern nowait =  %s <-\n", startlabel); 
	ReadMpatPcHandle pch = UTL_GetReadMpatPcHandle();
	UTL_SetReadMpatStartName      (pch, startlabel);
	UTL_SetReadMpatFileName       (pch, pat_path);
	rtn = UTL_ReadMpatStartPc     (pch, &pc);
	if(rtn == UT_NOT_FOUND )
	{
		ErrorStop("runtest_pattern:  start label \"%s\" was not found in pat file %s\n", startlabel, patfile);
		assert(rtn == UT_FOUND);
	}
	UTL_DeleteHandle(pch);

	FctHandle h = UTL_GetFctHandle();
	UTL_SetFctFailInhibit(h, UT_ON);
	UTL_SetFctMpatName   (h, pat_path);
	UTL_SetFctStartPc    (h, pc);
	UTL_SetFctNoWait(h, UT_ON);
	UTL_StartFct(h);
//	UTL_MeasFct(h);
	UTL_DeleteHandle(h);
}
#if 0
int GetAllMeasResult()
{
	int result =0;
	MAC_LOOPDUT_START(UT_DUT)
		if(UTL_ReadMeasResult(dut) == UT_RES_FAILED)
		{
			result |= (1<<(dut-1));

		}
	MAC_LOOPDUT_STOP
	return result;	
}
#endif
void start_alpg_pattern(char *patfile, char *startlabel)
{
	char pat_path[50] ;
	USlider pc;
	RadioButton rtn;
	sprintf(pat_path, "./patterns/%s", patfile);
	if(FK[16]==1) Print("	-> Start alpg pattern =  %s <-\n", startlabel); 
	ReadMpatPcHandle pch = UTL_GetReadMpatPcHandle();
	UTL_SetReadMpatStartName      (pch, startlabel);
	UTL_SetReadMpatFileName       (pch, pat_path);
	rtn = UTL_ReadMpatStartPc     (pch, &pc);
	if(rtn == UT_NOT_FOUND )
	{
		ErrorStop("runtest_pattern:  start label \"%s\" was not found in pat file %s\n", startlabel, patfile);
		assert(rtn == UT_FOUND);
	}
	UTL_DeleteHandle(pch);
	FctHandle h =UTL_GetFctHandle();
	UTL_SetFctFailInhibit(h, UT_ON);
	UTL_SetFctMpatName   (h, pat_path);
	UTL_SetFctStartPc    (h, pc);
	UTL_SetFctNoWait(h, UT_OFF);
	UTL_StartFct(h);
	UTL_DeleteHandle(h);
}
void continue_start_alpg_pattern()
{
	FctHandle	h = UTL_GetFctHandle();
	UTL_SetFctContinue(h, UT_ON);
	UTL_StartFct(h);
	UTL_DeleteHandle(h);
}
void continue_meas_alpg_pattern()
{
	FctHandle	h = UTL_GetFctHandle();
	UTL_SetFctContinue(h, UT_ON);
	UTL_MeasFct(h);
	UTL_DeleteHandle(h);
}
void stop_alpg_pattern()
{
	UTL_StopFct();
}

void pause()
{
	char buf[100];
	printf("please enter the key to continue...");
	fflush(stdout);
	fgets(buf, 100, stdin);
}

void pause2(char *fmt, ...)
{
	va_list ap;
	char buf[100];
	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
	fflush(stdout);
	fgets(buf, 100, stdin);
}

void pause3(char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
	fflush(stdout);
	UTL_CheckRepeatPause();
}

void SetDutsRejection (int reject_array[])
{
	RejectionHandle hex = UTL_GetRejectionHandle();
	UTL_SetRejectionIgnoreWet  (hex,UT_ON);  //roff

	MAC_LOOPDUT_START(UT_SDUT)
	{
		if (reject_array[dut-1])	{
			UTL_AddRejectionDut(hex,dut);
			DebugPrint((char *)"Permanently Reject DUT %d\n", dut);
		}
	}
	MAC_LOOPDUT_STOP
	UTL_SendRejection(hex);
	UTL_DeleteHandle(hex);
}

void SetDutsExclusion (int exclude_array[])
{
	PinCursor pc;
	UT_PIN pin;
	pc = UTL_GetPinCursor ("CLK");
	pin=UTL_NextPin(pc);
	UTL_DeleteCursor(pc);
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();

	ExclusionHandle hex = UTL_GetExclusionHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXH); //Validate before updata pinhandle
	UTL_SetExclusionIgnoreWet  (hex,UT_OFF);
	UTL_SetExclusionMask       (hex,UT_OFF);

	MAC_LOOPDUT_START(UT_CDUT)
	{
		if (exclude_array[dut-1])
		{
			UTL_AddExclusionDut(hex,dut);
			UTL_SendLevelFix(level_fix_handle, pin, dut);
			DebugPrint((char *)"Temporarily Excluded DUT %d\n", dut);
		}
	}
	MAC_LOOPDUT_STOP
	UTL_SetExclusionSetOrReset (hex,UT_ON);
	UTL_SendExclusion(hex);

	UTL_DeleteHandle(hex);
	UTL_DeleteHandle(level_fix_handle);
}

void SetDutsExclusion_rof(int exclude_array[])
{
	PinCursor pc;
	UT_PIN pin;
	pc = UTL_GetPinCursor ("CLK");
	pin=UTL_NextPin(pc);
	UTL_DeleteCursor(pc);
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();

	ExclusionHandle hex = UTL_GetExclusionHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXH); //Validate before updata pinhandle
	UTL_SetExclusionIgnoreWet  (hex,UT_OFF);
	UTL_SetExclusionMask       (hex,UT_ON);

	MAC_LOOPDUT_START(UT_CDUT)
	{
		if (exclude_array[dut-1])
		{
			UTL_AddExclusionDut(hex,dut);
			UTL_SendLevelFix(level_fix_handle, pin, dut);
			DebugPrint((char *)"Temporarily Excluded DUT %d\n", dut);
		}
	}
	MAC_LOOPDUT_STOP
	UTL_SetExclusionSetOrReset (hex,UT_ON);
	UTL_SendExclusion(hex);

	UTL_DeleteHandle(hex);
	UTL_DeleteHandle(level_fix_handle);
}

void ResetDutsExclusion (int recover_array[])
{
	PinCursor pc;
	UT_PIN pin;
	pc = UTL_GetPinCursor ("CLK");
	pin=UTL_NextPin(pc);
	UTL_DeleteCursor(pc);
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();

	ExclusionHandle hex = UTL_GetExclusionHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_NONE);
	UTL_SetExclusionIgnoreWet  (hex,UT_OFF);

	MAC_LOOPDUT_START(UT_MDUT)
	{
		if (recover_array[dut-1])
		{
			UTL_AddExclusionDut(hex,dut);
			UTL_SendLevelFix(level_fix_handle, pin, dut);
			DebugPrint((char *)"Recovered DUT %d\n", dut);
		}
	}
	MAC_LOOPDUT_STOP
	UTL_SetExclusionSetOrReset (hex,UT_OFF);
	UTL_SendExclusion(hex);

	UTL_DeleteHandle(hex);
	UTL_DeleteHandle(level_fix_handle);
}

void SetPinLevelFixl(char *pinlist){
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXL);
	MAC_LOOPPIN_START(pinlist)
		MAC_LOOPDUT_START(UT_CDUT)
			UTL_SendLevelFix(level_fix_handle, pin, dut);
		MAC_LOOPDUT_STOP
	MAC_LOOPPIN_STOP
	UTL_DeleteHandle  (level_fix_handle);
}
void SetPinLevelFixh(char *pinlist){
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_FIXH);
	MAC_LOOPPIN_START(pinlist)
		MAC_LOOPDUT_START(UT_CDUT)
			UTL_SendLevelFix(level_fix_handle, pin, dut);
		MAC_LOOPDUT_STOP
	MAC_LOOPPIN_STOP
	UTL_DeleteHandle  (level_fix_handle);
}
void SetPinLevelNone(char *pinlist){
	LevelFixHandle level_fix_handle = UTL_GetLevelFixHandle();
	UTL_SetLevelFixOutputLevel(level_fix_handle, UT_PIN_DR, UT_PIN_NONE);
	MAC_LOOPPIN_START(pinlist)
		MAC_LOOPDUT_START(UT_CDUT)
			UTL_SendLevelFix(level_fix_handle, pin, dut);
		MAC_LOOPDUT_STOP
	MAC_LOOPPIN_STOP
	UTL_DeleteHandle  (level_fix_handle);
}

char* getSymbol(char* name){
	if(UTL_ReadSymbol(name) != NULL){
		return UTL_ReadSymbol(name);
	}else{
		Print("%s is not found\n", name);
		return NULL;
	}
}

void setSymbol(char* name, char* value){
	UTL_SendSymbol(name, value);
}
int parse_xylist(char *xy_list, char xy_deli, int xybit[])
{
	char *p, *q, *t;
	int start, end;
	int i, idx = 0;

	q = (char*)malloc(strlen(xy_list) + 1);

	sprintf(q,"%s", xy_list);
	p = strtok(q, (char *)",");
	while(p)
	{
		//printf((char *)"%s\n", p);
		if(strstr(p, (char *)"-"))
		{
			t = strchr(p, xy_deli);
			start = atoi(t + 1);
			t = strrchr(p, xy_deli);
			end = atoi(t + 1);
			if(start <= end)
			{
				for(i = start; i <= end; i++)
				{
					xybit[idx++] = i;
				}
			}
			else
			{
				for(i = start; i >= end; i--)
				{
					xybit[idx++] = i;
				}
			}
		}
		else
		{
			t = strchr(p, xy_deli);
			xybit[idx++] = atoi(t + 1);
		}
		p = strtok(NULL, (char *)",");
	}

	free(q);
	return idx;
}
