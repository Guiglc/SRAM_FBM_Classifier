#ifndef __PINLIST_H
#define __PINLIST_H

typedef struct
{
	char pinname[100];
	int pinno;
	char vsname[100];
	int vsno;
} PIN_STRUCT;

extern PIN_STRUCT g_pinlist[300];
extern void PinList();

#endif
