ls -a
rm .*swp*
rm .*swo*
rm .*swx*
rm core.*
