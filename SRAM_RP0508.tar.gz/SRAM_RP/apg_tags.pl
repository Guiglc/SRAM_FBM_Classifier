#!/usr/perl/bin -w
use Cwd;
use File::Find;
use File::Spec;

# -----------------------------------------------------------------------------------------
sub ScanPatternFiles()
{
	open(IN, $FileName) || die $!;
	print "\t$FileName\n";

	$LineCount = 0; 
			
	while(<IN>)             #Read file line by line
	{
		$LineCount++;    

		chomp $_;
		s/\/\/.*//;  # eliminate // comments
		s/^\s+//;    # Removed leading whitespace 
		s/\;.*//;    # eliminate ; comments

		# if line is empty - continue processing while loop
		if (!$_)
		{
			next;
		}

		# split the line - want check if first word is a label
		@tmp_split = split(/\s+/);
		$_ = $tmp_split[0];

		# if a line begins with 'start' the next word is a pattern label (Advantest)
		# Example:  'start patt_label'
		if(/^START\b/ )
		{
			#if the next word is 'empty' then there is no label to process
			if( !$tmp_split[1] )
			{
				next;
			}
			$TagStringLabel[$TagStringCount] = $tmp_split[1];
			$TagString[$TagStringCount] = "$tmp_split[1]\t$FileName\t$LineCount;\"\td\n";
			$TagStringCount++;
		} 

		# if a line begins with '#define' the next word is a pattern label (Advantest)
		# Example:  '#define patt_define 0x1'
		#if(/^\#define\b/ )
		#{
		#	#if the 2nd word is 'empty' then the string is "#define patt_define'
		#	if( !$tmp_split[2] )
		#	{
		#		next;
		#	}
		#	$TagStringLabel[$TagStringCount] = $tmp_split[1];
		#	$TagString[$TagStringCount] = "$tmp_split[1]\t$FileName\t$LineCount;\"\td\n";
		#	$TagStringCount++;
		#}

		
		# if a line begins with 'SDEF' the next word is a pattern label (Advantest)
		# Example:  SDEF    ADDR1_IN          =         C2          C4           C6 
		if(/^SDEF\b/ )
		{
			#if the 2nd word is 'empty' then the string is "#define patt_define'
			if( !$tmp_split[1] )
			{
				next;
			}
			
			#Special handle for same tag in patsub.asc
			unless ( $tmp_split[1] eq "DATA_IN" || $tmp_split[1] eq "DATA_OUT") 
			{
				$TagStringLabel[$TagStringCount] = $tmp_split[1];
				$TagString[$TagStringCount] = "$tmp_split[1]\t$FileName\t$LineCount;\"\td\n";
				$TagStringCount++;				
			}
		} 

		# Find label or entry point in the pattern file - defined by the colon ':'
		# rindex() will find the rightmost occurance of the search string search. In this case
		# the search string is ":". rindex() returns -1 if the search string is not found
		# If a lable is found, keep chopping off the last character until done

		#@tmp_split = split(/\s+/);
		#$_ = $tmp_split[0];


		#if(!$_)
		#{
		#	next;
		#}

		$idx = rindex($_,":");
		if($idx != -1 ) 
		{
        
			while($idx != -1)
			{
				chop $_;
				$idx = rindex($_,":"); 
			}

			if(!$_)
			{
				; #print "Non label string .... $_\n";
			}
			else
			{
				$TagStringLabel[$TagStringCount] = $_;
				$TagString[$TagStringCount] = "$_\t$FileName\t$LineCount;\"\td\n";
				$TagStringCount++;
				if($GenerateUnderscore)
				{
					$TagStringLabel[$TagStringCount] = $_;
					$TagString[$TagStringCount] = "_$_\t$FileName\t$LineCount;\"\td\n";
					$TagStringCount++;
				}
        
			}
		}

	}
	close(IN);

}
# -----------------------------------------------------------------------------------------
# Open the tags file and add existing entries to the tags string array
sub ReadTagsFile()
{

	print "Reading existing tags file .....\n";

	open(IN_FILEHANDLE, "tags") || die $!;

	while(<IN_FILEHANDLE>)
	{
		if(/^!_TAG/)
		{
			# The TAG_FILE_SORTED parameter neeDBM_SEL to be '0' for an unsorted tags file
			if (/^!_TAG_FILE_SORTED/)
			{
				@tmp_split = split(/\s+/);
				if($tmp_split[1] == 1 )
				{
					s/1/0/;
				}
			}

			$TagHeader[$TagHeaderCount] = $_;
			$TagHeaderCount++;

		}
		else
		{

			$TagString[$TagStringCount] = $_;
			@tmp_split = split(/\s+/);
			$tmp_string = $tmp_split[0];
			$TagStringLabel[$TagStringCount] = $tmp_string;
			$TagStringCount++;
		}
	}
	close(IN_FILEHANDLE);
}



# -----------------------------------------------------------------------------------------
# Write the TagString arrray back to the tags files
# Assumption - the 'tags' file has beed deleted

sub WriteTagsFile()
{
	print "Writing tags .....\n";
	open(FILEHANDLE, ">tags") || die $!; 


	for($i = 0; $i < $TagHeaderCount; $i++)
	{
		print FILEHANDLE "$TagHeader[$i]";
	}


	for($i = 0; $i < $TagStringCount; $i++)
	{
		print FILEHANDLE "$TagString[$i]";
	}


	close(FILEHANDLE);
}
# -----------------------------------------------------------------------------------------
# Use simple bubble sort to re-order the tag strings
sub sort_tags()
{
	print "Sorting tags .....\n";
	for($i = 0; $i < $TagStringCount; $i++)
	{
		for($j = $i+1; $j < $TagStringCount; $j++)
		{
			# swap strings to put in sorted order 
			if( $TagStringLabel[$i] gt $TagStringLabel[$j] )
			{
				$tmp_label = $TagStringLabel[$i];
				$tmp_string = $TagString[$i];

				$TagStringLabel[$i] = $TagStringLabel[$j];
				$TagString[$i]      = $TagString[$j];

				$TagStringLabel[$j] = $tmp_label;
				$TagString[$j]      = $tmp_string;

			}

		}
	}

	for($i = 0 ; $i < $TagHeaderCount ; $i++)
	{
		if($TagHeader[$i] =~ /^!_TAG_FILE_SORTED/)
		{
			$TagHeader[$i] =~ s/0/1/; 
		}
	}
}
# -----------------------------------------------------------------------------------------
# MAIN BODY

$TagStringCount = 0;        # Count the number of tag entries
$TagHeaderCount = 0;
$FileName = "";
$GenerateUnderscore = "";

sub loopFile {
	if(/.apg$/)
	{
#		$FileName = File::Spec->abs2rel($File::Find::name, getcwd) ;
		$FileName = $File::Find::name;
		s/.apg$// ;
		$TagStringLabel[$TagStringCount] = $_;
		$TagString[$TagStringCount] = "$_\t$FileName\t0;\"\td\n";
		$TagStringCount++;

		$GenerateUnderscore = "YES";
		ScanPatternFiles();
	}
	elsif(/.asc$/)
	{
#		$FileName = File::Spec->abs2rel($File::Find::name, getcwd) ;
		$FileName = $File::Find::name;
		s/.asc$// ;
		$TagStringLabel[$TagStringCount] = $_;		
		$TagString[$TagStringCount] = "$_\t$FileName\t0;\"\td\n";		
		$TagStringCount++;
		$GenerateUnderscore = "";
		ScanPatternFiles();
	}
}

my $ctag_path = "ctags";
system("$ctag_path", "-R");

ReadTagsFile();           # Import the existing tags file and build list of tags entries

find(\&loopFile, getcwd);  # Loop through the current directory to build the new tags entries

sort_tags();                # Sort new and old tag entries and prepare to write new tags files

unlink "tags";               # erase the original tags file

WriteTagsFile();          # And write a new tags files




