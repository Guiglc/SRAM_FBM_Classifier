#include <stdio.h>
int main(){ puts("hello from centos7"); return 0; }
