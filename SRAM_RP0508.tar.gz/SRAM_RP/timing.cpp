#include "main.h"
void setTiming()
{
	//setBaseRate(5 NS);

	TgHandle h = UTL_GetTgHandle();

	int ts, i;
	double
		RATE[] = {100 NS, 200 NS, 1000 NS, 4000 NS},
		BCLK1[] = {10 NS, -1 NS, 100 NS, 0 NS}, // DIN
		BCLK2[] = {10 NS, 0 NS, 100 NS, 0 NS},	// ADDRESS WT
		CCLK2[] = {0 NS, -1 NS, 0 NS, 0 NS},	// ADDRESS RT
		BCLK3[] = {0 NS, 0 NS, 0 NS, 0 NS},		// CLK

		CCLK3[] = {50 NS, 100 NS, 500 NS, 1500 NS}, // CLK
		BCLK4[] = {-1 NS, -1 NS, -1 NS, -1 NS},		// SAET
		CCLK4[] = {-1 NS, -1 NS, -1 NS, -1 NS},		// SAET
		STRB1[] = {90 NS, 75 NS, 900 NS, 1500 NS},	// DOUT
		STRB2[] = {90 NS, 150 NS, 900 NS, 1500 NS}, // DOUT
		DREL1[] = {-1 NS, -1 NS, -1 NS, -1 NS},
		DRET1[] = {-1 NS, -1 NS, -1 NS, -1 NS};

	for (ts = 1, i = 0; ts <= sizeof(RATE) / sizeof(double); ts++, i++)
	{
		UTL_AddTgRate(h, ts, RATE[i]);
		if (BCLK1[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 1, BCLK1[i]);
		}
		if (BCLK2[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 2, BCLK2[i]);
		}
		if (CCLK2[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 2, CCLK2[i]);
		}
		if (BCLK3[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 3, BCLK3[i]);
		}
		if (CCLK3[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 3, CCLK3[i]);
		}
		if (BCLK4[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 4, BCLK4[i]);
		}
		if (CCLK4[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 4, CCLK4[i]);
		}
		if (STRB1[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 1, STRB1[i]);
		}
		if (STRB2[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 2, STRB2[i]);
		}
		if (DREL1[i] < 0)
		{
			UTL_AddTgDreLOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreL(h, ts, 1, DREL1[i]);
		}
		if (DRET1[i] < 0)
		{
			UTL_AddTgDreTOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreT(h, ts, 1, DRET1[i]);
		}
	}
	UTL_SendTg(h);
	UTL_DeleteHandle(h);
}
void setTiming250KHz()
{
	//setBaseRate(8 NS);

	TgHandle h = UTL_GetTgHandle();

	int ts, i;
	double
		RATE[] = {4000 NS},
		BCLK1[] = {0 NS}, // DIN
		BCLK2[] = {0 NS}, // ADDRESS WT
		CCLK2[] = {0 NS}, // ADDRESS RT
		BCLK3[] = {0 NS}, // CLK

		CCLK3[] = {2000 NS}, // CLK
		BCLK4[] = {-1 NS},	 // SAET
		CCLK4[] = {-1 NS},	 // SAET
		STRB1[] = {3600 NS}, // DOUT
		STRB2[] = {3600 NS}, // DOUT
		DREL1[] = {-1 NS},
		DRET1[] = {-1 NS};

	for (ts = 1, i = 0; ts <= sizeof(RATE) / sizeof(double); ts++, i++)
	{
		UTL_AddTgRate(h, ts, RATE[i]);
		if (BCLK1[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 1, BCLK1[i]);
		}
		if (BCLK2[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 2, BCLK2[i]);
		}
		if (CCLK2[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 2, CCLK2[i]);
		}
		if (BCLK3[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 3, BCLK3[i]);
		}
		if (CCLK3[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 3, CCLK3[i]);
		}
		if (BCLK4[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 4, BCLK4[i]);
		}
		if (CCLK4[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 4, CCLK4[i]);
		}
		if (STRB1[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 1, STRB1[i]);
		}
		if (DREL1[i] < 0)
		{
			UTL_AddTgDreLOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreL(h, ts, 1, DREL1[i]);
		}
		if (DRET1[i] < 0)
		{
			UTL_AddTgDreTOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreT(h, ts, 1, DRET1[i]);
		}
	}
	UTL_SendTg(h);
	UTL_DeleteHandle(h);
}
void setTiming1MHz()
{
	//setBaseRate(8 NS);

	TgHandle h = UTL_GetTgHandle();

	int ts, i;
	double
		RATE[] = {1000 NS},
		BCLK1[] = {100 NS}, // DIN
		BCLK2[] = {100 NS}, // ADDRESS WT
		CCLK2[] = {0 NS},	// ADDRESS RT
		BCLK3[] = {0 NS},	// CLK

		CCLK3[] = {500 NS}, // CLK
		BCLK4[] = {-1 NS},	// SAET
		CCLK4[] = {-1 NS},	// SAET
		STRB1[] = {900 NS}, // DOUT
		STRB2[] = {900 NS}, // DOUT
		DREL1[] = {-1 NS},
		DRET1[] = {-1 NS};

	for (ts = 1, i = 0; ts <= sizeof(RATE) / sizeof(double); ts++, i++)
	{
		UTL_AddTgRate(h, ts, RATE[i]);
		if (BCLK1[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 1, BCLK1[i]);
		}
		if (BCLK2[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 2, BCLK2[i]);
		}
		if (CCLK2[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 2, CCLK2[i]);
		}
		if (BCLK3[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 3, BCLK3[i]);
		}
		if (CCLK3[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 3, CCLK3[i]);
		}
		if (BCLK4[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 4, BCLK4[i]);
		}
		if (CCLK4[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 4, CCLK4[i]);
		}
		if (STRB1[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 1, STRB1[i]);
		}
		if (DREL1[i] < 0)
		{
			UTL_AddTgDreLOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreL(h, ts, 1, DREL1[i]);
		}
		if (DRET1[i] < 0)
		{
			UTL_AddTgDreTOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreT(h, ts, 1, DRET1[i]);
		}
	}
	UTL_SendTg(h);
	UTL_DeleteHandle(h);
}
void setTiming10MHz()
{
	//setBaseRate(8 NS);

	TgHandle h = UTL_GetTgHandle();

	int ts, i;
	double
		RATE[] = {100 NS},
		BCLK1[] = {10 NS}, // DIN
		BCLK2[] = {10 NS}, // ADDRESS WT
		CCLK2[] = {0 NS},  // ADDRESS RT
		BCLK3[] = {0 NS},  // CLK

		CCLK3[] = {50 NS}, // CLK
		BCLK4[] = {-1 NS}, // SAET
		CCLK4[] = {-1 NS}, // SAET
		STRB1[] = {90 NS}, // DOUT
		STRB2[] = {90 NS}, // DOUT
		DREL1[] = {-1 NS},
		DRET1[] = {-1 NS};

	for (ts = 1, i = 0; ts <= sizeof(RATE) / sizeof(double); ts++, i++)
	{
		UTL_AddTgRate(h, ts, RATE[i]);
		if (BCLK1[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 1, BCLK1[i]);
		}
		if (BCLK2[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 2, BCLK2[i]);
		}
		if (CCLK2[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 2, CCLK2[i]);
		}
		if (BCLK3[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 3, BCLK3[i]);
		}
		if (CCLK3[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 3, CCLK3[i]);
		}
		if (BCLK4[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 4, BCLK4[i]);
		}
		if (CCLK4[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 4, CCLK4[i]);
		}
		if (STRB1[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 1, STRB1[i]);
		}
		if (DREL1[i] < 0)
		{
			UTL_AddTgDreLOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreL(h, ts, 1, DREL1[i]);
		}
		if (DRET1[i] < 0)
		{
			UTL_AddTgDreTOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreT(h, ts, 1, DRET1[i]);
		}
	}
	UTL_SendTg(h);
	UTL_DeleteHandle(h);
}
void setTiming5MHz()
{
	//setBaseRate(8 NS);

	TgHandle h = UTL_GetTgHandle();

	int ts, i;
	double
		RATE[] = {200 NS},
		BCLK1[] = {20 NS}, // DIN
		BCLK2[] = {20 NS},  // ADDRESS WT
		CCLK2[] = {0 NS}, // ADDRESS RT
		BCLK3[] = {0 NS},  // CLK

		CCLK3[] = {100 NS}, // CLK
		BCLK4[] = {-1 NS},	// SAET
		CCLK4[] = {-1 NS},	// SAET
		STRB1[] = {180 NS},	// DOUT
		STRB2[] = {180 NS}, // DOUT
		DREL1[] = {-1 NS},
		DRET1[] = {-1 NS};

	for (ts = 1, i = 0; ts <= sizeof(RATE) / sizeof(double); ts++, i++)
	{
		UTL_AddTgRate(h, ts, RATE[i]);
		if (BCLK1[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 1, BCLK1[i]);
		}
		if (BCLK2[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 2, BCLK2[i]);
		}
		if (CCLK2[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 2);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 2, CCLK2[i]);
		}
		if (BCLK3[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 3, BCLK3[i]);
		}
		if (CCLK3[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 3);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 3, CCLK3[i]);
		}
		if (BCLK4[i] < 0)
		{
			UTL_AddTgBclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgBclk(h, ts, 4, BCLK4[i]);
		}
		if (CCLK4[i] < 0)
		{
			UTL_AddTgCclkOff(h, ts, 4);
		}
		else
		{
			UTL_AddTgCclk(h, ts, 4, CCLK4[i]);
		}
		if (STRB1[i] < 0)
		{
			UTL_AddTgStrbOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgStrb(h, ts, 1, STRB1[i]);
		}
		if (DREL1[i] < 0)
		{
			UTL_AddTgDreLOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreL(h, ts, 1, DREL1[i]);
		}
		if (DRET1[i] < 0)
		{
			UTL_AddTgDreTOff(h, ts, 1);
		}
		else
		{
			UTL_AddTgDreT(h, ts, 1, DRET1[i]);
		}
	}
	UTL_SendTg(h);
	UTL_DeleteHandle(h);
}

void setBaseRate(double val)
{
	TgBaseRateHandle hBr = UTL_GetTgBaseRateHandle();
	UTL_SetTgBaseRate(hBr, val);
	UTL_SendTgBaseRate(hBr);
	UTL_DeleteHandle(hBr);
}
