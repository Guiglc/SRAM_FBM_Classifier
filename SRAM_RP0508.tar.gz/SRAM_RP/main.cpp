#include "main.h"
#include <string.h>
static void TestStartLog();
static void TestEndLog();
static void SetGlobalData();

int main(int argc, char **argv)
{
	UTL_InitTest(argc, argv);

	if (UTL_GetDutCount(UT_SDUT) == 0)
		return 0;

	UTL_StartTimer(UT_TIMER_R10MS);
	char *exe =strrchr(argv[0],'/')?strrchr(argv[0],'/')+1:argv[0];
	printf("Current_Program: %s \n\n",argv[0]);
	
	SetGlobalData();
	TestStartLog();
	
	PinList();
	setPowerSeq();
	UTL_SetWet();


	TestFlow();
//     	testflow2;
	TestEndLog();

	return 0;
}

static void TestStartLog()
{
	setlinebuf(stdout);
//	unsigned int x_loc[1]={0};
//	unsigned int y_loc[1]={0};
	MAC_LOOPDUT_START(UT_SDUT)
//	x_loc[dut-1]=UTL_ReadDutXLocation(dut);
//	y_loc[dut-1]=UTL_ReadDutYLocation(dut);
//	printf("LOCATION X %d Y %d",x_loc[dut-1],y_loc[dut-1]);
//	Print((char *)"[D%02d] (%d,%d)\n", dut, x_loc[dut - 1], y_loc[dut - 1]);
//	Print((char *)"[D%02d] (%+3d,%+3d)\n", dut, g_die_X[dut - 1], g_die_Y[dut - 1]);
	MAC_LOOPDUT_STOP
	int dut =1;
 	Print((char*)"[RAW] X=%d y=%d\n",g_die_X[dut - 1],g_die_Y[dut - 1]);
	Print((char *)"TOUCHDOWN_NUM %d\n", g_shotcounter);
	Print("DeviceName = %s\n", g_DeviceName);
	Print("LotNumber = %s\n", g_LotNumber);
	Print("WaferSlotNumber = %s\n", g_WaferSlotNumber);
	Print("ProberID = %s\n", g_ProberID);
//	Print((char *)"TOUCHDOWN_NUM %d\n", g_shotcounter);
//	Print("DeviceName = %s\n", g_DeviceName);
//	Print("LotNumber = %s\n", g_LotNumber);
//	Print("WaferId = %s\n", g_WaferId);
//	Print("WaferSlotNumber = %s\n", g_WaferSlotNumber);
//	Print("ProberID = %s\n", g_ProberID);


	char date[256];
	time_t timep;
	timep = time(0);
	strftime(date, 128, (char *)"%Y/%m/%d_%H:%M:%S", localtime(&timep));
	Print((char *)"\nTEST_START_TIME:\t%s\n", date);
	Print("Test Program Compile Time: %s %s\n", __DATE__, __TIME__);
}

static void TestEndLog()
{
	CheckButton of;
	double dbTotal_Time;
	char szResult[32];
	UT_DUT sysdut;

	MAC_LOOPDUT_START(UT_SDUT)
	UTL_ConvertDutNumber(UT_SITEDUT, dut, UT_SYSDUT, NULL, &sysdut);
	if (g_Rejected[dut - 1])
	{
		sprintf(szResult, "FAIL");
		dbTotal_Time = g_tRjectTitemTime[dut - 1];
	}
	else
	{
		sprintf(szResult, "PASS");
		dbTotal_Time = UTL_ReadTimer(&of);
		UTL_SetCategory(dut, g_BinNo[dut - 1]);
	}
	Print((char *)"\n\n\n$RESULT_DUT_INFO X:%2d Y:%2d BIN:%2d SITE:%2d DUT:%2d SYSTEM_DUT:%2d, TT = %.0f MS, BIN NAME = %s\n",
		  g_die_X[dut - 1], g_die_Y[dut - 1], g_BinNo[dut - 1], UTL_ReadSiteNumber(), dut, sysdut, dbTotal_Time * 1000.0, g_BinName[dut - 1]);
	MAC_LOOPDUT_STOP
	char date[256];
	time_t timep;
	timep = time(0);
	strftime(date, 128, (char *)"%Y/%m/%d %H:%M:%S", localtime(&timep));
	Print((char *)"\n");
	Print((char *)"TEST_END_TIME:\t%s\n\n", date);
}

void SetGlobalData()
{
	// FK16 is print pattern lable
	// FK15 is display debug print
	// FK14  NOT USE
	// FK13  NOT USE
	// FK12  NOT USE
	// FK11 is only display testitem name
	// FK10  NOT USE
	// FK9   NOT USE
	// FK8   NOT USE
	// FK7   NOT USE
	// FK8 is force all testitem PASS
	// FK7   NOT USE
	// FK6   NOT USE
	// FK5   NOT USE
	// FK4   NOT USE
	// FK3  is print PowerOn/Off when use PowerOn/Off func
	// FK2  is FCM Fail Address Output
	// FK1  is only execute OpenShort Testitem
	int i = 0;
	for (i = 1; i < 17; i++)
	{
		if (ReadFk(i))
		{
			FK[i] = 1;
		}
	}
	if (UTL_ReadFirstFlag())
	{
		g_FirstRun = 1;
	}
	else
	{
		g_FirstRun = 0;
	}

	g_DeviceName = UTL_ReadHeaderDeviceName();
	g_LotNumber = UTL_ReadHeaderLotNumber();
	g_WaferId = UTL_ReadHeaderWaferId();
	g_WaferSlotNumber = UTL_ReadWaferSlotNumber();
	g_ProberID = UTL_ReadProberID();
	g_shotcounter = UTL_ReadShotCounter();
	MAC_LOOPDUT_START(UT_SDUT)
	g_die_X[dut - 1] = UTL_ReadDutXLocation(dut);
	g_die_Y[dut - 1] = UTL_ReadDutYLocation(dut);
// 	Print((char*)"[RAW] X=%d y=%d",g_die_X[dut - 1],g_die_Y[dut - 1]);
	g_BinNo[dut - 1] = 1;
	g_BinName[dut - 1] = "PASS";
	g_FlowDutActive[dut - 1] = true;
	MAC_LOOPDUT_STOP
	MAC_LOOPDUT_START(UT_DDUT)
	g_NextSeq[dut - 1] = NEXT;
	MAC_LOOPDUT_STOP
}
