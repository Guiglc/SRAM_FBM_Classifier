#ifndef __PINFMT_H
#define __PINFMT_H

void setPinFmt_vmin();
void setPinFmt();
void setPinFmt_Logic();
void setPinFmt_Logic2();
void setDpinFixL( char* pinName, int viNo , double vih, double vil );
void setDpinFixH( char* pinName, int viNo , double vih, double vil );
void setDpinOpen( char* pinName );
void setDpinClose( char* pinName );

extern PinHandle PIN_;
#define P(pin,...)                                              \
( {                                                             \
  PIN_ = UTL_GetPinHandle();                                    \
  UTL_InitializePinHandle( PIN_);                               \
  __VA_ARGS__;                                                  \
  UTL_SendPin( PIN_, pin);                                      \
  UTL_DeleteHandle( PIN_);                    \
} )
#define P_PART			        		UTL_SetPinSendMode	        ( PIN_, UT_PIN_PART   )
#define P_PPAT                          UTL_SetPinDbmPinPattern     ( PIN_, UT_ON         )
#define P_PDRE		                	UTL_SetPinDbmPinDrePattern  ( PIN_, UT_ON         )
#define P_PCPE(s)						UTL_AddPinStrbCpeMode	    ( PIN_, s, UT_PIN_PCPE)
#define P_CPE(s)						UTL_AddPinStrbCpeMode	    ( PIN_, s, UT_PIN_CPE )
#define P_FIXL                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_FIXL   )
#define P_FIXH                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_FIXH	  )
#define P_NRZB                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_NRZB	  )
#define P_INRZB                         UTL_SetPinDrWaveform        ( PIN_, UT_WAV_INRZB  )
#define P_NRZC                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_NRZC	  )
#define P_INRZC                         UTL_SetPinDrWaveform        ( PIN_, UT_WAV_INRZC  )
#define P_NRZBC                         UTL_SetPinDrWaveform        ( PIN_, UT_WAV_NRZBC  )
#define P_INRZBC                        UTL_SetPinDrWaveform        ( PIN_, UT_WAV_INRZBC )
#define P_NRZCB                         UTL_SetPinDrWaveform        ( PIN_, UT_WAV_NRZCB  )
#define P_INRZCB                        UTL_SetPinDrWaveform        ( PIN_, UT_WAV_INRZCB )
#define P_RZO                           UTL_SetPinDrWaveform        ( PIN_, UT_WAV_RZO	  )
#define P_IRZO                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_IRZO	  )
#define P_RZZ                           UTL_SetPinDrWaveform        ( PIN_, UT_WAV_RZZ	  )
#define P_IRZZ                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_IRZZ	  )
#define P_RZX                           UTL_SetPinDrWaveform        ( PIN_, UT_WAV_RZX	  )
#define P_IRZX                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_IRZX	  )
#define P_DNRZ                          UTL_SetPinDrWaveform        ( PIN_, UT_WAV_DNRZ	  )
#define P_IDNRZ                         UTL_SetPinDrWaveform        ( PIN_, UT_WAV_IDNRZ  )
#define P_OPEN                          UTL_SetPinOpen              ( PIN_, UT_ON         )
#define P_VSOPEN                        UTL_SetPinVsDisconnect      ( PIN_, UT_ON         )
#define P_HINIT                         UTL_SetPinInit              ( PIN_, UT_PIN_HINIT  )
#define P_LINIT                         UTL_SetPinInit              ( PIN_, UT_PIN_HINIT  )
#define P_BCLK(n)                       UTL_SetPinDrClock           ( PIN_, UT_PIN_BCLK, n)
#define P_CCLK(n)                       UTL_SetPinDrClock           ( PIN_, UT_PIN_CCLK, n)
#define P_PSM                           UTL_SetPinPsm               ( PIN_, UT_ON)
#define P_RDSM                          UTL_SetPinRdsm              ( PIN_, UT_ON)
#define P_EINVSTRB(n)			        UTL_AddPinEinvStrbNumber	( PIN_, n)
#define P_MATCH                         UTL_SetPinMatchMode         ( PIN_, UT_SIG_MATCH)
#define P_MATCHGROUP                    UTL_SetPinMatchMode         ( PIN_, UT_SIG_MATCHGROUP)
#define P_MPG_SEL1 			            UTL_SetPinMatchGroup	    ( PIN_, UT_MPG_SEL1, UT_ON)
#define P_MPG_SEL2			            UTL_SetPinMatchGroup	    ( PIN_, UT_MPG_SEL2, UT_ON)
#define P_INH(n)                        UTL_SetPinViNumber          ( PIN_, n), UTL_SetPinHvDr              ( PIN_, UT_ON)
#define P_IOC                           UTL_SetPinIoCtrl            ( PIN_, UT_ON)
#define P_IN(n)                         UTL_SetPinViNumber          ( PIN_, n)
#define P_OUT(n)                        UTL_SetPinVoNumber          ( PIN_, n), UTL_SetPinTerm( PIN_, UT_OFF)
#define P_OUTL(n)                       UTL_SetPinVoNumber          ( PIN_, n), UTL_SetPinTerm( PIN_, UT_ON)
#define P_VT(n)                         UTL_SetPinVtNumber          ( PIN_, n)
#define P_VL(n,r)                       UTL_SetPinVloadNumber       ( PIN_, n), UTL_SetPinVloadResistor( PIN_,r)
#define P_STRB(s,c)                     UTL_AddPinStrbCpeNumber     ( PIN_, s, c)

#define P_EXPA(s)                       UTL_AddPinExpStrbNumber       ( PIN_, s, UT_PIN_EXP_A)
#define P_EXPB(s)                       UTL_AddPinExpStrbNumber       ( PIN_, s, UT_PIN_EXP_B)
#define P_EXP_CH1_FL(s)                 UTL_AddPinStrbChannel       ( PIN_, s, 1)
#define P_EXP_CH1_FH(s)                 UTL_AddPinStrbChannel       ( PIN_, s, 1)
#define P_EXP_CH2_FL(s)                 UTL_AddPinStrbChannel       ( PIN_, s, 2)
#define P_EXP_CH2_FH(s)                 UTL_AddPinStrbChannel       ( PIN_, s, 2)
#define P_DRDLY(n)                      UTL_SetPinDrDelay           ( PIN_, n)
#define P_DREDLY(n)                     UTL_SetPinDreDelay          ( PIN_, n)
#define P_CPEDLY(n)                     UTL_SetPinCpeDelay          ( PIN_, n)
#define P_EXPDLY(n)                     UTL_SetPinExpDelay          ( PIN_, n)
#define P_DRECLK(n)                     UTL_SetPinDreClock          ( PIN_, n)
#define P_DRE(n)                        UTL_SetPinDreNumber         ( PIN_, n)
#define P_DRENRZ                        UTL_SetPinDreWaveform       ( PIN_, UT_DREWAV_NRZ)
#define PDSA(cyp,...)                                           \
( {                                                             \
  void (*PDS)(PinHandle,RadioButton,RadioButton)                \
    = UTL_AddPinPdsA;                                           \
  int    CYP = cyp;                                             \
  __VA_ARGS__;                                                  \
} )
#define PDSB(cyp,...)                                           \
( {                                                             \
  void (*PDS)(PinHandle,RadioButton,RadioButton)                \
    = UTL_AddPinPdsB;                                           \
  int    CYP = cyp;                                             \
  __VA_ARGS__;                                                  \
} )
#define PDSD(cyp,...)                                           \
( {                                                             \
  void (*PDS)(PinHandle,RadioButton,RadioButton)                \
    = UTL_AddPinPdsD;                                           \
  int    CYP = cyp;                                             \
  __VA_ARGS__;                                                  \
} )
#define P_C(n)                          PDS( PIN_, UT_SIG_C   (n), CYP)
#define P_I_C(n)                        PDS( PIN_, UT_SIG_I_C (n), CYP)
#define P_D(n)                          PDS( PIN_, UT_SIG_D   (n), CYP)
#define P_SD(n)                         PDS( PIN_, UT_SIG_SD  (n), CYP)
#define P_I_D(n)                        PDS( PIN_, UT_SIG_I_D (n), CYP)
#define P_I_SD(n)                       PDS( PIN_, UT_SIG_I_SD(n), CYP)
#define P_X(n)                          PDS( PIN_, UT_SIG_X   (n), CYP)
#define P_Y(n)                          PDS( PIN_, UT_SIG_Y   (n), CYP)
#define P_FH                            PDS( PIN_, UT_SIG_FH, CYP)
#define P_FL                            PDS( PIN_, UT_SIG_FL, CYP)
#define P_WT                            PDS( PIN_, UT_SIG_WT, CYP)
#define P_RD                            PDS( PIN_, UT_SIG_RD, CYP)

#endif
