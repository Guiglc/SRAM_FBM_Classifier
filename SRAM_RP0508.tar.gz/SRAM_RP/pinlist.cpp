#include "main.h"

PIN_STRUCT g_pinlist[300];
static void ulCreatePinListWithNumber(char *plst, int type, int num);
static void ulCreatePinListWithList(char *plst, int type, ...);
static void ulCreatePinListWithListArray(char *plst, int type, char *pinlist[], int number);

#define POWERPIN_NUMBER 5
#define ALLPIN_NUMBER 104
#define OSPIN_NUMBER 104
#define OUTPIN_NUMBER 32
#define INPUTPIN_NUMBER 70
#define INPUT_LEAKAGEPIN_NUMBER 70
#define OUTPUT_LEAKAGEPIN_NUMBER 32

char *powerpin_list[POWERPIN_NUMBER] ={"VDDM","VDDM1","VDDM2","VDD","DVDD"};

char *allpin_list[ALLPIN_NUMBER] ={"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
	"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",
	"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
	"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
	"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
	"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
	"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT",};

char *ospin_list[OSPIN_NUMBER] ={"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
	"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",
	"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
	"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
	"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
	"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
	"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT"};


char *outpin_list[OUTPIN_NUMBER] ={"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
	"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31"};

char *inputpin_list[INPUTPIN_NUMBER] ={"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
	"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
	"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
	"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
	"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT"};
char *input_leakagepin_list[INPUT_LEAKAGEPIN_NUMBER]  ={"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
	"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
	"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
	"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
	"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT"};
char *output_leakagepin_list[OUTPUT_LEAKAGEPIN_NUMBER] ={"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",          
	"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31"};
void PinList()                  
{
	/* VDD PIN */
	ulCreatePinListWithNumber("VDDM",		UT_PINTYPE_VS,		1);//PPS1A
	ulCreatePinListWithNumber("VDDM1",		UT_PINTYPE_VS,		2);//PPS5A
	ulCreatePinListWithNumber("VDDM2",		UT_PINTYPE_VS,		3);//PPS6A
	ulCreatePinListWithNumber("VDD",		UT_PINTYPE_VS,		4);//PPS9A
	ulCreatePinListWithNumber("DVDD",		UT_PINTYPE_VS,		5);//PPS9A

	/* DOUT PINS */
	ulCreatePinListWithNumber( "DOUT0",			UT_PINTYPE_PIN,		33);
	ulCreatePinListWithNumber( "DOUT1",			UT_PINTYPE_PIN,		34);
	ulCreatePinListWithNumber( "DOUT2",			UT_PINTYPE_PIN,		35);
	ulCreatePinListWithNumber( "DOUT3",			UT_PINTYPE_PIN,		36);
	ulCreatePinListWithNumber( "DOUT4",			UT_PINTYPE_PIN,		37);
	ulCreatePinListWithNumber( "DOUT5",			UT_PINTYPE_PIN,		38);
	ulCreatePinListWithNumber( "DOUT6",			UT_PINTYPE_PIN,		39);
	ulCreatePinListWithNumber( "DOUT7",			UT_PINTYPE_PIN,		40);
	ulCreatePinListWithNumber( "DOUT8",			UT_PINTYPE_PIN,		41);
	ulCreatePinListWithNumber( "DOUT9",			UT_PINTYPE_PIN,		42);
	ulCreatePinListWithNumber( "DOUT10",		UT_PINTYPE_PIN,		43);
	ulCreatePinListWithNumber( "DOUT11",		UT_PINTYPE_PIN,		44);
	ulCreatePinListWithNumber( "DOUT12",		UT_PINTYPE_PIN,		45);
	ulCreatePinListWithNumber( "DOUT13",		UT_PINTYPE_PIN,		46);
	ulCreatePinListWithNumber( "DOUT14",		UT_PINTYPE_PIN,		47);
	ulCreatePinListWithNumber( "DOUT15",		UT_PINTYPE_PIN,		48);
	ulCreatePinListWithNumber( "DOUT16",		UT_PINTYPE_PIN,		97);
	ulCreatePinListWithNumber( "DOUT17",		UT_PINTYPE_PIN,		98);
	ulCreatePinListWithNumber( "DOUT18",		UT_PINTYPE_PIN,		99);
	ulCreatePinListWithNumber( "DOUT19",		UT_PINTYPE_PIN,		100);
	ulCreatePinListWithNumber( "DOUT20",		UT_PINTYPE_PIN,		101);
	ulCreatePinListWithNumber( "DOUT21",		UT_PINTYPE_PIN,		102);
	ulCreatePinListWithNumber( "DOUT22",		UT_PINTYPE_PIN,		103);
	ulCreatePinListWithNumber( "DOUT23",		UT_PINTYPE_PIN,	 	104);
	ulCreatePinListWithNumber( "DOUT24",		UT_PINTYPE_PIN,		105);
	ulCreatePinListWithNumber( "DOUT25",		UT_PINTYPE_PIN,		106);
	ulCreatePinListWithNumber( "DOUT26",		UT_PINTYPE_PIN,		107);
	ulCreatePinListWithNumber( "DOUT27",		UT_PINTYPE_PIN,		108);
	ulCreatePinListWithNumber( "DOUT28",		UT_PINTYPE_PIN,		109);
	ulCreatePinListWithNumber( "DOUT29",		UT_PINTYPE_PIN,		110);
	ulCreatePinListWithNumber( "DOUT30",		UT_PINTYPE_PIN,		111);
	ulCreatePinListWithNumber( "DOUT31",		UT_PINTYPE_PIN,		112);

	/* DIN PINS */
	ulCreatePinListWithNumber( "DIN0",			UT_PINTYPE_PIN,		1);
	ulCreatePinListWithNumber( "DIN1",			UT_PINTYPE_PIN,		2);
	ulCreatePinListWithNumber( "DIN2",			UT_PINTYPE_PIN,		3);
	ulCreatePinListWithNumber( "DIN3",			UT_PINTYPE_PIN,		4);
	ulCreatePinListWithNumber( "DIN4",			UT_PINTYPE_PIN,		5);
	ulCreatePinListWithNumber( "DIN5",			UT_PINTYPE_PIN,		6);
	ulCreatePinListWithNumber( "DIN6",			UT_PINTYPE_PIN,		7);
	ulCreatePinListWithNumber( "DIN7",			UT_PINTYPE_PIN,		8);
	ulCreatePinListWithNumber( "DIN8",			UT_PINTYPE_PIN,		9);
	ulCreatePinListWithNumber( "DIN9",			UT_PINTYPE_PIN,		10);
	ulCreatePinListWithNumber( "DIN10",			UT_PINTYPE_PIN,		11);
	ulCreatePinListWithNumber( "DIN11",			UT_PINTYPE_PIN,		12);
	ulCreatePinListWithNumber( "DIN12",			UT_PINTYPE_PIN,		13);
	ulCreatePinListWithNumber( "DIN13",			UT_PINTYPE_PIN,		14);
	ulCreatePinListWithNumber( "DIN14",			UT_PINTYPE_PIN,		15);
	ulCreatePinListWithNumber( "DIN15",			UT_PINTYPE_PIN,		16);
	ulCreatePinListWithNumber( "DIN16",			UT_PINTYPE_PIN,		65);
	ulCreatePinListWithNumber( "DIN17",			UT_PINTYPE_PIN,		66);
	ulCreatePinListWithNumber( "DIN18",			UT_PINTYPE_PIN,		67);
	ulCreatePinListWithNumber( "DIN19",			UT_PINTYPE_PIN,		68);
	ulCreatePinListWithNumber( "DIN20",			UT_PINTYPE_PIN,		69);
	ulCreatePinListWithNumber( "DIN21",			UT_PINTYPE_PIN,		70);
	ulCreatePinListWithNumber( "DIN22",			UT_PINTYPE_PIN,		71);
	ulCreatePinListWithNumber( "DIN23",			UT_PINTYPE_PIN,		72);
	ulCreatePinListWithNumber( "DIN24",			UT_PINTYPE_PIN,		73);
	ulCreatePinListWithNumber( "DIN25",			UT_PINTYPE_PIN,		74);
	ulCreatePinListWithNumber( "DIN26",			UT_PINTYPE_PIN,		75);
	ulCreatePinListWithNumber( "DIN27",			UT_PINTYPE_PIN,		76);
	ulCreatePinListWithNumber( "DIN28",			UT_PINTYPE_PIN,		77);
	ulCreatePinListWithNumber( "DIN29",			UT_PINTYPE_PIN,		78);
	ulCreatePinListWithNumber( "DIN30",			UT_PINTYPE_PIN,		79);
	ulCreatePinListWithNumber( "DIN31",			UT_PINTYPE_PIN,		80);

	/* ADDRESS PINS */
	ulCreatePinListWithNumber( "AD0",			UT_PINTYPE_PIN,		129);
	ulCreatePinListWithNumber( "AD1",			UT_PINTYPE_PIN,		130);
	ulCreatePinListWithNumber( "AD2",			UT_PINTYPE_PIN,		131);
	ulCreatePinListWithNumber( "AD3",			UT_PINTYPE_PIN,		132);
	ulCreatePinListWithNumber( "AD4",			UT_PINTYPE_PIN,		133);
	ulCreatePinListWithNumber( "AD5",			UT_PINTYPE_PIN,		134);
	ulCreatePinListWithNumber( "AD6",			UT_PINTYPE_PIN,		135);
	ulCreatePinListWithNumber( "AD7",			UT_PINTYPE_PIN,		136);
	ulCreatePinListWithNumber( "AD8",			UT_PINTYPE_PIN,		137);
	ulCreatePinListWithNumber( "AD9",			UT_PINTYPE_PIN,		138);
	ulCreatePinListWithNumber( "AD10",		UT_PINTYPE_PIN,		139);
	ulCreatePinListWithNumber( "AD11",		UT_PINTYPE_PIN,		140);
	ulCreatePinListWithNumber( "AD12",		UT_PINTYPE_PIN,		141);
	ulCreatePinListWithNumber( "MACRO_SEL0",		UT_PINTYPE_PIN,		198);
	ulCreatePinListWithNumber( "MACRO_SEL1",		UT_PINTYPE_PIN,		199);
	ulCreatePinListWithNumber( "MACRO_SEL2",		UT_PINTYPE_PIN,		200);
	ulCreatePinListWithNumber( "MACRO_SEL3",		UT_PINTYPE_PIN,		201);
	ulCreatePinListWithNumber( "MACRO_SEL4",		UT_PINTYPE_PIN,		202);
	ulCreatePinListWithNumber( "MACRO_SEL5",		UT_PINTYPE_PIN,		203);
	ulCreatePinListWithNumber( "MACRO_ALL",		UT_PINTYPE_PIN,		194);

	/* CONTROL PINS */
	ulCreatePinListWithNumber( "CLK",			UT_PINTYPE_PIN,		142);
	ulCreatePinListWithNumber( "CEN",			UT_PINTYPE_PIN,		143);//Chip Enable, Low Active
	ulCreatePinListWithNumber( "WE",			UT_PINTYPE_PIN,		144);//Write Enabke, High Write, Low Read
	ulCreatePinListWithNumber( "RN",			UT_PINTYPE_PIN,		193);//Retension Mode, Low Active
	ulCreatePinListWithNumber( "MODE_SEL0",			UT_PINTYPE_PIN,		195);//Test mode enable, High Active
	ulCreatePinListWithNumber( "MODE_SEL1",			UT_PINTYPE_PIN,		196);
	ulCreatePinListWithNumber( "FSEL0",			UT_PINTYPE_PIN,		206);//Test Mode Select: 00 R/W mode; 01 Write Thru mode; 10 FA mode
	ulCreatePinListWithNumber( "FSEL1",			UT_PINTYPE_PIN,		207);//SA enable for TST 00 & 01
	ulCreatePinListWithNumber( "FTYPE0",			UT_PINTYPE_PIN,		257);
	ulCreatePinListWithNumber( "FTYPE1",			UT_PINTYPE_PIN,		258);
	ulCreatePinListWithNumber( "BIST_EN",			UT_PINTYPE_PIN,	    259);

	/* DEBUG & MONITOR PINS */
	ulCreatePinListWithNumber( "SAE_SEL",			UT_PINTYPE_PIN,		260);
	ulCreatePinListWithNumber( "SAE",			UT_PINTYPE_PIN,		197);
	ulCreatePinListWithNumber( "WL_CPW_CTRL0",			UT_PINTYPE_PIN,		261);
	ulCreatePinListWithNumber( "WL_CPW_CTRL1",			UT_PINTYPE_PIN,		262);
	ulCreatePinListWithNumber( "PAD_OE",			UT_PINTYPE_PIN,		263);
	ulCreatePinListWithNumber( "DIRIN",			UT_PINTYPE_PIN,		264);
	ulCreatePinListWithNumber( "DIROUT",			UT_PINTYPE_PIN,		297);
	//	ulCreatePinListWithNumber( "AIN",			UT_PINTYPE_PIN,		);
	//	ulCreatePinListWithNumber( "AOUTN",			UT_PINTYPE_PIN,		144);


	/* PINS GROUP */

	//
	ulCreatePinListWithList("POWERPINS",		UT_PINTYPE_VS, 	"VDDM","VDDM1","VDDM2","VDD","DVDD",NULL);
	ulCreatePinListWithList("ALLPINS",		UT_PINTYPE_PIN, 	"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
			"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",
			"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
			"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
			"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
			"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
			"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT",NULL);
	ulCreatePinListWithList("OSPINS",		UT_PINTYPE_PIN, 	"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
			"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",
			"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
			"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
			"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
			"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
			"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT",NULL);
	ulCreatePinListWithList("OUTPINS",		UT_PINTYPE_PIN, 	"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",
			"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",NULL);
	ulCreatePinListWithList("INPUTPINS",		UT_PINTYPE_PIN, 	"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
			"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
			"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
			"CLK","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","WE",
			"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN","DIROUT",NULL);
	ulCreatePinListWithList("INPUT_LEAKAGEPINS",		UT_PINTYPE_PIN, 	"DIN0","DIN1","DIN2","DIN3","DIN4","DIN5","DIN6","DIN7","DIN8","DIN9","DIN10","DIN11","DIN12","DIN13","DIN14","DIN15",
			"DIN16","DIN17","DIN18","DIN19","DIN20","DIN21","DIN22","DIN23","DIN24","DIN25","DIN26","DIN27","DIN28","DIN29","DIN30","DIN31",
			"AD0","AD1","AD2","AD3","AD4","AD5","AD6","AD7","AD8","AD9","AD10","AD11","AD12","MACRO_SEL0","MACRO_SEL1","MACRO_SEL2","MACRO_SEL3","MACRO_SEL4","MACRO_SEL5","MACRO_ALL",
			"CLK","RN","MODE_SEL0","MODE_SEL1","FSEL0","FSEL1","FTYPE0","FTYPE1","BIST_EN","CEN","WE",
			"SAE_SEL","SAE","WL_CPW_CTRL0","WL_CPW_CTRL1","PAD_OE","DIRIN",NULL);
	ulCreatePinListWithList("OUTPUT_LEAKAGEPINS",		UT_PINTYPE_PIN, 	"DOUT0","DOUT1","DOUT2","DOUT3","DOUT4","DOUT5","DOUT6","DOUT7","DOUT8","DOUT9","DOUT10","DOUT11","DOUT12","DOUT13","DOUT14","DOUT15",          
			"DOUT16","DOUT17","DOUT18","DOUT19","DOUT20","DOUT21","DOUT22","DOUT23","DOUT24","DOUT25","DOUT26","DOUT27","DOUT28","DOUT29","DOUT30","DOUT31",NULL);
	ulCreatePinListWithList("MODE_CONTROL_PINS",		UT_PINTYPE_PIN, 	"CEN","RN",NULL);

}

static void ulCreatePinListWithNumber(char *plst, int type, int num)
{
	UTL_CreatePinList(plst);
	UTL_SetPinType   (plst, type);
	UTL_AddPinNumber (plst, num);
	if(type==UT_PINTYPE_VS){
		g_pinlist[num].vsno=num ;		strcpy(g_pinlist[num].vsname ,plst);
	}else{
		g_pinlist[num].pinno=num ;		strcpy(g_pinlist[num].pinname ,plst);
	}
}

static void ulCreatePinListWithListArray(char *plst, int type, char *pinlist[], int number)
{
	UTL_CreatePinList(plst); 
	UTL_SetPinType   (plst, type);
	for(int i=0; i<number;i++){
		UTL_AppendPinList(plst, pinlist[i]);
	}
}

static void ulCreatePinListWithList(char *plst, int type, ...)
{
	va_list va;
	char   *ap;

	va_start(va, type);
	UTL_CreatePinList(plst);
	UTL_SetPinType   (plst, type);
	while((ap = va_arg(va, char *))!= NULL)
	{
		UTL_AppendPinList(plst, ap);
	}
	va_end(va);
}
