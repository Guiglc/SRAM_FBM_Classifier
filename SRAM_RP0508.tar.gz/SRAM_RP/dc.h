#ifndef __DC_H
#define __DC_H

enum ePPS_SRNG { R2V, R3V, R4V, R16V };
enum ePPS_MRNG { M40uA, M400uA, M4mA, M40mA, M400mA, M1200mA};
enum eDC_VRNG { R20V, Rm20V };
enum eDC_IRNG { R5uA, R20uA, R200uA, R2mA, R20mA, Rm20mA };
enum eVPP_SRNG { R8V, R32V };
enum eVPP_MRNG { M8uA, M80uA, M800uA, M8mA, M128mA,
                 M8V, Mm8V, M32V, Mm32V };

void setPowerSeq();
void setVs(int vsno, double val, enum ePPS_SRNG srng, enum ePPS_MRNG mrng, double pclamp, double mclamp);
void setVsMeas(int vsno, double val, enum ePPS_SRNG srng, enum ePPS_MRNG mrng, double pclamp, double mclamp, double upperLimit, double lowerLimit, int cnt);
void setHv(int vsno, double val, enum eVPP_SRNG srng, enum eVPP_MRNG mrng, double pclamp, double mclamp);
void setHvMeas(int vsno, double val, enum eVPP_SRNG srng, enum eVPP_MRNG mrng, double pclamp, double mclamp, double upperLimit, double lowerLimit, int cnt);
void setHvMVM(int vsno, enum eVPP_MRNG mrng, double upperLimit, double lowerLimit , int cnt);
void addVsLimit(int vsno, double upperLimit, double lowerLimit);
void setDcVS( double sval, enum eDC_VRNG srng, enum eDC_IRNG mrng, double pclamp, double mclamp);
void setDcIS( double sval, enum eDC_IRNG srng, enum eDC_VRNG mrng, double pclamp, double mclamp);
void setDcVSIM( double sval, enum eDC_VRNG srng, enum eDC_IRNG mrng, double pclamp, double mclamp, double hlimit, double llimit, int cnt);
void setDcISVM( double sval, enum eDC_IRNG srng, enum eDC_VRNG mrng, double pclamp, double mclamp, double hlimit, double llimit , int cnt);
void setVsOpen(int vsno);
void setVsDisconnect(char *vspins);
void setVsConnect(char *vspins);
void setHvUnMask(int vs_no);
void setHvMask(int vs_no);
void setDpinDcConnect( char* pinName);
void setDpinDcDisconnect( char* pinName);
void setSettlingTime(double t, double t1, double t2);
void setSamplingRate(double t);
void MeasPin(char *pinlist);
void PrintHistoryData(char *pinlist, double unit, int meas_cnt);
void ReadHistoryData(int dut, char *pinlist, int meas_cnt, double *data);
void PrintMeasData(char *pinlist, char *test_item, double unit, char* unitstr); 
void PrintMeasData_FAtest(char *pinlist, char *test_item, double unit, char* unitstr, USlider IOflag);
void ReadMeasData(char *pinlist, double unit,double *data);
void ReadMeasData2D(char *pinlist, double unit,double (*data)[DUT_NUM]);

#endif
