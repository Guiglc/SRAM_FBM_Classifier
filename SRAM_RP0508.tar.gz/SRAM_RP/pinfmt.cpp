#include "main.h"
PinHandle PIN_;

void setPinFmt_vmin()
{
	/*INPUT PINS*/
	P("DIN0",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(0)),PDSA(2, P_D(0)));
	P("DIN1",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(1)),PDSA(2, P_D(1)));
	P("DIN2",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(2)),PDSA(2, P_D(2)));
	P("DIN3",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(3)),PDSA(2, P_D(3)));
	P("DIN4",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(4)),PDSA(2, P_D(4)));
	P("DIN5",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(5)),PDSA(2, P_D(5)));
	P("DIN6",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(6)),PDSA(2, P_D(6)));
	P("DIN7",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(7)),PDSA(2, P_D(7)));
	P("DIN8",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(8)),PDSA(2, P_D(8)));
	P("DIN9",  P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(9)),PDSA(2, P_D(9)));
	P("DIN10", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(10)),PDSA(2, P_D(10)));
	P("DIN11", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(11)),PDSA(2, P_D(11)));
	P("DIN12", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(12)),PDSA(2, P_D(12)));
	P("DIN13", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(13)),PDSA(2, P_D(13)));
	P("DIN14", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(14)),PDSA(2, P_D(14)));
	P("DIN15", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(15)),PDSA(2, P_D(15)));
	P("DIN16", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(16)),PDSA(2, P_D(16)));
	P("DIN17", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(17)),PDSA(2, P_D(17)));
	P("DIN18", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(0)),PDSA(2, P_SD(0)));
	P("DIN19", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(1)),PDSA(2, P_SD(1)));
	P("DIN20", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(2)),PDSA(2, P_SD(2)));
	P("DIN21", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(3)),PDSA(2, P_SD(3)));
	P("DIN22", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(4)),PDSA(2, P_SD(4)));
	P("DIN23", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(5)),PDSA(2, P_SD(5)));
	P("DIN24", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(6)),PDSA(2, P_SD(6)));
	P("DIN25", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(7)),PDSA(2, P_SD(7)));
	P("DIN26", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(8)),PDSA(2, P_SD(8)));
	P("DIN27", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(9)),PDSA(2, P_SD(9)));
	P("DIN28", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(10)),PDSA(2, P_SD(10)));
	P("DIN29", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(11)),PDSA(2, P_SD(11)));
	P("DIN30", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(12)),PDSA(2, P_SD(12)));
	P("DIN31", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(13)),PDSA(2, P_SD(13)));

	/*OUTPUT PINS*/
	P("DOUT0",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(0)),PDSA(2, P_D(0)));
	P("DOUT1",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(1)),PDSA(2, P_D(1)));
	P("DOUT2",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(2)),PDSA(2, P_D(2)));
	P("DOUT3",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(3)),PDSA(2, P_D(3)));
	P("DOUT4",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(4)),PDSA(2, P_D(4)));
	P("DOUT5",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(5)),PDSA(2, P_D(5)));
	P("DOUT6",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(6)),PDSA(2, P_D(6)));
	P("DOUT7",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(7)),PDSA(2, P_D(7)));
	P("DOUT8",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(8)),PDSA(2, P_D(8)));
	P("DOUT9",  P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(9)),PDSA(2, P_D(9)));
	P("DOUT10", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(10)),PDSA(2, P_D(10)));
	P("DOUT11", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(11)),PDSA(2, P_D(11)));
	P("DOUT12", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(12)),PDSA(2, P_D(12)));
	P("DOUT13", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(13)),PDSA(2, P_D(13)));
	P("DOUT14", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(14)),PDSA(2, P_D(14)));
	P("DOUT15", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(15)),PDSA(2, P_D(15)));
	P("DOUT16", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(16)),PDSA(2, P_D(16)));
	P("DOUT17", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(17)),PDSA(2, P_D(17)));
	P("DOUT18", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(0)),PDSA(2, P_SD(0)));
	P("DOUT19", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(1)),PDSA(2, P_SD(1)));
	P("DOUT20", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(2)),PDSA(2, P_SD(2)));
	P("DOUT21", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(3)),PDSA(2, P_SD(3)));
	P("DOUT22", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(4)),PDSA(2, P_SD(4)));
	P("DOUT23", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(5)),PDSA(2, P_SD(5)));
	P("DOUT24", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(6)),PDSA(2, P_SD(6)));
	P("DOUT25", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(7)),PDSA(2, P_SD(7)));
	P("DOUT26", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(8)),PDSA(2, P_SD(8)));
	P("DOUT27", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(9)),PDSA(2, P_SD(9)));
	P("DOUT28", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(10)),PDSA(2, P_SD(10)));
	P("DOUT29", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(11)),PDSA(2, P_SD(11)));
	P("DOUT30", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(12)),PDSA(2, P_SD(12)));
	P("DOUT31", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(13)),PDSA(2, P_SD(13)));

	/*ADDRESS PINS*/
	P("AD0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(0)),PDSA(2, P_Y(0)));
	P("AD1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(1)),PDSA(2, P_Y(1)));
	P("AD2", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(2)),PDSA(2, P_Y(2)));
	P("AD3", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(3)),PDSA(2, P_Y(3)));
	P("AD4", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(0)),PDSA(2, P_X(0))); // Address[0:4] for column0~31
	P("AD5", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(1)),PDSA(2, P_X(1)));
	P("AD6", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(2)),PDSA(2, P_X(2)));
	P("AD7", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(3)),PDSA(2, P_X(3)));
	P("AD8", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(4)),PDSA(2, P_X(4)));
	P("AD9", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(5)),PDSA(2, P_X(5)));
	P("AD10", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(6)),PDSA(2, P_X(6)));
	P("AD11", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(7)),PDSA(2, P_X(7)));
	P("AD12", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(8)),PDSA(2, P_X(8))); // Address[5:12] for row0~255
	P("MACRO_SEL0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(9)),PDSA(2, P_X(9)));//X0
	P("MACRO_SEL1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(10)),PDSA(2, P_X(10)));//X1
	P("MACRO_SEL2", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(11)),PDSA(2, P_X(11)));//X2
	P("MACRO_SEL3", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(12)),PDSA(2, P_X(12)));//X3
	P("MACRO_SEL4", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(13)),PDSA(2, P_X(13)));//X4
	P("MACRO_SEL5", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(14)),PDSA(2, P_X(14)));//X5

	/*CONTROL PINS*/
	P("CLK"		, P_IN(1), P_IRZO, P_BCLK(3), P_CCLK(3), PDSA(1, P_C(1)),PDSA(2, P_C(1)));
	P("DIRIN"	, P_IN(1), P_IRZO, P_BCLK(3), P_CCLK(3), PDSA(1, P_C(2)),PDSA(2, P_C(2)));
	P("DIROUT"	, P_OUTL(1), P_DNRZ, P_EXPA(1),P_EXPB(2),P_STRB(1, 2), P_STRB(2, 2), PDSA(1, P_C(3)),PDSB(1,P_C(31)),PDSA(2, P_C(3)),PDSB(2,P_C(31))); // STRB with CPE2
	P("PAD_OE"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_FIXH), PDSA(2, P_FIXH));		// WE pin, High Write, Low Read
	P("MODE_SEL0"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(5)), PDSA(2, P_C(5)));		// WE pin, High Write, Low Read
	P("MODE_SEL1"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(6)),PDSA(2, P_C(6)));		// WE pin, High Write, Low Read
	P("RN"	, P_IN(1), P_INRZB, P_BCLK(2), PDSA(1, P_C(7)),PDSA(2, P_C(7)));		// WE pin, High Write, Low Read
	P("FSEL0"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(8)),PDSA(2, P_C(8)));		// WE pin, High Write, Low Read
	P("FSEL1"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(9)),PDSA(2, P_C(9)));		// WE pin, High Write, Low Read
	P("FTYPE0"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(10)),PDSA(2, P_C(10)));		// WE pin, High Write, Low Read
	P("FTYPE1"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(11)),PDSA(2, P_C(11)));		// WE pin, High Write, Low Read
	P("BIST_EN"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(12)),PDSA(2, P_C(12)));		// WE pin, High Write, Low Read
	P("CEN"		, P_IN(1), P_INRZB, P_BCLK(2), PDSA(1, P_C(13)),PDSA(2, P_C(13)));			// WE pin, High Write, Low Read
	P("SAE_SEL"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(14)),PDSA(2, P_C(14)));		// WE pin, High Write, Low Read
	P("SAE"		, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(15)),PDSA(2, P_C(15)));			// WE pin, High Write, Low Read
	P("WL_CPW_CTRL0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(16)),PDSA(2, P_C(16))); // WE pin, High Write, Low Read
	P("WL_CPW_CTRL1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(17)),PDSA(2, P_C(17))); // WE pin, High Write, Low Read
	P("WE", P_IN(1)	, P_NRZB, P_BCLK(2), PDSA(1, P_C(18)),PDSA(2, P_C(18))); // WE pin, High Write, Low Read
	P("MACRO_ALL", P_IN(1)	, P_NRZB, P_BCLK(2), PDSA(1, P_C(24)),PDSA(2, P_C(24))); // WE pin, High Write, Low Read

	
}

void setPinFmt()
{
	/*INPUT PINS*/
	P("DIN0", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(0)),PDSA(2, P_D(0)));
	P("DIN1", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(1)),PDSA(2, P_D(1)));
	P("DIN2", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(2)),PDSA(2, P_D(2)));
	P("DIN3", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(3)),PDSA(2, P_D(3)));
	P("DIN4", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(4)),PDSA(2, P_D(4)));
	P("DIN5", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(5)),PDSA(2, P_D(5)));
	P("DIN6", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(6)),PDSA(2, P_D(6)));
	P("DIN7", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(7)),PDSA(2, P_D(7)));
	P("DIN8", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(8)),PDSA(2, P_D(8)));
	P("DIN9", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(9)),PDSA(2, P_D(9)));
	P("DIN10", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(10)),PDSA(2, P_D(10)));
	P("DIN11", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(11)),PDSA(2, P_D(11)));
	P("DIN12", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(12)),PDSA(2, P_D(12)));
	P("DIN13", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(13)),PDSA(2, P_D(13)));
	P("DIN14", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(14)),PDSA(2, P_D(14)));
	P("DIN15", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(15)),PDSA(2, P_D(15)));
	P("DIN16", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(16)),PDSA(2, P_D(16)));
	P("DIN17", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_D(17)),PDSA(2, P_D(17)));
	P("DIN18", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(0)),PDSA(2, P_SD(0)));
	P("DIN19", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(1)),PDSA(2, P_SD(1)));
	P("DIN20", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(2)),PDSA(2, P_SD(2)));
	P("DIN21", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(3)),PDSA(2, P_SD(3)));
	P("DIN22", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(4)),PDSA(2, P_SD(4)));
	P("DIN23", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(5)),PDSA(2, P_SD(5)));
	P("DIN24", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(6)),PDSA(2, P_SD(6)));
	P("DIN25", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(7)),PDSA(2, P_SD(7)));
	P("DIN26", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(8)),PDSA(2, P_SD(8)));
	P("DIN27", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(9)),PDSA(2, P_SD(9)));
	P("DIN28", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(10)),PDSA(2, P_SD(10)));
	P("DIN29", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(11)),PDSA(2, P_SD(11)));
	P("DIN30", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(12)),PDSA(2, P_SD(12)));
	P("DIN31", P_IN(1), P_NRZB, P_BCLK(1), PDSA(1, P_SD(13)),PDSA(2, P_SD(13)));

	/*OUTPUT PINS*/
	P("DOUT0", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(0)),PDSA(2, P_D(0)));
	P("DOUT1", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(1)),PDSA(2, P_D(1)));
	P("DOUT2", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(2)),PDSA(2, P_D(2)));
	P("DOUT3", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(3)),PDSA(2, P_D(3)));
	P("DOUT4", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(4)),PDSA(2, P_D(4)));
	P("DOUT5", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(5)),PDSA(2, P_D(5)));
	P("DOUT6", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(6)),PDSA(2, P_D(6)));
	P("DOUT7", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(7)),PDSA(2, P_D(7)));
	P("DOUT8", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(8)),PDSA(2, P_D(8)));
	P("DOUT9", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(9)),PDSA(2, P_D(9)));
	P("DOUT10", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(10)),PDSA(2, P_D(10)));
	P("DOUT11", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(11)),PDSA(2, P_D(11)));
	P("DOUT12", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(12)),PDSA(2, P_D(12)));
	P("DOUT13", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(13)),PDSA(2, P_D(13)));
	P("DOUT14", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(14)),PDSA(2, P_D(14)));
	P("DOUT15", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(15)),PDSA(2, P_D(15)));
	P("DOUT16", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(16)),PDSA(2, P_D(16)));
	P("DOUT17", P_OUT(1), P_STRB(1, 1), PDSA(1, P_D(17)),PDSA(2, P_D(17)));
	P("DOUT18", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(0)),PDSA(2, P_SD(0)));
	P("DOUT19", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(1)),PDSA(2, P_SD(1)));
	P("DOUT20", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(2)),PDSA(2, P_SD(2)));
	P("DOUT21", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(3)),PDSA(2, P_SD(3)));
	P("DOUT22", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(4)),PDSA(2, P_SD(4)));
	P("DOUT23", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(5)),PDSA(2, P_SD(5)));
	P("DOUT24", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(6)),PDSA(2, P_SD(6)));
	P("DOUT25", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(7)),PDSA(2, P_SD(7)));
	P("DOUT26", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(8)),PDSA(2, P_SD(8)));
	P("DOUT27", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(9)),PDSA(2, P_SD(9)));
	P("DOUT28", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(10)),PDSA(2, P_SD(10)));
	P("DOUT29", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(11)),PDSA(2, P_SD(11)));
	P("DOUT30", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(12)),PDSA(2, P_SD(12)));
	P("DOUT31", P_OUT(1), P_STRB(1, 1), PDSA(1, P_SD(13)),PDSA(2, P_SD(13)));

	/*ADDRESS PINS*/
	P("AD0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(0)),PDSA(2, P_Y(0)));
	P("AD1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(1)),PDSA(2, P_Y(1)));
	P("AD2", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(2)),PDSA(2, P_Y(2)));
	P("AD3", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_Y(3)),PDSA(2, P_Y(3)));
	P("AD4", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(0)),PDSA(2, P_X(0))); // Address[0:4] for column0~31
	P("AD5", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(1)),PDSA(2, P_X(1)));
	P("AD6", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(2)),PDSA(2, P_X(2)));
	P("AD7", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(3)),PDSA(2, P_X(3)));
	P("AD8", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(4)),PDSA(2, P_X(4)));
	P("AD9", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(5)),PDSA(2, P_X(5)));
	P("AD10", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(6)),PDSA(2, P_X(6)));
	P("AD11", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(7)),PDSA(2, P_X(7)));
	P("AD12", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(8)),PDSA(2, P_X(8))); // Address[5:12] for row0~255
	P("MACRO_SEL0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(9)),PDSA(2, P_X(9)));//X0
	P("MACRO_SEL1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(10)),PDSA(2, P_X(10)));//X1
	P("MACRO_SEL2", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(11)),PDSA(2, P_X(11)));//X2
	P("MACRO_SEL3", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(12)),PDSA(2, P_X(12)));//X3
	P("MACRO_SEL4", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(13)),PDSA(2, P_X(13)));//X4
	P("MACRO_SEL5", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_X(14)),PDSA(2, P_X(14)));//X5

	/*CONTROL PINS*/
	P("CLK"		, P_IN(1), P_IRZO, P_BCLK(3), P_CCLK(3), PDSA(1, P_C(1)),PDSA(2, P_C(1)));
	P("DIRIN"	, P_IN(1), P_IRZO, P_BCLK(3), P_CCLK(3), PDSA(1, P_C(2)),PDSA(2, P_C(2)));
	P("DIROUT"	, P_OUT(1), P_DNRZ, P_EXPA(1),P_EXPB(2),P_STRB(1, 2), P_STRB(2, 2), PDSA(1, P_C(3)),PDSB(1,P_C(31)),PDSA(2, P_C(3)),PDSB(2,P_C(31))); // STRB with CPE2
	P("PAD_OE"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(4)), PDSA(2, P_C(4)));		// WE pin, High Write, Low Read
	P("MODE_SEL0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(5)), PDSA(2, P_C(5)));		// WE pin, High Write, Low Read
	P("MODE_SEL1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(6)),PDSA(2, P_C(6)));		// WE pin, High Write, Low Read
	P("RN"	, P_IN(1), P_INRZB, P_BCLK(2), PDSA(1, P_C(7)),PDSA(2, P_C(7)));		// WE pin, High Write, Low Read
	P("FSEL0"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(8)),PDSA(2, P_C(8)));		// WE pin, High Write, Low Read
	P("FSEL1"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(9)),PDSA(2, P_C(9)));		// WE pin, High Write, Low Read
	P("FTYPE0"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(10)),PDSA(2, P_C(10)));		// WE pin, High Write, Low Read
	P("FTYPE1"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(11)),PDSA(2, P_C(11)));		// WE pin, High Write, Low Read
	P("BIST_EN"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(12)),PDSA(2, P_C(12)));		// WE pin, High Write, Low Read
	P("CEN"		, P_IN(1), P_INRZB, P_BCLK(2), PDSA(1, P_C(13)),PDSA(2, P_C(13)));			// WE pin, High Write, Low Read
	P("SAE_SEL"	, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(14)),PDSA(2, P_C(14)));		// WE pin, High Write, Low Read
	P("SAE"		, P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(15)),PDSA(2, P_C(15)));			// WE pin, High Write, Low Read
	P("WL_CPW_CTRL0", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(16)),PDSA(2, P_C(16))); // WE pin, High Write, Low Read
	P("WL_CPW_CTRL1", P_IN(1), P_NRZB, P_BCLK(2), PDSA(1, P_C(17)),PDSA(2, P_C(17))); // WE pin, High Write, Low Read
	P("WE", P_IN(1)	, P_NRZB, P_BCLK(2), PDSA(1, P_C(18)),PDSA(2, P_C(18))); // WE pin, High Write, Low Read
	P("MACRO_ALL", P_IN(1)	, P_NRZB, P_BCLK(2), PDSA(1, P_C(24)),PDSA(2, P_C(24))); // WE pin, High Write, Low Read

	
}

void setDpinFixL(char *pinName, int viNo, double vih, double vil)
{
	setDpinVi(viNo, vih, vil);
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle(hPin);
	UTL_SetPinViNumber(hPin, viNo);
	UTL_SetPinDrWaveform(hPin, UT_WAV_FIXL);
	UTL_SendPin(hPin, pinName);
	UTL_DeleteHandle(hPin);
}

void setDpinFixH(char *pinName, int viNo, double vih, double vil)
{
	setDpinVi(viNo, vih, vil);
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle(hPin);
	UTL_SetPinViNumber(hPin, viNo);
	UTL_SetPinDrWaveform(hPin, UT_WAV_FIXH);
	UTL_SendPin(hPin, pinName);
	UTL_DeleteHandle(hPin);
}
void setDpinOpen(char *pinName)
{
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle(hPin);
	UTL_SetPinOpen(hPin, UT_ON);
	UTL_SendPin(hPin, pinName);
	UTL_DeleteHandle(hPin);
}

void setDpinClose(char *pinName)
{
	PinHandle hPin = UTL_GetPinHandle();
	UTL_InitializePinHandle(hPin);
	UTL_SetPinOpen(hPin, UT_OFF);
	UTL_SendPin(hPin, pinName);
	UTL_DeleteHandle(hPin);
}
